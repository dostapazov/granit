//---------------------------------------------------------------------------

#ifndef opcclient_modemH
#define opcclient_modemH
#include <modem.hpp>
#include "opcclientmdm.h"
//---------------------------------------------------------------------------
class TOPCClientModem:public TModemBase
{
protected:
  OCSETTINGS settings;
  bool    __fastcall read_settings  ();
  bool    __fastcall write_settings ();
  DWORD   __fastcall get_config_data(DWORD mask,LPVOID buf,DWORD bsz);
  bool    __fastcall set_config_data(DWORD mask,LPVOID buf,DWORD bsz);
  bool    __fastcall compare_config_data(DWORD mask,LPVOID buf,DWORD bsz,LPDWORD ch_mask,BOOL * restart);
  bool    __fastcall check_config_data  (DWORD mask,LPVOID buf,DWORD bsz);
  DWORD   __fastcall get_mem_used();
  int     __fastcall convert_rx_data(LPWORD fa,LPBYTE in,int in_len,LPBYTE out,DWORD out_sz) ;
  void    __fastcall free_line(modem_line *);
  DWORD   __fastcall get_lines_limit() {return 1;};
//  BOOL    __fastcall can_start(DWORD reason,LPARAM p2);
  DWORD   __fastcall start(DWORD reason,LPARAM start_param);
  DWORD   __fastcall get_window_module (wchar_t * buf,DWORD bsz);
  DWORD   __fastcall get_modem_flags() {return MPF_DATA_SOURCE;}
public:
  TOPCClientModem();
};

#endif

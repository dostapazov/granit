//---------------------------------------------------------------------------
/*
Copyright (c) 2013 Serge L. Ryadkow admin@opcgate.ru http://opcgate.ru 

Permission is hereby granted, free of charge, to any person obtaining a copy of this 
software and associated documentation files (the "Software"), to deal in the Software 
without restriction, including without limitation the rights to use, copy, modify, 
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to 
permit persons to whom the Software is furnished to do so, subject to the following 
conditions:

The above copyright notice and this permission notice shall be included in all copies 
or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE 
FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR 
OTHER DEALINGS IN THE SOFTWARE. 
*/
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
#include <vcl.h>
#include <oleauto.hpp>

#pragma hdrstop

#pragma warn -8027
#include <utilcls.h>
#pragma warn .8027

#include "OPCEnum.h"
//---------------------------------------------------------------------------

#pragma package(smart_init)


//---------------------------------------------------------------------------
const CLSID CLSID_OPCServerList =
  {0x13486D51,0x4821,0x11D2,{0xA4,0x94,0x3C,0xB3,0x06,0xC1,0x00,0x00}};
const CATID CATID_OPCDAServer10 =
  {0x63D5F430,0xCFE4,0x11d1,{0xB2,0xC8,0x00,0x60,0x08,0x3B,0xA1,0xFB}};
const CATID CATID_OPCDAServer20 =
  {0x63D5F432,0xCFE4,0x11d1,{0xB2,0xC8,0x00,0x60,0x08,0x3B,0xA1,0xFB}};
const CATID CATID_OPCDAServer30 =
  {0xCC603642,0x66D7,0x48f1,{0xB6,0x9A,0xB6,0x25,0xE7,0x36,0x52,0xD7}};
const CATID CATID_XMLDAServer10 =
  {0x3098EDA4,0xA006,0x48b2,{0xA2,0x7F,0x24,0x74,0x53,0x95,0x94,0x08}};
const CATID CATID_OPCDXServer10 =
  {0xA0C85BB8,0x4161,0x4fd6,{0x86,0x55,0xBB,0x58,0x46,0x01,0xC9,0xE0}};
const CATID CATID_OPCAEServer10 =
  {0x58E13251,0xAC87,0x11d1,{0x84,0xD5,0x00,0x60,0x8C,0xB8,0xA7,0xE9}};
//---------------------------------------------------------------------------
TOPCEnum::TOPCEnum(const AnsiString &host)
{
  Oleauto::OleCheck(CoClassCreator::CreateRemote(
    host.IsEmpty() ? WideString("localhost").c_bstr() : WideString(host).c_bstr(),
    CLSID_OPCServerList, IID_IOPCServerList, &ServerList));

}
//---------------------------------------------------------------------------
TOPCEnum::~TOPCEnum()
{
  ServerList->Release();
}
//---------------------------------------------------------------------------
CLSID TOPCEnum::CLSIDFromProgID(const AnsiString &pid)
{
  CLSID cid;
  Oleauto::OleCheck(ServerList->CLSIDFromProgID(WideString(pid).c_bstr(), &cid));
  return cid;
}
//---------------------------------------------------------------------------
AnsiString TOPCEnum::ProgIDFromCLSID(const GUID &cid)
{
  LPWSTR pid;
  LPWSTR ut;
  Oleauto::OleCheck(ServerList->GetClassDetails(cid, &pid, &ut));
  AnsiString s(pid);
  ::CoTaskMemFree(pid);
  ::CoTaskMemFree(ut);
  return s;
}
//---------------------------------------------------------------------------
AnsiString TOPCEnum::UserTypeFromCLSID(const GUID &cid)
{
  LPWSTR pid;
  LPWSTR ut;
  Oleauto::OleCheck(ServerList->GetClassDetails(cid, &pid, &ut));
  AnsiString s(ut);
  ::CoTaskMemFree(pid);
  ::CoTaskMemFree(ut);
  return s;
}
//---------------------------------------------------------------------------
int TOPCEnum::EnumProgId(TStrings *sl, TOPCServerType type)
{
  int cnt;
  TStringList *dl = new TStringList;
  try {
    cnt = Enum(sl, dl, type);
  }
  __finally {
    delete dl;
  }
  return cnt;
}
//---------------------------------------------------------------------------
int TOPCEnum::EnumUserType(TStrings *sl, TOPCServerType type)
{
  int cnt;
  TStringList *dl = new TStringList;
  try {
    cnt = Enum(dl, sl, type);
  }
  __finally {
    delete dl;
  }
  return cnt;
}
//---------------------------------------------------------------------------
int TOPCEnum::Enum(TStrings *pid, TStrings *ut, TOPCServerType type)
{
  pid->Clear();
  ut->Clear();
  int cnt = 0;
  int n = 0;
  if (type & OPC_DA10) ++n;
  if (type & OPC_DA20) ++n;
  if (type & OPC_DA30) ++n;
  if (type & OPC_XMLDA10) ++n;
  if (type & OPC_DX10) ++n;
  if (type & OPC_AE10) ++n;
  GUID *g = new GUID[n];
  try {
    int i = 0;
    if (type & OPC_DA10) g[i++] = CATID_OPCDAServer10;
    if (type & OPC_DA20) g[i++] = CATID_OPCDAServer20;
    if (type & OPC_DA30) g[i++] = CATID_OPCDAServer30;
    if (type & OPC_XMLDA10) g[i++] = CATID_XMLDAServer10;
    if (type & OPC_DX10) g[i++] = CATID_OPCDXServer10;
    if (type & OPC_AE10) g[i] = CATID_OPCAEServer10;
    IEnumGUID *e;
    Oleauto::OleCheck(ServerList->EnumClassesOfCategories(n, g, 0, 0, &e));
    try {
      GUID g;
      unsigned long l = 0;
      LPWSTR p;
      LPWSTR u;
      while (e->Next(1, &g, &l) == S_OK) {
        Oleauto::OleCheck(ServerList->GetClassDetails(g, &p, &u));
        pid->Add(p);
        ut->Add(u);
        ++cnt;
        ::CoTaskMemFree(p);
        ::CoTaskMemFree(u);
      }
    }
    __finally {
      e->Release();
    }
  }
  __finally {
    delete[] g;
  }
  return cnt;
}
//---------------------------------------------------------------------------


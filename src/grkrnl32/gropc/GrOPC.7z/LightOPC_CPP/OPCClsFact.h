//---------------------------------------------------------------------------
/*
Object oriented shell for LightOPC library
Copyright (C) 2012 Serge L. Ryadkow

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

Contacts:
admin@opcgate.ru
http://opcgate.ru
*/
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
#ifndef OPCClsFactH
#define OPCClsFactH
//---------------------------------------------------------------------------
#include <windows.h>
#include <ole2.h>
#include <olectl.h>
#include <oleauto.h>

#include <opcda.h>
#include <opcerror.h>
#include <lightopc.h>
//---------------------------------------------------------------------------
extern const char OPCClsID[];
extern const char OPCProgID[];
extern const loVendorInfo OPCVendor;
extern const GUID OPCGUID;
//---------------------------------------------------------------------------
//**** Server Counting stuff & OLE ICF implementation *****************
//  The IClassFactory is unavoidable evil. Feel free to go ahead.
//  Basically we've to unload when the server_count being zero.
//  But there are different techniques for in-/out-of- proc servers.
//---------------------------------------------------------------------------
class TOPCClassFactory: public IClassFactory
{
public:
 int  is_out_of_proc,
      server_inuse; /* go 0 when unloading initiated */
 LONG server_count;
 CRITICAL_SECTION lk_count;  // protect server_count
 TOPCClassFactory(): is_out_of_proc(0), server_inuse(0), server_count(0)
   {
      InitializeCriticalSection(&lk_count);
   }
 ~TOPCClassFactory()
   {
      DeleteCriticalSection(&lk_count);
   }

  void serverAdd(void);
  void serverRemove(void);

// Do nothing: we're static, he-he
  STDMETHODIMP_(ULONG) AddRef(void) { return 1; }
  STDMETHODIMP_(ULONG) Release(void) { return 1; }

  STDMETHODIMP QueryInterface(REFIID iid, LPVOID *ppInterface)
    {
      if (ppInterface == NULL)
        return E_INVALIDARG;
      if (iid == IID_IUnknown || iid == IID_IClassFactory)
        {
          *ppInterface = this;
          AddRef();
          return S_OK;
        }
      *ppInterface = NULL;
      return E_NOINTERFACE;
    }

  STDMETHODIMP LockServer(BOOL fLock)
    {
      if (fLock)
        serverAdd();
      else
        serverRemove();
      return S_OK;

    }

  STDMETHODIMP CreateInstance(LPUNKNOWN pUnkOuter, REFIID riid,
                              LPVOID *ppvObject);

};
//---------------------------------------------------------------------------
extern loService *OPCSvc;
extern TOPCClassFactory ClsFact;
//---------------------------------------------------------------------------
#endif

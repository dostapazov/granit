/****************************************************************************

 NT-Service helper library.

 Copyright (c) 2000,2002  Timofei Bondarenko, Kostya Volovich.
 ****************************************************************************/
#ifndef  NTSE_H_
#define  NTSE_H_
#ifdef __cplusplus
extern "C" {
#endif

/*****************************************************************************

  The NTSE is a simple (hrrr) library destinated to simplify writing of
  NT-Services. (Note _writing_ - not desigining).
  NTSE does two thing:
  a) wrap native SCM API to save some handtyping 
    (but keep transparency and allow to turn back to native SCM easily);
  b) provide SCM simulator for the Win95/98/ME.
    (An icon with menu inserted into taskbar).

  Therefore we got two thing:
  a) The same binares of NTSE-based services are able to run on eihter
     Win95 or NT with no changes.
  b) NTSE layer can be removed easily, without redesigning of a service.

  Most of ntse functions have their SCM equivalents, so they 
  described briefly. Look at NSDN for details.

  Usage: link ntse as static library. If you use VisualC then _copy_
  ntse.dsp into your project directory and include in your project.

 All functions return 0 if Ok or appropriate GetLastError() otherwise.
 ( > 0 when error is not critical).

 *****************************************************************************/

typedef struct ntseContext ntseContext;

/* The ntseContext* is an extensible storage for auxiliary 
configurable parameters.
   At the moment there are 3 possible values:
   NULL - autoselect NT/95; */

extern ntseContext *ntseCtxNT, /* use NT's SCM (fail on Win95) */
                   *ntseCtx95; /* simulate SCM (works on Win95 and NT) */

/* Commands controlling services: */

#define ntseOP_DELETE   (-1)
#define ntseOP_START    (-2)
#define ntseOP_STOP     (-3) /*1*/
#define ntseOP_PAUSE    (-4) /*2*/
#define ntseOP_CONTINUE (-5) /*3*/
#define ntseOP_QUERY    (-6)

int ntseCommand(ntseContext *nc, const char *name, int command);
/* These two function do accept either ntseOP_*** or SERVICE_CONTROL_*** constants.
   And do call to a service control function.
The 1072=ERROR_SERVICE_MARKED_FOR_DELETE returned in attempt to delete
    a running service. */

#ifdef SERVICE_CONTROL_STOP
/* The same as ntseCommand(), but returns SERVICE_STATUS.
   But not for any COMMAND SERVICE_STATUS will be filled in! */
int ntseControl(ntseContext *nc, const char *name, int command, SERVICE_STATUS *stat);

/* Allocates the buffer for *cfg. This buffer have to be freed by ntseFree().
   If cfg is 0 then 0 returned if service is installed.
   1060=ERROR_SERVICE_DOES_NOT_EXIST. */
int ntseQueryConfig(ntseContext *nc, const char *name, QUERY_SERVICE_CONFIG **cfg);
#endif

int ntseFree(ntseContext *nc, void *buf);

/* See CreateService(). 1073=ERROR_SERVICE_EXISTS is posiible error */

int ntseCreate(ntseContext *nc,
               const char *serviceName,   /* name of service */
               const char *displayName,   /* display name */
                     int   serviceType,   /* type of service:
            SERVICE_{WIN32_{OWN|SHARE}|INTERACTIVE}_PROCESS */
                     int   startType,     /* when to start service:
            SERVICE_{DISABLED|{{AUTO|DEMAND|[BOOT|SYSTEM]}_START}} */
                     int   errorControl,  /* severity of service failure
            SERVICE_ERROR_{IGNORE|NORMAL|[SEVERE|CRITICAL]} */
               const char *commandline,   /* name of binary file */
               const char *loadOrderGroup, /* name of load ordering group */
                 unsigned *lpdwTagId,     /* tag identifier */
               const char *dependencies,  /* array of dependency names */
               const char *accountName,   /* account name */
               const char *password);     /* account password */
/* COMMANDLINE may contains space separated arguments.
   Therefore the name of executable itself should not contain
   spaces or should be quoted in double quotes. */


/* see ServerChangeConfig() */
int ntseChangeConfig(ntseContext *nc,
               const char *serviceName,
               const char *displayName,
                     int   serviceType,
                     int   startType,
                     int   errorControl,
               const char *commandline,
               const char *loadOrderGroup,
                 unsigned *lpdwTagId,
               const char *dependencies,
               const char *accountName,
               const char *password);

/* Be ware! All parameters shold be specified as for ntseCreate() */

int ntseCreateOrChange(ntseContext *nc,
               const char *serviceName,
               const char *displayName,
                     int   serviceType,
                     int   startType,
                     int   errorControl,
               const char *commandline,
               const char *loadOrderGroup,
                 unsigned *lpdwTagId,
               const char *dependencies,
               const char *accountName,
               const char *password);

/******************* Run services... ************************/

typedef struct ntseService_int *ntseHandle;

typedef void (*ntseMain)(ntseHandle, int argc, const char *argv[]);

/* Yes, ServiceMain(). But ntseHandle is not the same as a service's HANDLE. */

#ifdef SERVICE_CONTROL_STOP

/* Service description structure */
typedef struct ntseService 
  {
     const char         *nsName;
     ntseMain            nsMain;
     LPHANDLER_FUNCTION  nsHandler;  /* VOID WINAPI Handler(DWORD) */
     SERVICE_STATUS     *nsStatus;   /* optional, used before nsMain() gets called. */
     ntseHandle         *nsHandle;   /* will be filled-in */
  } ntseService; 

int ntseServiceRun(ntseContext *nc, ntseService *table, unsigned count);

/* Much like StartServiceCtrlDispatcher() + RegisterServiceCtrlHandler();
   On success, SERVICE_STATUS is set to START_PENDING, nWaitHint = 3000.
   When nsMain exited, status will be changed to STOPPED.
   nsStatus should point to a initialized by at least SERVICE_TYPE & nWaitHint. */

#ifdef  WM_USER
int ntseServiceRunEx(ntseContext *nc, ntseService *table, unsigned count,
                     int (*init_callback)(void *arg, HWND), void *arg);
/* The INIT_CALLBACK will be called when SCM simulator created. 
   In will not be called in nt-mode.
   A Non-zero return value from INIT_CALLBACK will cause abort of
   the SCM and immediate return from ntseServiceRunEx(). */
     
#endif

int ntseSetStatus(ntseHandle se, const SERVICE_STATUS *status);
/* See SetServiceStatus().  There is might be no return from 
   successful ntseSetStatus(SERVICE_STOPPED). */
#endif

#ifdef  WM_USER
HWND ntseServiceWindow(ntseContext *nc, const char *name, int *index);
/* Find the HWND of the Win95-simulated SCM that carries 
   the service NAME (system-wide, not limited by current process). 
   Returns NULL if the SCM not found or not running. 
   Optionally returns INDEX of service in the SCM if SHARED_PROCESS. */
#define NTSE_WM_TASKBAR     (WM_USER+1)
#define NTSE_ID_TASKBAR     111/*an arbitrary number*/
/* A simulated SCM has assotiated icon in taskbar and menu.
   The icon can be altered via Shell_NotifyIcon():
   NOTIFYICONDATA::uID = NTSE_ID_TASKBAR; 
   NOTIFYICONDATA::uCallbackMessage = NTSE_WM_TASKBAR;
   The HWND can be managed via GetWindowThreadProcessId() 
   and SetWindowsHookEx(). */
/* The WM_COMMAND::wParam's identifiers in range [128...255] 
   are not used by ntse. Thus they can be used safely to extend 
   simulator's menu. */
#endif

int printServiceConfig(ntseContext *, const char *name);
int printServiceStatus(ntseContext *nc, const char *name);

#ifdef __cplusplus
           }
#endif
#endif /*NTSE_H_*/

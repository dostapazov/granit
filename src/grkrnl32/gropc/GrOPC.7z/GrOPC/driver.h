#ifndef __DRIVER_H
#define __DRIVER_H

//#include "lightopc.h"
//#include "unilog.h"

//class /*__declspec(dllexport)*/ GrOPCDriver
//{
//public:
//	//loService *gr_service;
//	GrOPCDriver();
//	~GrOPCDriver();
//
//	//virtual int driver_init(int lflags);
//	//virtual void driver_destroy(void);
//
//};

//extern unilog *log;                    

//STDAPI_(void) OPCStep(void);

#endif

//---------------------------------------------------------------------------
/*
Copyright (c) 2013 Serge L. Ryadkow admin@opcgate.ru http://opcgate.ru 

Permission is hereby granted, free of charge, to any person obtaining a copy of this 
software and associated documentation files (the "Software"), to deal in the Software 
without restriction, including without limitation the rights to use, copy, modify, 
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to 
permit persons to whom the Software is furnished to do so, subject to the following 
conditions:

The above copyright notice and this permission notice shall be included in all copies 
or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE 
FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR 
OTHER DEALINGS IN THE SOFTWARE. 
*/
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
#ifndef OPCEnumH
#define OPCEnumH
//---------------------------------------------------------------------------
#include <opccomn.h>
//---------------------------------------------------------------------------
class TOPCEnum
{
  public:
    enum TOPCServerType {
      OPC_DA10 = 0x0001, OPC_DA20 = 0x0002, OPC_DA30 = 0x0004,
      OPC_XMLDA10 = 0x0008, OPC_DX10 = 0x0010, OPC_AE10 = 0x0020,
      OPC_DA = OPC_DA10 | OPC_DA20 | OPC_DA30,
      OPC_XMLDA = OPC_XMLDA10,
      OPC_DX = OPC_DX10,
      OPC_AE = OPC_AE10,
      OPC_ALL = OPC_DA | OPC_XMLDA | OPC_DX | OPC_AE
    };
    TOPCEnum(const AnsiString &host = "");
    ~TOPCEnum();
    CLSID CLSIDFromProgID(const AnsiString &pid);
    AnsiString ProgIDFromCLSID(const GUID &cid);
    AnsiString UserTypeFromCLSID(const GUID &cid);
    int EnumProgId(TStrings *sl, TOPCServerType type = OPC_ALL);
    int EnumUserType(TStrings *sl, TOPCServerType type = OPC_ALL);
    int Enum(TStrings *pid, TStrings *ut, TOPCServerType type = OPC_ALL);
  private:
    IOPCServerList *ServerList;
};
//---------------------------------------------------------------------------
#endif //OPCEnumH

#include "grclfact.h"
#include "driver.h"
#include <opcda.h>
//#include "gkmodules.h"
//#include "opcsrv_modem.hpp"

//unilog *log;
static GrClassFactory Gr_CF;

GrClassFactory::GrClassFactory(): server_inuse(0), server_count(0)//, gr_service(0)
{
  InitializeCriticalSection(&lk_count);
}

GrClassFactory::~GrClassFactory()
{
  DeleteCriticalSection(&lk_count);
}

STDMETHODIMP GrClassFactory::QueryInterface(REFIID iid, LPVOID *ppInterface)
{
	UL_ERROR((log,0, "��� QueryInterface"));
  if (ppInterface == NULL)
    return E_INVALIDARG;
  if (iid == IID_IUnknown || iid == IID_IClassFactory)
  {
    UL_DEBUG((log,0, "GranitClassFactory::QueryInterface() Ok"));
    *ppInterface = this;
    AddRef();
    return S_OK;
  }
  UL_DEBUG((log,0, "GranitClassFactory::QueryInterface() Failed"));
  *ppInterface = NULL;
  return E_NOINTERFACE;
}

STDMETHODIMP GrClassFactory::LockServer(BOOL fLock)
{
  UL_DEBUG((log,0, "GranitClassFactory::LockServer(%d)", fLock));
  if (fLock) serverAdd();
  else serverRemove();
  return S_OK;
}

void GrClassFactory::serverAdd(void)
{
  EnterCriticalSection(&lk_count);
  ++server_count;
  LeaveCriticalSection(&lk_count);
}

void GrClassFactory::serverRemove(void)
{
  EnterCriticalSection(&lk_count);
  if (0 == --server_count && server_inuse) server_inuse = 0;
  LeaveCriticalSection(&lk_count);
}

static void a_server_finished(void *arg, loService *b, loClient *c)
{
  /* ARG is the same as we've passed to loClientCreate() */
  UL_DEBUG((log,0, "a_server_finished(%lu)...", Gr_CF.server_count));
  Gr_CF.serverRemove();

/* OPTIONAL: */
  UL_INFO((log,0, "a_server_finished(%lu) USERID=<%ls>",
    Gr_CF.server_count, arg? arg: L"<null>"));
}

//static void dll_simulator_wait(void); /* in-proc specefic */
//static void dll_simulator_start(void); /* in-proc specefic */

STDMETHODIMP GrClassFactory::CreateInstance(LPUNKNOWN pUnkOuter, REFIID riid, LPVOID *ppvObject)
{
	if (gr_service)
		UL_WARNING((log,0, "gr_service not null"));
	else
		UL_WARNING((log,0, "gr_service null"));
	if (!gr_service) 
		return CLASS_E_CLASSNOTAVAILABLE;

  IUnknown *server = 0;
  HRESULT hr = S_OK;

/* OPTIONAL: security stuff */
  OLECHAR *userid = 0;
  wchar_t *cuserid;
  LONG userno;
  static LONG usercount;

  userno = InterlockedIncrement(&usercount);

  CoQueryClientBlanket(0, 0, 0, 0, 0, (RPC_AUTHZ_HANDLE*)&userid, 0);
  if (!userid) userid = L"{unknown}";

  UL_WARNING((log,0, "USER:#%ld <%ls>", userno, userid));

  if (cuserid = (wchar_t*)malloc((wcslen(userid) + 16) * sizeof(wchar_t)))
    swprintf(cuserid, L"#%ld %ls", userno, userid);
/* -- end of security stuff */

  if (pUnkOuter)
    {
#if 1 /* Do we support aggregation? */
     if (riid != IID_IUnknown) 
#endif
          return CLASS_E_NOAGGREGATION;
    }

  serverAdd();  /* the lock for a_server_finished() */

{
 IUnknown *inner = 0;
 if (loClientCreate_agg(gr_service, (loClient**)&server, 
                       pUnkOuter, &inner,
                       0, 0, a_server_finished, cuserid/*this*/))
    {
      serverRemove();
      hr = E_OUTOFMEMORY;
      UL_MESSAGE((log,0, "GranitClassFactory::loClientCreate_agg() failed"));
    }
  else if (pUnkOuter) *ppvObject = (void*)inner; /*aggregation requested*/
  else /* no aggregation */
    {
/* loClientCreate(my_service, (loClient**)&server, 
                  0, &vendor, a_server_finished, cuserid) - with no aggregation */
      /* Initally the created SERVER has RefCount=1 */
      hr = server->QueryInterface(riid, ppvObject); /* Then 2 (if success) */
      server->Release(); /* Then 1 (on behalf of client) or 0 (if QI failed) */
      if (FAILED(hr)) 
        UL_MESSAGE((log,0, "GranitClassFactory::loClient QueryInterface() failed"));
      /* So we shouldn't carry about SERVER destruction at this point */
    }
}
  if (SUCCEEDED(hr))
    {
      loSetState(gr_service, (loClient*)server,
             loOP_OPERATE, (int)OPC_STATUS_RUNNING, /* other states are possible */
             "Finished by client");
      UL_DEBUG((log,0, "GranitClassFactory::server_count = %ld", server_count));
    }

  return hr;
}

/************************* The END of OLE-specific ***************************/

/****************** The Process Data to be exported via OPC ******************
 (driver's internal representation) */

//static CRITICAL_SECTION lk_values;     /* protects ti[] from simultaneous 
//                                    access by simulator() and WriteTags() */
///* Our data tags: */
///* zero is resierved for an invalid RealTag */
//#define TI_zuzu      (1)
//#define TI_lulu      (2)
//#define TI_bandwidth (3)
//#define TI_array     (4)
//#define TI_enum      (5)
//#define TI_quiet     (6)
//#define TI_quality   (7)
//#define TI_string    (8)
//#define TI_MAX       (8)
//
//static loTagId ti[TI_MAX + 1];          /* their IDs */
//static const char *tn[TI_MAX + 1] =     /* their names */
//{ "--not--used--", "zuzu", "lulu", "bandwidth", "array", "enum-localizable",
//    "quiet", "quality", "string" };
//static loTagValue tv[TI_MAX + 1];       /* their values */
//
//
/**********************************************************************
 sample server initiation & simulation
 **********************************************************************/

/* OPTIONAL: example of dynamic tag creation */

///********* Data simulator stuff ************************************************/
//
//void simulate(unsigned pause)
//{
//  DWORD hitime = 0;
//  unsigned starttime = GetTickCount();
//  UL_WARNING((log,0, "Simulator Started..."));
//
//  EnterCriticalSection(&lk_values);
//
///* Set up initial values for the tags we didn't initialized in driver_init(): */
//
//  tv[TI_zuzu].tvTi = ti[TI_zuzu];
//  tv[TI_zuzu].tvState.tsError = S_OK;
//  tv[TI_zuzu].tvState.tsQuality = OPC_QUALITY_GOOD;
//  V_VT(&tv[TI_zuzu].tvValue) = VT_R8;
//  V_R8(&tv[TI_zuzu].tvValue) = -100;
//
//  tv[TI_lulu].tvTi = ti[TI_lulu];
//  tv[TI_lulu].tvState.tsError = S_OK;
//  tv[TI_lulu].tvState.tsQuality = OPC_QUALITY_GOOD;
//  V_VT(&tv[TI_lulu].tvValue) = VT_I2;
//  V_I2(&tv[TI_lulu].tvValue) = 78;
//
//  tv[TI_enum].tvTi = ti[TI_enum];
//  tv[TI_enum].tvState.tsError = S_OK;
//  tv[TI_enum].tvState.tsQuality = OPC_QUALITY_GOOD;
//  V_VT(&tv[TI_enum].tvValue) = VT_I2;
//  V_I2(&tv[TI_enum].tvValue) = 1;
//
//  tv[TI_bandwidth].tvTi = ti[TI_bandwidth];
//  tv[TI_bandwidth].tvState.tsError = S_OK;
//  tv[TI_bandwidth].tvState.tsQuality = OPC_QUALITY_GOOD;
//  V_VT(&tv[TI_bandwidth].tvValue) = VT_I1;
//  V_I1(&tv[TI_bandwidth].tvValue) = -1;
//
//  tv[TI_quiet].tvTi = ti[TI_quiet];
//  tv[TI_quiet].tvState.tsError = S_OK;
//  tv[TI_quiet].tvState.tsQuality = OPC_QUALITY_LAST_KNOWN;
//  V_VT(&tv[TI_quiet].tvValue) = VT_I2;
//  V_I2(&tv[TI_quiet].tvValue) = 1412;
//
//  tv[TI_quality].tvTi = ti[TI_quality];
//  tv[TI_quality].tvState.tsError = S_OK;
////  tv[TI_quality].tvValue -- already assigned
//
//  tv[TI_string].tvTi = ti[TI_string];
//  tv[TI_string].tvState.tsQuality = OPC_QUALITY_GOOD;
//  tv[TI_string].tvState.tsError = S_OK;
////  tv[TI_string].tvValue -- already assigned
//
////  tv[TI_enum], tv[TI_array], string, quality, -- already assigned 
//
//  LeaveCriticalSection(&lk_values);
//
///**** Then do simulate ***********/
//
//  while(0 != my_CF.server_inuse) /* still working? */
//    {
//      FILETIME ft;
//
//      Sleep(10);   /* main delay */
//      GetSystemTimeAsFileTime(&ft); /* awoke */
//
///* OPTIONAL: reload log's configuration fromtime to time */
//      if (hitime != (ft.dwLowDateTime & 0xf8000000))    /* 13.5 sec */
//        {                       /* 0xff000000 is about 1.67 sec */
//          hitime = ft.dwLowDateTime & 0xf8000000;
//#if 0
//          unilog_Refresh(0);    /* all logs */
//#else
//          unilog_Refresh("LightOPC");
//          unilog_Refresh("Lopc-Sample-exe");
//          unilog_Refresh("Lopc-Sample-dll");
//#endif
//        }
//
///***** The main job: update the values ******/
//      EnterCriticalSection(&lk_values);
//
//double zuzu = 
//      (V_R8(&tv[TI_zuzu].tvValue) += 1./3.); /* main simulation */
//      V_VT(&tv[TI_zuzu].tvValue) = VT_R8;
//      tv[TI_zuzu].tvState.tsTime = ft;
//
//      V_I2(&tv[TI_lulu].tvValue) = (short)zuzu;
//      V_VT(&tv[TI_lulu].tvValue) = VT_I2;
//      tv[TI_lulu].tvState.tsTime = ft;
//
//      V_I2(&tv[TI_enum].tvValue) = (short)((ft.dwLowDateTime >> 22) % 7);
//      V_VT(&tv[TI_enum].tvValue) = VT_I2;
//      tv[TI_enum].tvState.tsTime = ft;
//
//      V_I1(&tv[TI_bandwidth].tvValue) = (char)loGetBandwidth(my_service, 0);
//      V_VT(&tv[TI_bandwidth].tvValue) = VT_I1;
//      tv[TI_bandwidth].tvState.tsTime = ft;
//      
///** OPTIONAL: enumerate all possible qualities: */
//      static const unsigned char legalq[] = {
//    OPC_QUALITY_CONFIG_ERROR    ,    OPC_QUALITY_NOT_CONNECTED   ,
//    OPC_QUALITY_DEVICE_FAILURE  ,    OPC_QUALITY_SENSOR_FAILURE  ,
//    OPC_QUALITY_LAST_KNOWN      ,    OPC_QUALITY_COMM_FAILURE    ,
//    OPC_QUALITY_OUT_OF_SERVICE  ,
//
//// STATUS_MASK Values for Quality = UNCERTAIN
//    OPC_QUALITY_LAST_USABLE     ,    OPC_QUALITY_SENSOR_CAL      ,
//    OPC_QUALITY_EGU_EXCEEDED    ,    OPC_QUALITY_SUB_NORMAL      ,
//
//// STATUS_MASK Values for Quality = GOOD
//    OPC_QUALITY_LOCAL_OVERRIDE  };
//
//      tv[TI_quality].tvState.tsTime = ft;
//      tv[TI_quality].tvState.tsQuality = 
//        legalq[((unsigned)ft.dwLowDateTime >> 24) % SIZEOF_ARRAY(legalq)];
//
///** OPTIONAL: change the STRING variable: */
//      WCHAR wstr[32];
//      local_text(wstr, (ft.dwLowDateTime >> 24) % 7, 0);
//      VariantClear(&tv[TI_string].tvValue); /* don't miss it! 
//                                    BSTR is not a simple type */
//      V_BSTR(&tv[TI_string].tvValue) = SysAllocString(wstr);
//      V_VT(&tv[TI_string].tvValue) = VT_BSTR;
//      tv[TI_string].tvState.tsTime = ft;
//
///** OPTIONAL: change the ARRAY variable: */
//      if (ti[TI_array]) /* has been successfuly initialized? */
//        {
//          long ix0 = 1, val = (long)zuzu;
//          SafeArrayPutElement(V_ARRAY(&tv[TI_array].tvValue), &ix0, &val);
//          tv[TI_array].tvTi = ti[TI_array];
//          tv[TI_array].tvState.tsTime = ft;
//        }
//
///** MANDATORY: send all the values into the cache: */
//      loCacheUpdate(my_service, TI_MAX, tv + 1, 0);
//
//      LeaveCriticalSection(&lk_values);
//
//      if (pause) 
//        {
///* IMPORTANT: force unloading of an out-of-proc 
//   if not connected during PAUSE millisec */
//          unsigned tnow = GetTickCount();
//          if (tnow - starttime >= pause)
//            {
//              pause = 0;
//              my_CF.serverRemove();
//            }
//        }
//
//      if (test_mode)
//        {
///* OPTIONAL: simulate client's connections to test loSetState
//      and track down resource leakage */
//          static int xx;
//          static IUnknown *cli;
//          unsigned tnow = GetTickCount();
//          if (tnow - starttime >= 2500)
//            {
//              starttime = tnow;
///* To test for unreleased handles / threads
//   run taskmgr and see what's happen...*/
//              if (cli) 
//                {
//                  cli->Release(); cli = 0;
//                  if (5 < ++xx) 
//                    {
//                      puts("SHUTDOWN initiated...");
//                      loSetState(my_service, 0, loOP_SHUTDOWN,
//                                 OPC_STATUS_SUSPENDED, "forced shutdown");
//                      my_CF.serverRemove();
//                      test_mode = 2;
//                    }
//                }
//              else if (test_mode == 1)
//                {
//                  my_CF.CreateInstance(0, IID_IUnknown, (void **)&cli);
//                }
//              else
//                {
//                  puts("DISCONNECT initiated...");
//                  loSetState(my_service, 0, loOP_STOP | loOP_DISCONNECT,
//                             OPC_STATUS_SUSPENDED, "forced shutdown");
//                }
//            }
//        } /* end of if (test_mode... */
//    } /* end of loop */
//
//  if (0 == my_CF.is_out_of_proc) /* For in-proc servers only! */
//    {
//      EnterCriticalSection(&my_CF.lk_count);
//      driver_destroy();
//      LeaveCriticalSection(&my_CF.lk_count);
//    }
//  
//  UL_MESSAGE((log,0, "All clean. exiting..."));
//}
//


/***************************************************************************
 DLL-specefic stuff
 ***************************************************************************/

//static void dll_simulator_wait(void) /* in-proc specefic */
//{
//  for(;;) 
//    {
//      int finished;
//      EnterCriticalSection(&my_CF.lk_count); 
//      finished = my_service == 0 || my_CF.server_inuse;
//      LeaveCriticalSection(&my_CF.lk_count);
//      if (finished) break;
//      else Sleep(500);
//    }
//  /* Looking for conditional variables?
//     See unilog/condsb.[hc] */
//}
//
//static void dll_simulator_start(void) /* in-proc specefic */
//{
//  int rv;
//  EnterCriticalSection(&my_CF.lk_count);
//  if (!my_service)
//    {
//      if (rv = driver_init( /* inproc only options! */
//#if 1
//               loDf_FREEMARSH | loDf_BOTHMODEL
//#else
//               0
//#endif
//        ))
//        {
//           UL_ERROR((log,0, "!%e driver_init FAILED:", rv));
//        }
//      else if (-1 == (int)_beginthread((void(*)(void *))simulate, 0, (void *)0))
//        {
//           UL_ERROR((log,0, "!%E _beginthread() FAILED:"));
//           driver_destroy();
//        }
//      else my_CF.server_inuse = 1;
//    }
//
//  LeaveCriticalSection(&my_CF.lk_count);  
//}

HMODULE server_module = 0;

extern "C"
  BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
  if (fdwReason == DLL_PROCESS_ATTACH)
    {
      server_module = hinstDLL;

      log = unilog_Create("LOPC-dll", "|LOPC-dll", "%!T", -1,   /* Max filesize: -1 unlimited, -2 -don't change */
                          ll_DEBUG);    /* level [ll_FATAL...ll_DEBUG] */
      unilog_Redirect("LOPC-dll", "LightOPC", 0);
      unilog_Delete(log);
      log = unilog_Create("GrOPC-dll", "|GrOPC-dll", "", -1,        /* Max filesize: -1 unlimited, -2 -don't change */
                          ll_DEBUG);    /* level [ll_FATAL...ll_DEBUG] */
      UL_DEBUG((log,0, "DllMain(process_attach)"));
      //driver_init();    /* not the best place */



  loDriver ld;

//  setlocale(LC_CTYPE, "");

  if (gr_service) 
    {
      UL_ERROR((log,0, "Driver already initialized!"));
      return 0;
    }

  memset(&ld, 0, sizeof(ld));   /* basic server parameters: */
//  ld.ldRefreshRate = 3;//10;
//  ld.ldSubscribe = activation_monitor;
//  ld.ldWriteTags = WriteTags;
//  ld.ldReadTags = ReadTags;
//  ld.ldConvertTags = ConvertTags;
//#if 0
//  ld.ldAskItemID = AskItemID;
//#endif
  ld.ldFlags = loDF_IGNCASE |  /*loDf_FREEMARSH | loDf_BOTHMODEL | */
    /*loDF_NOCOMP| */ loDf_NOFORCE & 0 /*| loDF_SUBSCRIBE_RAW*/;
    /*Fix the Bug in ProTool *//*|loDF_IGNCASE */ ;
  ld.ldBranchSep = '/'; /* Hierarchial branch separator */

  loServiceCreate(&gr_service, &ld, 64 /* number of tags in the cache */);
//  UL_ERROR((log,0, "��� loServiceCreate"));
//
//  VARIANT var;
//  loTagId tti;
//  int ecode;
//
//	VariantInit(&var);
//  ecode = loAddRealTag(gr_service,    /* actual service context */
//                         &tti,  /* returned TagId */
//                         (loRealTag)1,     /* != 0  driver's key */
//                         "Just the hint",   /* tag name (hint) */
//                         0,     /* loTF_ Flags */
//                         OPC_READABLE | OPC_WRITEABLE, &var, 0, 0);
//
//  V_I1(&var) = -1; /* the good practice: set the value first, then type. */
//  V_VT(&var) = VT_I1; /* Do you know why? */
//


    }
  else if (fdwReason == DLL_PROCESS_DETACH)
    {

      UL_DEBUG((log,0, "DllMain(process_detach)"));
      unilog_Delete(log);
      log = 0;
      //driver_destroy(); /* not the best place */

			loServiceDestroy(gr_service);
			gr_service=0;
    }

  return TRUE;
}

STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID *ppv)
{
  UL_DEBUG((log,0, "DllGetClassObject() ..."));

  if (rclsid == CLSID_GranitOPCServer)
    {
      HRESULT hr = Gr_CF.QueryInterface(riid, ppv);
      UL_DEBUG((log,0, "%!l DllGetClassObject() >>%04X %s", hr, hr,
                FAILED(hr) ? "failed" : "Ok"));
      return hr;
    }
  UL_DEBUG((log,0, "DllGetClassObject() >>CLASS_E_CLASSNOTAVAILABLE"));
  return CLASS_E_CLASSNOTAVAILABLE;
}

STDAPI DllCanUnloadNow(void)
{
  UL_DEBUG((log,0, "DllCanUnloadNow() invoked servers=%d", Gr_CF.server_count));
//  Gr_CF.serverAdd();
//  Gr_CF.serverRemove(); /* Force stopping the simulator if not used */
/* the simulator can be restarted in ICF::CreateInstance() if requested */
//  if (0 == Gr_CF.server_inuse) 
//    {
//      dll_simulator_wait();
      if (0 == Gr_CF.server_inuse) return S_OK;
//    }
  return S_FALSE;
}

/* standard OLE registration stuff */

const char dClsidName[] = "GranitOPC server";
const char dProgID[] = "OPC.GranitCenter";

STDAPI DllRegisterServer(void)
{
  char sFile[FILENAME_MAX + 16];
  GetModuleFileName(server_module, sFile, sizeof(sFile) - 1);
  UL_DEBUG((log,0, "DllRegister(%s)", sFile));
  return loServerRegister(&CLSID_GranitOPCServer, dProgID, dClsidName, sFile,
          "Both") ? SELFREG_E_CLASS: S_OK;
}

STDAPI DllUnregisterServer(void)
{
  return loServerUnregister(&CLSID_GranitOPCServer, dProgID)? SELFREG_E_CLASS: S_OK;
}



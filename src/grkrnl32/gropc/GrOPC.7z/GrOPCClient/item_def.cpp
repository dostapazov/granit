//---------------------------------------------------------------------------


#pragma hdrstop

#include "item_def.h"
#include "opcconst.c"

//---------------------------------------------------------------------------

#pragma package(smart_init)

__fastcall TItemDef::TItemDef(void) 
{
  Address.addr=0;
  Object=0;
  Mask=0;
  Handle=0;
  VariantInit(&Value);
  CoFileTimeNow(&TimeStamp);
  Quality = OPC_QUALITY_BAD;
}

__fastcall TItemDef::~TItemDef(void)
{
  VariantClear(&Value);
}

DWORD __fastcall TItemDef::GetMaskedValue()
{
  DWORD ret=0;
  if (Mask)
  {
    ret=Value.ulVal & Mask;
    DWORD m=Mask;
    for (int i=0; i<32; i++)
    {
      if (m & 0x00000001) break;
      m>>=1;
      ret>>=1;
    }
  }
  else
    ret=Value.ulVal;
  return ret;
}

AnsiString __fastcall TItemDef::ToString()
{
  AnsiString s;
  if (Mask)
    s.sprintf("{%3d.%3d.%3d.%3d.%3d}%s{%d}",Address.pu,Address.cp,Address.fa,Address.sb,Object,Name,Mask);
  else
    s.sprintf("{%3d.%3d.%3d.%3d.%3d}%s",Address.pu,Address.cp,Address.fa,Address.sb,Object,Name);
  return s;
}

bool __fastcall TItemDef::FromString(AnsiString s)
{
  AnsiString ss,st=s;
  DWORD pos;
  if (st.SubString(1,1)!="{") return false;
  st.Delete(1,1);
  if (pos=st.Pos("."))
  {
    ss=st.SubString(1,pos-1);
    Address.pu=ss.ToIntDef(0);
  }
  else
    return false;
  st.Delete(1,pos);
  if (pos=st.Pos("."))
  {
    ss=st.SubString(1,pos-1);
    Address.cp=ss.ToIntDef(0);
  }
  else
    return false;
  st.Delete(1,pos);
  if (pos=st.Pos("."))
  {
    ss=st.SubString(1,pos-1);
    Address.fa=ss.ToIntDef(0);
  }
  else
    return false;
  st.Delete(1,pos);
  if (pos=st.Pos("."))
  {
    ss=st.SubString(1,pos-1);
    Address.sb=ss.ToIntDef(0);
  }
  else
    return false;
  st.Delete(1,pos);
  if (pos=st.Pos("}"))
  {
    ss=st.SubString(1,pos-1);
    Object=ss.ToIntDef(0);
  }
  else
    return false;
  st.Delete(1,pos);
  if (pos=st.Pos("{"))
  {
    Name=st.SubString(1,pos-1);
    st.Delete(1,pos);
    if (pos=st.Pos("}"))
    {
      ss=st.SubString(1,pos-1);
      Mask=ss.ToIntDef(0);
    }
    else
      return false;
  }
  else
  {
    Name=st;
    Mask=0;
  }
  return true;
}


//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "opcclientmdm_wnd.h"
#include "../item_def.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TOPCClientWnd *OPCClientWnd;
//---------------------------------------------------------------------------
__fastcall TOPCClientWnd::TOPCClientWnd(TComponent* Owner,HWND parent,GKHANDLE mod)
        : TGKModuleForm(Owner,parent,mod)
{
  Server=NULL;
  Browser=NULL;
  StringGrid1->Cells[0][0]="��";
  StringGrid1->Cells[1][0]="��";
  StringGrid1->Cells[2][0]="��";
  StringGrid1->Cells[3][0]="���";
  StringGrid1->Cells[4][0]="���";
  StringGrid1->Cells[5][0]="��� ����";
  StringGrid1->Cells[6][0]="�����";
  NoRows=true;
}

__fastcall TOPCClientWnd::~TOPCClientWnd()
{
  if (Server)
  {
    delete Browser;
    Browser=NULL;
    delete Server;
    Server=NULL;
  }
  Disconnect();
}
//---------------------------------------------------------------------------

void  __fastcall TOPCClientWnd::on_module_state(GKHANDLE mod,DWORD state)
{
  bool running = ((state & MODULE_STATE_RUNNING_MASK )== MODULE_STATE_RUNNING) ? true:false;
  bool stopped  = (state & MODULE_STATE_RUNNING_MASK ) ? false:true;
  StartBtn->Enabled = stopped;
  StopBtn->Enabled  = running;
  if(running)
     StatusBar1->Panels->Items[0]->Text =  "��������";
  if(stopped)
     StatusBar1->Panels->Items[0]->Text =  "����������";
}

void     __fastcall TOPCClientWnd::on_module_config_change(GKHANDLE mod,LPMODULE_CONFIG_DATA mcd)
{
  LPOCSETTINGS ocs =(LPOCSETTINGS)mcd->data;
  if(mcd->mask&CCFL_MODEM_NUMBER)
    settings.modem_number = ocs->modem_number;
  if(mcd->mask&CCFL_SRVNAME)
    safe_strcpy(settings.srv_name,ocs->srv_name);
  if(mcd->mask&CCFL_CFGNAME)
    safe_strcpy(settings.cfg_name,ocs->cfg_name);
  if(mcd->mask&CCFL_RATE)
    settings.rate=ocs->rate;
  if(mcd->mask&CCFL_DEADBAND)
    settings.dead_band=ocs->dead_band;

  setup_config_controls();
}

void     __fastcall TOPCClientWnd::after_set_gkhandle()
{
  TGKModuleForm::after_set_gkhandle();
  if(get_settings())
     setup_config_controls();
  on_module_state(mod_iface(),mod_iface.get_module_state());
  set_notify(mod_iface(),MNF_COMMON);
}

void __fastcall TOPCClientWnd::setup_config_controls()
{
  ModemNumber->Position = settings.modem_number;
  CBServer->Text        = settings.srv_name;
  CfgName->Text         = settings.cfg_name;
  EdRate->Text          = settings.rate;
  EdDeadBand->Text      = settings.dead_band;

  chmask = 0;
}

bool  __fastcall TOPCClientWnd::get_settings()
{
  LPMODULE_CONFIG_DATA mcd;
  BYTE buffer[sizeof(*mcd)+sizeof(OCSETTINGS)];
  mcd = (LPMODULE_CONFIG_DATA)buffer;
  mcd->dw_sz = sizeof(buffer);
  mcd->mask  = -1;
  LPOCSETTINGS ocs =(LPOCSETTINGS)mcd->data;
  ZeroMemory(ocs,sizeof(*ocs));
  ocs->dw_size = sizeof(*ocs);
  if(mod_iface.get_config_data(mcd,mcd->dw_sz))
  {
    memcpy(&settings,ocs,sizeof(settings));
    return true;
  }
  return false;
}

void __fastcall TOPCClientWnd::ModemNumberChangingEx(TObject *Sender,
      bool &AllowChange, short NewValue, TUpDownDirection Direction)
{
  if(settings.modem_number!=(DWORD) NewValue)
  {
    chmask|=CCFL_MODEM_NUMBER;
  }
  else
    chmask&=~CCFL_MODEM_NUMBER;
  ModemNumberEdit->Font->Color = (chmask&CCFL_MODEM_NUMBER) ? clHotLight:clDefault;
}
//---------------------------------------------------------------------------

void __fastcall TOPCClientWnd::Setchmask(DWORD value)
{
  if(Fchmask!=value)
    Fchmask = value;
  ApplyBtn->Enabled = value ? true:false;
  UndoBtn ->Enabled = value ? true:false;
}
void __fastcall TOPCClientWnd::StartBtnClick(TObject *Sender)
{
  handle_call_result(mod_iface.start(MODULE_START_REQUEST,0));
}
//---------------------------------------------------------------------------

void __fastcall TOPCClientWnd::StopBtnClick(TObject *Sender)
{
  handle_call_result(mod_iface.stop(MODULE_STOP_REQUEST));
}
//---------------------------------------------------------------------------

void __fastcall TOPCClientWnd::ApplyBtnClick(TObject *Sender)
{
  WideString wstr;
  LPMODULE_CONFIG_DATA mcd;
  BYTE buffer[sizeof(*mcd)+sizeof(OCSETTINGS)];
  mcd = (LPMODULE_CONFIG_DATA)buffer;
  mcd->dw_sz = sizeof(buffer);
  mcd->mask  = chmask;
  LPOCSETTINGS ocs =(LPOCSETTINGS)mcd->data;
  ZeroMemory(ocs,sizeof(*ocs));
  ocs->dw_size = sizeof(*ocs);
  memcpy(ocs,&settings,sizeof(settings));
  if(chmask&CCFL_MODEM_NUMBER)
    ocs->modem_number = ModemNumber->Position;
  if(chmask&CCFL_SRVNAME)
  {
    wstr = CBServer->Text;
    safe_strcpy(ocs->srv_name,wstr.c_bstr());
  }
  if(chmask&CCFL_CFGNAME)
  {
    wstr = CfgName->Text;
    safe_strcpy(ocs->cfg_name,wstr.c_bstr());
  }
  if(chmask&CCFL_RATE)
  {
    ocs->rate=(DWORD)EdRate->Text.ToIntDef(1000);
  }
  if(chmask&CCFL_DEADBAND)
  {
    ocs->dead_band=EdDeadBand->Text.ToDouble();
  }

  mod_iface.set_config_data(mcd,sizeof(buffer));
}
//---------------------------------------------------------------------------

void __fastcall TOPCClientWnd::UndoBtnClick(TObject *Sender)
{
  if(get_settings())
    setup_config_controls();
}
//---------------------------------------------------------------------------

void __fastcall TOPCClientWnd::handle_call_result(LRESULT ret)
{
  wchar_t err_text[MAX_PATH];
  err_text[0] =0;
  mod_iface.get_error_text(GetLastError(),err_text,sizeof(err_text)/sizeof(wchar_t));
  StatusBar1->Panels->Items[1]->Text = err_text;
}


void __fastcall TOPCClientWnd::CBServerDropDown(TObject *Sender)
{
  TOPCEnum e;
  e.EnumProgId(CBServer->Items, TOPCEnum::OPC_DA);
}
//---------------------------------------------------------------------------

void __fastcall TOPCClientWnd::CBServerChange(TObject *Sender)
{
  AnsiString str = settings.srv_name;
  if(str.AnsiCompareIC(CBServer->Text))
  {
    chmask|=CCFL_SRVNAME;
  }
  else
    chmask&=~CCFL_SRVNAME;
  CBServer->Font->Color = (chmask&CCFL_SRVNAME) ? clHotLight:clDefault;
}
//---------------------------------------------------------------------------

void __fastcall TOPCClientWnd::SpeedButton2Click(TObject *Sender)
{
  OpenDialog1->FileName=CfgName->Text;
  if(OpenDialog1->Execute())
  {
    CfgName->Text = OpenDialog1->FileName;
  }
}
//---------------------------------------------------------------------------

void __fastcall TOPCClientWnd::CfgNameChange(TObject *Sender)
{
  AnsiString str = settings.cfg_name;
  if(str.AnsiCompareIC(CfgName->Text))
  {
    chmask|=CCFL_CFGNAME;
  }
  else
    chmask&=~CCFL_CFGNAME;
  CfgName->Font->Color = (chmask&CCFL_CFGNAME) ? clHotLight:clDefault;
}
//---------------------------------------------------------------------------

void __fastcall TOPCClientWnd::Button1Click(TObject *Sender)
{
  if (!Server)
  {
    Server = new TOPCServer(CBServer->Text);
    Browser = new TOPCBrowser(Server);
  }
  Browser->FillTree(TreeView1->Items);
}
//---------------------------------------------------------------------------

void __fastcall TOPCClientWnd::AddBtnClick(TObject *Sender)
{
  if(!Browser) return;
  if(!TreeView1->Items->Count) return;
  if(TreeView1->Selected->HasChildren) return;
  TStringList *names=new TStringList();
  TStringList *ids=new TStringList();
  Browser->FillList(TreeView1->Selected->Parent,names,ids);
  if(NoRows)
  {
    NoRows=false;
    StringGrid1->Cells[0][1]="1";
    StringGrid1->Cells[1][1]="1";
    StringGrid1->Cells[2][1]="1";
    StringGrid1->Cells[3][1]="1";
    StringGrid1->Cells[4][1]="1";
    StringGrid1->Cells[5][1]=ids->Strings[names->IndexOf(TreeView1->Selected->Text)]; //def->Name;
  }
  else
  {
    StringGrid1->RowCount++;
    int i=StringGrid1->RowCount-1;
    StringGrid1->Rows[i]=StringGrid1->Rows[i-1];
    StringGrid1->Cells[4][i]=StringGrid1->Cells[4][i-1].ToIntDef(0)+1;
    StringGrid1->Cells[5][i]=ids->Strings[names->IndexOf(TreeView1->Selected->Text)];  //def->Name;
  }
  delete ids;
  delete names;
}
//---------------------------------------------------------------------------

void __fastcall TOPCClientWnd::DelBtnClick(TObject *Sender)
{
  if(NoRows) return;
  int i=StringGrid1->Row;
  if (StringGrid1->RowCount==2)
  {
    StringGrid1->Rows[1]->Clear();
    NoRows=true;
  }
  else
  {
    for(int j=i+1; j<StringGrid1->RowCount; j++)
      StringGrid1->Rows[j-1]=StringGrid1->Rows[j];
    StringGrid1->RowCount--;
  }
}
//---------------------------------------------------------------------------

void __fastcall TOPCClientWnd::StringGrid1SelectCell(TObject *Sender,
      int ACol, int ARow, bool &CanSelect)
{
  if(ACol==5) CanSelect=false;
  if(NoRows) CanSelect=false;
}
//---------------------------------------------------------------------------

void __fastcall TOPCClientWnd::TreeView1DblClick(TObject *Sender)
{
  if(!TreeView1->Selected->HasChildren) AddBtnClick(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TOPCClientWnd::UpBtnClick(TObject *Sender)
{
  int i=StringGrid1->Row;
  if(i<2) return;
  AnsiString tmp=StringGrid1->Rows[i-1]->Text;
  StringGrid1->Rows[i-1]=StringGrid1->Rows[i];
  StringGrid1->Rows[i]->Text=tmp;
  StringGrid1->Row--;
}
//---------------------------------------------------------------------------

void __fastcall TOPCClientWnd::DownBtnClick(TObject *Sender)
{
  int i=StringGrid1->Row;
  if(i>StringGrid1->RowCount-2) return;
  AnsiString tmp=StringGrid1->Rows[i+1]->Text;
  StringGrid1->Rows[i+1]=StringGrid1->Rows[i];
  StringGrid1->Rows[i]->Text=tmp;
  StringGrid1->Row++;
}
//---------------------------------------------------------------------------

void __fastcall TOPCClientWnd::SaveBtnClick(TObject *Sender)
{
  if(NoRows) return;
  TStringList *sl=new TStringList;
  TItemDef *def=new TItemDef;
  for(int i=1; i<StringGrid1->RowCount; i++)
  {
    def->Address.pu=StringGrid1->Cells[0][i].ToIntDef(0);
    def->Address.cp=StringGrid1->Cells[1][i].ToIntDef(0);
    def->Address.fa=StringGrid1->Cells[2][i].ToIntDef(0);
    def->Address.sb=StringGrid1->Cells[3][i].ToIntDef(0);
    def->Object=StringGrid1->Cells[4][i].ToIntDef(0);
    def->Name=StringGrid1->Cells[5][i];
    def->Mask=StringGrid1->Cells[6][i].ToIntDef(0);
    sl->Add(def->ToString());
  }
  sl->SaveToFile(settings.cfg_name);
  delete def;
  delete sl;
}
//---------------------------------------------------------------------------

void __fastcall TOPCClientWnd::LoadBtnClick(TObject *Sender)
{
  if(!NoRows)
  {
    StringGrid1->RowCount=2;
    StringGrid1->Rows[1]->Clear();
    NoRows=true;
  }
  TStringList *sl=new TStringList;
  TItemDef *def=new TItemDef;
  sl->LoadFromFile(settings.cfg_name);
  int num=0;
  for(int i=0; i<sl->Count; i++)
  {
    if(def->FromString(sl->Strings[i]))
    {
      num++;
      StringGrid1->RowCount=num+1;
      StringGrid1->Cells[0][num]=def->Address.pu;
      StringGrid1->Cells[1][num]=def->Address.cp;
      StringGrid1->Cells[2][num]=def->Address.fa;
      StringGrid1->Cells[3][num]=def->Address.sb;
      StringGrid1->Cells[4][num]=def->Object;
      StringGrid1->Cells[5][num]=def->Name;
      if(def->Mask) StringGrid1->Cells[6][num]=def->Mask;
    }
  }
  if(num) NoRows=false;
  delete def;
  delete sl;
}
//---------------------------------------------------------------------------

void __fastcall TOPCClientWnd::OnChange(TAsyncOPCGroup *group, int count, int *i)
{
  SYSTEMTIME st;
  TListItem *li;
  Variant v;
  DWORD d;
  double r;
  AnsiString s;
  for (int j = 0; j < count; ++j)
  {
    li = ListView1->Items->Item[i[j]];
    v=group->Value[i[j]];
    switch(v.Type())
    {
      case varByte:
      case varWord:
      case varLongWord:
        d=v;
        if(CBMask->Checked)
        {
          DWORD m=(DWORD)li->Data;
          d=d & m;
          for (int i=0; i<32; i++)
          {
            if (m & 0x00000001) break;
            m>>=1;
            d>>=1;
          }
        }
        li->SubItems->Strings[0]=d;
        break;
      case varSingle:
      case varDouble:
      case varCurrency:
        r=v;
        s.sprintf("%.3f",r);
        li->SubItems->Strings[0]=s;
        break;
      default: li->SubItems->Strings[0]=VarToStr(v);
    }
    li->SubItems->Strings[1]=group->Time[i[j]].FormatString(
            "dd\".\"mm\".\"yyyy\" \"hh\":\"nn\":\"ss\".\"zzz");
    li->SubItems->Strings[2]=group->Quality[i[j]];
  }
}

void __fastcall TOPCClientWnd::Connect()
{
  ListView1->Items->Clear();
  TStringList *sl=new TStringList;
  TStringList *ids=new TStringList;
  TItemDef *def=new TItemDef;
  TListItem *li;
  sl->LoadFromFile(settings.cfg_name);
  for(int i=0; i<sl->Count; i++)
  {
    if(def->FromString(sl->Strings[i]))
    {
      ids->Add(def->Name);
      li = ListView1->Items->Add();
      li->Caption = def->Name;
      li->SubItems->Add("?");
      li->SubItems->Add("?");
      li->SubItems->Add("?");
      li->Data=(void *)def->Mask;
    }
  }
  delete sl;
  delete def;
  try
  {
    ServerView=new TOPCServer(settings.srv_name);
    Group=new TAsyncOPCGroup(ServerView,ids,"ViewGroup",1000,0);
    Group->OnDataChange = OnChange;
  }
  __finally
  {
    delete ids;
  }

}

void __fastcall TOPCClientWnd::Disconnect()
{
  if (Group)
  {
    delete Group;
    Group=NULL;
  }
  if(ServerView)
  {
    delete ServerView;
    ServerView=NULL;
  }
}



void __fastcall TOPCClientWnd::PageControl1Change(TObject *Sender)
{
  if(PageControl1->ActivePage->Name=="ViewTab")
    Connect();
  else
    Disconnect();
}
//---------------------------------------------------------------------------


void __fastcall TOPCClientWnd::CBMaskClick(TObject *Sender)
{
  if(Group) Group->Refresh(true);
}
//---------------------------------------------------------------------------

void __fastcall TOPCClientWnd::EdRateChange(TObject *Sender)
{
  if(settings.rate!=(DWORD)EdRate->Text.ToIntDef(1000))
  {
    chmask|=CCFL_RATE;
  }
  else
    chmask&=~CCFL_RATE;
  EdRate->Font->Color = (chmask&CCFL_RATE) ? clHotLight:clDefault;
}
//---------------------------------------------------------------------------

void __fastcall TOPCClientWnd::EdDeadBandChange(TObject *Sender)
{
  if(settings.dead_band!=EdDeadBand->Text.ToDouble())
  {
    chmask|=CCFL_DEADBAND;
  }
  else
    chmask&=~CCFL_DEADBAND;
  EdDeadBand->Font->Color = (chmask&CCFL_DEADBAND) ? clHotLight:clDefault;
}
//---------------------------------------------------------------------------


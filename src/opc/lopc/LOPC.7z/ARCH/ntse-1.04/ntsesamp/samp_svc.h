#ifdef __cplusplus
extern "C" {
#endif

/* Translates MSGID to string. 
   Returned string must be freed via LocalFree */

char *system_message(int msgid);

/* Kind of perror(): printf() + error message of ECODE.
   ECODE should be compatible with GetLastError(). */
void print_err(int ecode, const char *fmt, ...);

struct svcHandle;
typedef struct svcHandle svcHandle;

extern unsigned ntseHideConsole(void);

/* Attemt to reduce service control to single function */

extern unsigned svcControlAndSleep(
              svcHandle *ctx,  /* context */   
              unsigned sleep,     /* milliseconds or INFINITE   */
              unsigned nextstate, /* SERVICE_RUNNING etc. */
              unsigned win32err,  /* SERVICE_STATUS::dwWin32ExitCode*/
              unsigned specefic); /* ::dwServiceSpecificExitCode */
/* Wait no longer than SLEEP milliseconds.
   If no SERVICE_CONTROL_* pending and NEXTSTATE != 0 then 
   Set the specified NEXTSTATE and error codes; Returns 0.
   Otherwise Returns SERVICE_CONTROL_*, doesn't set NEXTSTATE.
 */

extern void svcSignal(svcHandle *ctx, unsigned ctl);
/* Awake the svcControlAndSleep() if it waiting;
   send CTL=SERVICE_CONTROL_* if CTL != 0.
 */

extern int svcMain(int argc, char *argv[]); 
/* call it from main() or WinMain() (space-separated arg are ok) */

/** To implement: */
extern int svcRun(svcHandle *ctx, const char *svc_name);
extern int svcRegister(const char *svc_name, const char *run_opt);
extern int svcUnregister(const char *svc_name);

extern const char *svcName;      /* "samp-svc" */
extern const char *svcDescr;     /* "sample service" */
extern const char *svcDependence; /* = NULL, "rpcss\0", etc.. */
extern unsigned svcStartType; /*SERVICE_[DEMAND|AUTO]_START */
extern unsigned svcWaitHint; /* 10000 = 10sec */
extern unsigned svcAcceptCtl; /* SERVICE_ACCEPT_PAUSE_CONTINUE | 
                 SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_SHUTDOWN */
extern int svcIsFakeSCM; /* == 0 if running under real NT's SCM */

#ifdef __cplusplus
  }
#endif

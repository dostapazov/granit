//---------------------------------------------------------------------------
/*
Copyright (c) 2013,2014
Serge L. Ryadkow admin@opcgate.ru http://opcgate.ru
Leonid P. Lebedev llebedev@k-solutions.ru

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be included in all copies
or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.
*/
//---------------------------------------------------------------------------
/*
�����������, ���������� ��������� ������ � ��������� �������� ���������,
�������� ������������� // 2014.07.31 L�
*/
//---------------------------------------------------------------------------
#ifndef OPCClientH
#define OPCClientH
//---------------------------------------------------------------------------
#include <atl\atlbase.h>
#include <ComCtrls.hpp>

#include <opcda.h>

#include "DataCallbackSink.h"
//---------------------------------------------------------------------------
class TOPCServer
{
  public:
    TOPCServer(const AnsiString &server, const AnsiString &host = "");
    ~TOPCServer();
    static TDateTime OPCTimeToDateTime(FILETIME t);
  private:
    IOPCServer *Server;
    CCreatableShutdownCallbackSink ShutdownCallbackSink;
    OPCSERVERSTATE __fastcall GetState();
    TDateTime __fastcall GetStartTime();
    TDateTime __fastcall GetCurrTime();
    TDateTime __fastcall GetLastUpdateTime();
    int __fastcall GetGroupCount();
    int __fastcall GetBandWidth();
    int __fastcall GetMajorVersion();
    int __fastcall GetMinorVersion();
    int __fastcall GetBuildNumber();
    AnsiString __fastcall GetVendorInfo();
    void __fastcall DoShutdown(/* [in] */ LPCWSTR szReason);
    void __fastcall (__closure *FOnShutdown)(TOPCServer *server,
                                             AnsiString reason);
  public:
    __property OPCSERVERSTATE State = { read=GetState };
    __property TDateTime StartTime = { read=GetStartTime };
    __property TDateTime CurrentTime = { read=GetCurrTime };
    __property TDateTime LastUpdateTime = { read=GetLastUpdateTime };
    __property int GroupCount = { read=GetGroupCount };
    __property int BandWidth = { read=GetBandWidth };
    __property int MajorVersion = { read=GetMajorVersion };
    __property int MinorVersion = { read=GetMinorVersion };
    __property int BuildNumber = { read=GetBuildNumber };
    __property AnsiString VendorInfo = { read=GetVendorInfo };
    __property void __fastcall (__closure *OnShutdown)(TOPCServer *server,
                                                       AnsiString reason) =
      { read = FOnShutdown, write = FOnShutdown };
  friend class TOPCGroup;
  friend class TOPCBrowser;
};
//---------------------------------------------------------------------------
class TOPCBrowser
{
  public:
    __fastcall TOPCBrowser(TOPCServer *server);
    __fastcall ~TOPCBrowser();
    void __fastcall FillTree(TTreeNodes *nodes, TTreeNode *root = 0);
    template <class T> void __fastcall FillTreeObj(TTreeNodes *nodes,
    		TTreeNode *root = 0);
    void __fastcall FillGroupTree(TTreeNodes *nodes, TTreeNode *root = 0);
    int __fastcall FillList(TStrings *sl);
    int __fastcall FillList(TTreeNode *node, TStrings *names, TStrings *ids);
  private:
    IOPCBrowseServerAddressSpace *Browser;
    OPCNAMESPACETYPE __fastcall GetOrganization();
    bool __fastcall GetIsFlat() {
      return Organization == OPC_NS_FLAT;
    }
    bool __fastcall GetIsHierarchial() {
      return Organization == OPC_NS_HIERARCHIAL;
    }
    void __fastcall FillTreeP(TTreeNodes *nodes, TTreeNode *node);
    template <class T> void __fastcall FillTreeObjP(TTreeNodes *nodes,
    		TTreeNode *node);
    void __fastcall FillGroupTreeP(TTreeNodes *nodes, TTreeNode *node);
    void __fastcall FillListP(TStrings *sl);
    void __fastcall GoDown(const AnsiString &s);
    void __fastcall GoUp(const AnsiString &s);
    void __fastcall GoTo(const AnsiString &s);
    int __fastcall GetGroups(TStrings *sl);
    int __fastcall GetTags(TStrings *sl);
    int __fastcall GetFlat(TStrings *sl);
    AnsiString GetItemId(const AnsiString &item);
  public:
    __property OPCNAMESPACETYPE Organization = { read=GetOrganization };
    __property bool IsFlat = { read=GetIsFlat };
    __property bool IsHierarchial = { read=GetIsHierarchial };

};
//---------------------------------------------------------------------------
class TOPCGroup
{
  public:
    TOPCGroup(TOPCServer *server, TStrings* tl, const AnsiString &name,
              int rate = 0, float deadBand = 0);
    virtual ~TOPCGroup();
    void Read(bool fromDevice);
    virtual void Read();
    virtual void Write(int i, const Variant &value);
  protected:
    TOPCServer *Server;
    int FRate;
    float FDeadBand;
    DWORD Handle;
    IUnknown    *Group;
    IOPCSyncIO  *SyncIO;
    IOPCItemMgt *ItemMgt;
    DWORD *ItemHandles;
    int FCount;
    Variant *Values;
    TDateTime *Times;
    int *Qualities;
    // 2014.07.31 L� - ��������� �� ������ ������
    long *Errors;
    Variant GetValue(int i);
    virtual void SetValue(int i, const Variant &value);
    TDateTime GetTime(int i);
    int GetQuality(int i);
    bool GetGood(int i);
    // 2014.07.31 L� - ���������� ��� ������ �������� � �������� i
    long GetError(int i);
    // 2014.07.31 L� - ���������� ������� ���������� ������ ��� �������� � �������� i
    bool GetSucceeded(int i);
  public:
    __property int Count = { read=FCount };
    __property int Rate = { read=FRate };
    __property float DeadBand = { read=FDeadBand };
    __property Variant Value[int i] = { read=GetValue, write=SetValue };
    __property TDateTime Time[int i] = { read=GetTime };
    __property int Quality[int i] = { read=GetQuality };
    __property bool Good[int i] = { read=GetGood };
    // 2014.07.31 L� - ��� ������ �������� � �������� i
    __property long Error[int i] = { read=GetError };
    // 2014.07.31 L� - ������� ���������� ������ ��� �������� � �������� i
    __property bool Succeeded[int i] = { read=GetSucceeded };
};
//---------------------------------------------------------------------------
class TAsyncOPCGroup : public TOPCGroup
{
  public:
    TAsyncOPCGroup(TOPCServer *server, TStrings* tl, const AnsiString &name,
                   int rate = 0, float deadBand = 0);
    virtual ~TAsyncOPCGroup();
    virtual void Read();
    void Refresh(bool fromDevice = false);
    virtual void Write(int i, const Variant &value);
  private:
    IOPCAsyncIO2 *AsyncIO;
    CCreatableDataCallbackSink DataCallbackSink;
    DWORD CancelId;
    virtual void SetValue(int i, const Variant &value);
    void __fastcall DoDataChange(
      /* [in] */ DWORD dwTransid,
      /* [in] */ OPCHANDLE hGroup,
      /* [in] */ HRESULT hrMasterquality,
      /* [in] */ HRESULT hrMastererror,
      /* [in] */ DWORD dwCount,
      /* [size_is][in] */ OPCHANDLE __RPC_FAR *phClientItems,
      /* [size_is][in] */ VARIANT __RPC_FAR *pvValues,
      /* [size_is][in] */ WORD __RPC_FAR *pwQualities,
      /* [size_is][in] */ FILETIME __RPC_FAR *pftTimeStamps,
      /* [size_is][in] */ HRESULT __RPC_FAR *pErrors);
    void __fastcall DoReadComplete(
      /* [in] */ DWORD dwTransid,
      /* [in] */ OPCHANDLE hGroup,
      /* [in] */ HRESULT hrMasterquality,
      /* [in] */ HRESULT hrMastererror,
      /* [in] */ DWORD dwCount,
      /* [size_is][in] */ OPCHANDLE __RPC_FAR *phClientItems,
      /* [size_is][in] */ VARIANT __RPC_FAR *pvValues,
      /* [size_is][in] */ WORD __RPC_FAR *pwQualities,
      /* [size_is][in] */ FILETIME __RPC_FAR *pftTimeStamps,
      /* [size_is][in] */ HRESULT __RPC_FAR *pErrors);
    void __fastcall DoWriteComplete(
      /* [in] */ DWORD dwTransid,
      /* [in] */ OPCHANDLE hGroup,
      /* [in] */ HRESULT hrMastererr,
      /* [in] */ DWORD dwCount,
      /* [size_is][in] */ OPCHANDLE __RPC_FAR *pClienthandles,
      /* [size_is][in] */ HRESULT __RPC_FAR *pErrors);
    void __fastcall DoCancelComplete(
      /* [in] */ DWORD dwTransid,
      /* [in] */ OPCHANDLE hGroup);
    void __fastcall (__closure *FOnDataChange)(TAsyncOPCGroup *group,
                                               int count, int *i);
    void __fastcall (__closure *FOnReadComplete)(TAsyncOPCGroup *group);
    void __fastcall (__closure *FOnWriteComplete)(TAsyncOPCGroup *group);
    void __fastcall (__closure *FOnCancelComplete)(TAsyncOPCGroup *group);
  public:
    __property void __fastcall (__closure *OnDataChange)(TAsyncOPCGroup *group,
                                                         int count, int *i) =
      { read = FOnDataChange, write = FOnDataChange };
    __property void __fastcall (__closure *OnReadComplete)(TAsyncOPCGroup *group) =
      { read = FOnReadComplete, write = FOnReadComplete };
    __property void __fastcall (__closure *OnWriteComplete)(TAsyncOPCGroup *group) =
      { read = FOnWriteComplete, write = FOnWriteComplete };
    __property void __fastcall (__closure *OnCancelComplete)(TAsyncOPCGroup *group) =
      { read = FOnCancelComplete, write = FOnCancelComplete };
};
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
template <class T>
void __fastcall TOPCBrowser::FillTreeObj(TTreeNodes *nodes, TTreeNode *root)
{
  if (!root)
	  nodes->Clear();
  if (IsFlat) {
    TStringList *sl = new TStringList;
    try {
      GetFlat(sl);
      for (int i = 0; i < sl->Count; ++i)
        nodes->AddChildObject(root, sl->Strings[i], new T());
    }
    __finally {
      delete sl;
    }
  } else
    FillTreeObjP<T>(nodes, root);
}
//---------------------------------------------------------------------------
template <class T>
void __fastcall TOPCBrowser::FillTreeObjP(TTreeNodes *nodes, TTreeNode *node)
{
  TStringList *sl = new TStringList;
  try {
    GetGroups(sl);
    for (int i = 0; i < sl->Count; ++i) {
      TTreeNode *n = nodes->AddChild(node, sl->Strings[i]);
      GoDown(sl->Strings[i]);
      try {
        FillTreeObjP<T>(nodes, n);
      }
      __finally {
        GoUp(sl->Strings[i]);
      }
    }
    GetTags(sl);
    for (int i = 0; i < sl->Count; ++i)
      nodes->AddChildObject(node, sl->Strings[i], new T());
  }
  __finally {
    delete sl;
  }
}
//---------------------------------------------------------------------------
#endif //OPCClientH

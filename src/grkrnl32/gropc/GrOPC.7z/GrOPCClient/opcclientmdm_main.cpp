//---------------------------------------------------------------------------

#pragma hdrstop

#include "opcclient_modem.h"
#pragma package(smart_init)
//---------------------------------------------------------------------------
static THeap heap(TSysInfo().GetPageSize()<<8); // 512 ��
static DWORD total_mem_alloc = 0;

void * operator new(size_t sz)
{
  void * ptr = heap.Alloc(sz);
  if (ptr) total_mem_alloc+= heap.MemSize(ptr,0);
  return ptr;
}

void * operator new [](size_t sz)
{
  void * ptr = heap.Alloc(sz);
  if (ptr) total_mem_alloc+= heap.MemSize(ptr,0);
  return ptr;
}

void operator delete( void * ptr)
{
  if(ptr && heap.Validate(ptr))
  {
     total_mem_alloc-= heap.MemSize(ptr,0);
     heap.Free(ptr);
  }
}

void operator delete[]( void * ptr)
{
  if(ptr && heap.Validate(ptr))
  {
    total_mem_alloc-= heap.MemSize(ptr,0);
    heap.Free(ptr);
  }
}

DWORD __fastcall TOPCClientModem::get_mem_used()
{
  return total_mem_alloc;
}

LRESULT WINAPI module_main(DWORD cmd ,LPARAM,LPARAM)
{
  LRESULT ret = NULL;

  switch(cmd)
  {
    case GKME_CMD_GET_MODULETYPE: ret = MT_MODEM;break;
    case GKME_CMD_CREATE_HANDLE :
    {
      TOPCClientModem * modem = new TOPCClientModem;
      ret  = (LRESULT)(*modem)();
      if(!ret)
        delete modem;
    }
    break;
  }
  return ret;
}


 
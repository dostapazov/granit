//---------------------------------------------------------------------------
/*
Object oriented shell for LightOPC library
Copyright (C) 2012 Serge L. Ryadkow

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

Contacts:
admin@opcgate.ru
http://opcgate.ru
*/
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
#ifndef OPCSrvrH
#define OPCSrvrH
//---------------------------------------------------------------------------
#include <lightopc.h>

#include "OPCClsFact.h"
//---------------------------------------------------------------------------
/* application must implement next constant (example):
const char OPCClsID[] = "LightOPC Sample server (exe)";
const char OPCProgID[] = "OPC.LightOPC-exe";
const loVendorInfo OPCVendor = {
  3, //Major
  2, //Minor
  1, //Build
  0, //Reserv
  "Sample OPC Server #9"
};
// {4EA2713D-CA07-11d4-BEF5-00002120DB5C}
const GUID OPCGUID =
  { 0x4ea2713d, 0xca07, 0x11d4, {0xbe, 0xf5, 0x0, 0x0, 0x21, 0x20, 0xdb,
                                 0x5c} };
*/
//---------------------------------------------------------------------------
class TOPCSrvr {
public:
  static void __fastcall Register();
  static void __fastcall UnRegister();
  __fastcall TOPCSrvr(int tagCnt, int refRate = 0, int flags = 0);
  __fastcall ~TOPCSrvr();
  void __fastcall Start();
  void __fastcall Add(int id, const char *name, VARTYPE vt,
      int access = OPC_READABLE);
  void __fastcall AddBool(int id, const char *name, int access = OPC_READABLE);
  void __fastcall AddByte(int id, const char *name, int access = OPC_READABLE);
  void __fastcall AddUByte(int id, const char *name, int access = OPC_READABLE);
  void __fastcall AddShort(int id, const char *name, int access = OPC_READABLE);
  void __fastcall AddUShort(int id, const char *name, int access = OPC_READABLE);
  void __fastcall AddLong(int id, const char *name, int access = OPC_READABLE);
  void __fastcall AddULong(int id, const char *name, int access = OPC_READABLE);
  void __fastcall AddFloat(int id, const char *name, int access = OPC_READABLE);
  void __fastcall AddDouble(int id, const char *name, int access = OPC_READABLE);
  void __fastcall SetBool(int id, bool val, FILETIME *time = 0,
      int qual = OPC_QUALITY_GOOD);
  void __fastcall SetByte(int id, char val, FILETIME *time = 0,
      int qual = OPC_QUALITY_GOOD);
  void __fastcall SetUByte(int id, unsigned char val, FILETIME *time = 0,
      int qual = OPC_QUALITY_GOOD);
  void __fastcall SetShort(int id, short val, FILETIME *time = 0,
      int qual = OPC_QUALITY_GOOD);
  void __fastcall SetUShort(int id, unsigned short val, FILETIME *time = 0,
      int qual = OPC_QUALITY_GOOD);
  void __fastcall SetLong(int id, long val, FILETIME *time = 0,
      int qual = OPC_QUALITY_GOOD);
  void __fastcall SetULong(int id, unsigned long val, FILETIME *time = 0,
      int qual = OPC_QUALITY_GOOD);
  void __fastcall SetFloat(int id, float val, FILETIME *time = 0,
      int qual = OPC_QUALITY_GOOD);
  void __fastcall SetDouble(int id, double val, FILETIME *time = 0,
      int qual = OPC_QUALITY_GOOD);
  bool __fastcall GetBool(int id);
  char __fastcall GetByte(int id);
  unsigned char __fastcall GetUByte(int id);
  short __fastcall GetShort(int id);
  unsigned short __fastcall GetUShort(int id);
  long __fastcall GetLong(int id);
  unsigned long __fastcall GetULong(int id);
  float __fastcall GetFloat(int id);
  double __fastcall GetDouble(int id);
  void __fastcall SetBad(int id, FILETIME *time = 0);
  void __fastcall Flush();
protected:
  loTagValue *TV;
private:
  static int WriteTagsS(const loCaller *ca, unsigned count, loTagPair taglist[],
      VARIANT values[], HRESULT error[], HRESULT *master, LCID lcid);
  static loTrid ReadTagsS(const loCaller *ca, unsigned count, loTagPair taglist[],
      VARIANT *values, WORD *qualities, FILETIME *stamps, HRESULT *errs,
      HRESULT *master_err, HRESULT *master_qual, const VARTYPE vtypes[],
      LCID lcid);
  virtual int WriteTags(const loCaller *ca, unsigned count, loTagPair taglist[],
      VARIANT values[], HRESULT error[], HRESULT *master, LCID lcid);
  virtual loTrid ReadTags(const loCaller *ca, unsigned count, loTagPair taglist[],
      VARIANT *values, WORD *qualities, FILETIME *stamps, HRESULT *errs,
      HRESULT *master_err, HRESULT *master_qual, const VARTYPE vtypes[],
      LCID lcid);
  virtual HRESULT WriteTag(int id, VARIANT &val);
  const int TagCnt;
  DWORD ObjID;
  loDriver Drv;
  CRITICAL_SECTION CS;
};
//---------------------------------------------------------------------------
#endif

/****************************************************************************

 Sample NT service based on ntse.

 Copyright (c) 2000-2003, Timofei Bondarenko, Kostya Volovich.
 ****************************************************************************/
/*
  This sample contains a bit complicated service's code (svc).
  All GUI stuff is optional (dialogs, icons and hooks).
  Arguments parsing in main() is optional too.

  The code is quite reusable for wide range of servers.
  The only thing you have to modify is svc_main() or svcRun().
 */
#include <windows.h>
#include <winsvc.h>
#include <stdarg.h>
#include <string.h>
#include <stdio.h>

#include <ntse.h>
#include "samp_svc.h"
#include "resource.h"

/* Define TEST_SVC=1 if you want a self-consistent sample service. */
#ifndef TEST_SVC
#define TEST_SVC (0)
#endif

/* Basic parameters */
#define SVC_TYPE    SERVICE_WIN32_OWN_PROCESS

#if 0 != TEST_SVC

const char *svcName = "ntse-Sample-SVC";
const char *svcDescr = "ntse sample NT service";

unsigned svcAcceptCtl = (SERVICE_ACCEPT_PAUSE_CONTINUE | \
    SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_SHUTDOWN);
unsigned svcWaitHint = (5000) /* 5 sec */;
unsigned svcStartType = SERVICE_DEMAND_START;
const char *svcDependence = NULL;

#define svcRegister(z,u) (0)
#define svcUnregister(z) (0)

#if 0
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine,     // command line
                   int nCmdShow) // show state
{
    char *argv[3] = { "samp_svc", lpCmdLine, NULL };
    int argc = 2;
#else
int main(int argc, char *argv[])
{
#endif
  return svcMain(argc, argv);
}

#endif /*TEST_SVC*/

/* Service's entry points */
static void WINAPI svc_handler(DWORD opcode);
static void svc_main(ntseHandle nh, int argc, const char *argv[]);

struct svcHandle
  {
   SERVICE_STATUS   shStatus;
   CRITICAL_SECTION shLock;
   HANDLE           shCond;
   ntseHandle       shHndl;
   DWORD            shCommand;
   int              shSignal;
  };

static svcHandle svcState;
int svcIsFakeSCM = 0;

/* [OPTIONAL] Add our hairy GUI */
static int set_hooks(void *, HWND);
static void unset_hooks(void);
void change_icon(int state);

#ifndef IDI_RUNNING /* have icons? */
#define change_icon(x)
#endif

/**************************************************************************/

int svcMain(int argc, char *argv[])
{
 int main_err = 0, opts = 0, should_run = 0;
 int arg = 1, err;
 char *run_opt = "/run";
 ntseContext *sectx = 0; /* auto */

 if (argc <= 1)
   {
    main_err = 1; goto Help;
   }

 for(arg = 1; arg < argc; arg++)
 {
    char *arp = argv[arg];

    while(*arp)
    {
        while(*arp == '/' || *arp =='-' || isspace(0xff & *arp)) arp++;
        if (*arp) opts++;
        else continue;

#define OPT_MATCH(arg,str) (0 == strnicmp(arg, str, strlen(str)) && (arg += strlen(str)))

        if (OPT_MATCH(arp, "run"))
          {
            should_run = 1;
          }
        else if (OPT_MATCH(arp, "95"))
          {
                fprintf(stdout, "Force win95 mode...\n");
                sectx = ntseCtx95;
                run_opt = "/95run";
          }
        else if (OPT_MATCH(arp, "remove"))
        {
            ntseCommand(sectx, svcName, ntseOP_STOP);

            for(err = 0; 0 == ntseCommand(sectx, svcName, ntseOP_STOP)
                         && err < 6; err++) Sleep(500);
            err = ntseCommand(sectx, svcName, ntseOP_DELETE);
            switch(err)
            {
            case 0:
                fprintf(stdout, "Service [%s] uninstalled.\n", svcName);
                break;
            case ERROR_SERVICE_DOES_NOT_EXIST:
//                fprintf(stdout, "Service [%s] is not installed.\n", svcName);
                print_err(err, "Service [%s]:", svcName);
                err = 0;
                main_err = 1;
                break;
            case ERROR_SERVICE_MARKED_FOR_DELETE:
//                fprintf(stdout, "Service [%s] is locked and marked for delete.\n", svcName);
                print_err(err, "Service [%s]:", svcName);
                err = 0;
                main_err = 1;
                break;
            default:
                print_err(err, "Can't uninstall service [%s]", svcName);
                main_err = 1;
                break;
            }
            if (!err)
              {
                err = svcUnregister(svcName);
                if (err && !main_err)
                  print_err(err, "Service [%s] Unregistration failed:", svcName);
              }
        }
        else if (OPT_MATCH(arp, "install"))
        {
          unsigned len;
          char exepath[FILENAME_MAX + 16];

          /* argv[0] is unsafe */
          if (!(len = GetModuleFileName(NULL, exepath + 1,
                                             FILENAME_MAX + 8)))
            {
              print_err(GetLastError(),
                "Service [%s] install: GetModuleFileName() failed", svcName);
              main_err = 1;
            }
          else if (len + 4 + strlen(run_opt) >= sizeof(exepath))
            {
//              fprintf(stdout,
              /*ERROR_FILENAME_EXCED_RANGE ERROR_BAD_PATHNAME */
              print_err(ERROR_FILENAME_EXCED_RANGE,
                "Service [%s] install: Executable name is too long: %s",
                 svcName, exepath + 1);
              main_err = 1;
            }
          else
            {
              exepath[0] = exepath[++len] = '\"';
              exepath[++len] = ' ';
              strcpy(exepath + ++len, run_opt);
              err = ntseCreateOrChange(sectx, svcName, svcDescr,
                              SVC_TYPE,
                              svcStartType,
                              SERVICE_ERROR_NORMAL,
                              exepath, NULL, NULL,
                              svcDependence, 
                              NULL/*account*/, NULL/*password*/);
              if (err)
              {
                  print_err(err, "Can't install service [%s]", svcName);
                  main_err = 1;
              }
              else
              {
                  err = svcRegister(svcName, run_opt);
                  if (err)
                  {
                    print_err(err, "Service [%s] registration failed:", svcName);
                    main_err = 1;
                    ntseCommand(sectx, svcName, ntseOP_DELETE);
                  }
                  else
                    fprintf(stdout, "Service [%s] has been installed.\n", svcName);
              }
            }
        }
#if 1 /* [OPTIONAL] for debugging only */
        else if (OPT_MATCH(arp, "start"))
          {
            fprintf(stdout, "Starting service [%s]...",
              arg+1 < argc? argv[arg+1]: svcName);
            err = ntseCommand(sectx, arg+1 < argc? argv[arg+1]: svcName, ntseOP_START);
            if (err) print_err(err, "START Failed:");
            else fprintf(stdout, "Ok\n");
          }
        else if (OPT_MATCH(arp, "stop"))
          {
            err = ntseCommand(sectx, arg+1 < argc? argv[arg+1]: svcName, ntseOP_STOP);
            if (err)
              print_err(err, "STOP Failed:");

          }
        else if (OPT_MATCH(arp, "pause"))
          {
            err = ntseCommand(sectx, arg+1 < argc? argv[arg+1]: svcName, ntseOP_PAUSE);
            if (err)
              print_err(err, "PAUSE Failed:");
          }
        else if (OPT_MATCH(arp, "continue"))
          {
            err = ntseCommand(sectx, arg+1 < argc? argv[arg+1]: svcName, ntseOP_CONTINUE);
            if (err)
              print_err(err, "CONTINUE Failed:");
          }
        else if (OPT_MATCH(arp, "view"))
        {
            const char *svc_name = arg+1 < argc? argv[arg+1]: svcName;
            err = ntseQueryConfig(sectx, svc_name, NULL);

            switch(err)
            {
            case 0:
                fprintf(stdout, "Service [%s] is installed.\n", svcName);
                printServiceConfig(sectx, svc_name);
                err = printServiceStatus(sectx, svc_name);
                if (err) print_err(err, "==");
                break;
            case ERROR_SERVICE_DOES_NOT_EXIST:
//                fprintf(stdout,
                print_err(err, "Service [%s] is not installed.\n", svc_name);
                break;
            default:
                print_err(err, "Access to Service [%s] failed", svc_name);
                main_err = 1;
                break;
            }
        }
#endif /* end of [OPTIONAL] keys */
        else
        {
            if (!OPT_MATCH(arp, "help") && !OPT_MATCH(arp, "?"))
            {
//              print_err(ERROR_INVALID_PARAMETER,
              fprintf(stdout,
                "Unknown option '%s'\n", arp);
                main_err = 1;
            }
Help:
            fprintf(stdout, "Service [%s]\nUsage: \n"
                "/95   - modifier, forces Win95 mode;\n"
                "/install /remove /view\n"
                "/run  - start [in Win95 mode] or connect [on NT] to SCM;\n"
                "/start /stop /pause /continue [service_name]",
                svcName);
        }

        if (main_err) goto OptsDone;

    } /* end of while(arp... */
 } /* end of for(arg... */
 if (!main_err && should_run)
   {
    static ntseService iam[] = {
      { NULL, svc_main, svc_handler, &svcState.shStatus, &svcState.shHndl } };
      iam[0].nsName = svcName;
      /* muliple services allowed */

    svcState.shStatus.dwServiceType = SVC_TYPE;
    svcState.shStatus.dwCurrentState = SERVICE_START_PENDING;
    svcState.shStatus.dwControlsAccepted = svcAcceptCtl;
    svcState.shStatus.dwCheckPoint = 0;
    svcState.shStatus.dwWaitHint = svcWaitHint;
    svcState.shStatus.dwWin32ExitCode = 0;
    svcState.shStatus.dwServiceSpecificExitCode = 0;
    svcState.shCommand = 0;

    svcState.shSignal = 0;
    fprintf(stdout, "Service [%s] Running...\n", svcName);
    svcState.shCond = CreateEvent(0, 0, 0, 0);
    if (!svcState.shCond)
      {
        err = GetLastError();
        print_err(err, "CreateEvent() failed");
        svcState.shStatus.dwWin32ExitCode = err? err: -1;
        svcState.shStatus.dwCurrentState = SERVICE_STOPPED;
      }
    InitializeCriticalSection(&svcState.shLock);

/* NOTE: We use ntseServiceRunEx() here.
    But we could call ntseServiceWindow() to connect another process.
    And then hook it or change icons as well. */

#if 1 || defined(IDM_ABOUT) || defined(IDI_RUNNING)
    err = ntseServiceRunEx(sectx, iam, 1, set_hooks, NULL);
    unset_hooks();
#else
    err = ntseServiceRun(sectx, iam, 1);
#endif
    if (err)
      {
        print_err(err, "Can't run service [%s]", svcName);
        main_err = 2;
      }
    DeleteCriticalSection(&svcState.shLock);
    CloseHandle(svcState.shCond);
   }

OptsDone:

 return main_err;
}

/**************** service control functions ***************************/

/* Attemt to reduce service control to single function */

/* Wait no longer than SLEEP milliseconds.
   If no SERVICE_CONTROL_* pending and NEXTSTATE != 0 then
   Set the specified NEXTSTATE and error codes; Returns 0.
   Otherwise Returns SERVICE_CONTROL_*, doesn't set NEXTSTATE. */

unsigned svcControlAndSleep(
              svcHandle *ctx,  /* context */
              unsigned sleep,     /* milliseconds or INFINITE   */
              unsigned nextstate, /* SERVICE_RUNNING etc. */
              unsigned win32err,  /* SERVICE_STATUS::dwWin32ExitCode*/
              unsigned specefic)  /* ::dwServiceSpecificExitCode */
{
  unsigned ctl;

  EnterCriticalSection(&ctx->shLock);
  ctl = ctx->shCommand; ctx->shCommand = 0;
  if (nextstate)
    {
      if (nextstate != ctx->shStatus.dwCurrentState ||
          nextstate != SERVICE_RUNNING &&
          nextstate != SERVICE_PAUSED)
        {
          if (!ctl) /* is this check required? */
            ctx->shStatus.dwCurrentState = nextstate;
          ctx->shStatus.dwWin32ExitCode = win32err;
          ctx->shStatus.dwServiceSpecificExitCode = specefic;
          ctx->shStatus.dwWaitHint = svcWaitHint;
          ctx->shStatus.dwCheckPoint++;
          ntseSetStatus(ctx->shHndl, &ctx->shStatus);
          change_icon(nextstate);
        }
//      else
    }
  if (!ctl && sleep && !ctx->shSignal)
    {
      ResetEvent(ctx->shCond);
      LeaveCriticalSection(&ctx->shLock);
        WaitForSingleObject(ctx->shCond, sleep);
      EnterCriticalSection(&ctx->shLock);
      ctl = ctx->shCommand; ctx->shCommand = 0;
    }
  if (ctx->shSignal) 
    {
      ctx->shSignal = 0;
      ResetEvent(ctx->shCond);
    }
  LeaveCriticalSection(&ctx->shLock);
  return ctl;
}

/* Awake the svcControlAndSleep() if it waiting;
   send CTL=SERVICE_CONTROL_* if CTL != 0.
 */
void svcSignal(svcHandle *ctx, unsigned ctl)
{
  EnterCriticalSection(&ctx->shLock);
  if (ctl) ctx->shCommand = ctl;
  if (!ctx->shSignal) 
    { 
      ctx->shSignal = 1;
      SetEvent(ctx->shCond);
    }
  LeaveCriticalSection(&ctx->shLock);
}

static void svc_main(ntseHandle nh, int argc, const char *argv[])
{
  int ctl;
/* Return if hasn't initialized properly */
  if (!svcState.shCond) 
    {
      svcState.shStatus.dwCurrentState = SERVICE_STOPPED;
      ntseSetStatus(svcState.shHndl, &svcState.shStatus);
      return;
    }

  EnterCriticalSection(&svcState.shLock);
//svcState.shHndl = nh;
  svcState.shStatus.dwCurrentState = SERVICE_START_PENDING;
  svcState.shStatus.dwControlsAccepted = svcAcceptCtl;
  svcState.shStatus.dwCheckPoint++;
  ctl = ntseSetStatus(svcState.shHndl, &svcState.shStatus);
  LeaveCriticalSection(&svcState.shLock);

  if (ctl) return;

#if 0 == TEST_SVC
  ctl = svcRun(&svcState, svcName);

  EnterCriticalSection(&svcState.shLock);
  svcState.shStatus.dwCurrentState = SERVICE_STOPPED;
  svcState.shStatus.dwControlsAccepted = 0;
  svcState.shStatus.dwWin32ExitCode = ctl;
  ntseSetStatus(svcState.shHndl, &svcState.shStatus);
  LeaveCriticalSection(&svcState.shLock);
  change_icon(SERVICE_STOPPED);
#else
{
 int state = SERVICE_RUNNING;
  /* There are several ways to implement this loop
     for various kinds of services. */
  for(ctl = svcControlAndSleep(&svcState, 0, SERVICE_RUNNING, 0, 0);
      ctl != SERVICE_CONTROL_STOP;
      ctl = svcControlAndSleep(&svcState, 1000, /* timeout (ms)*/
                               ctl, 0, 0))
    {
      switch(ctl)
        {
      case SERVICE_CONTROL_PAUSE:    ctl = state = SERVICE_PAUSED;  break;
      case SERVICE_CONTROL_CONTINUE: ctl = state = SERVICE_RUNNING; break;
      case SERVICE_CONTROL_STOP:
      case SERVICE_CONTROL_SHUTDOWN: goto BREAK;
      default: ctl = 0;
        /* Blinking icon */
            change_icon((GetTickCount() / 1000 & 1)? 0: state);
            break;
        }
    }
BREAK:
  svcControlAndSleep(&svcState, 0, SERVICE_STOPPED, 0, 0);
}
#endif
} /* end of svc_main() */

static void WINAPI svc_handler(DWORD opcode)
{
    EnterCriticalSection(&svcState.shLock);

    switch (opcode)
    {
    case SERVICE_CONTROL_PAUSE:
        if (svcState.shStatus.dwCurrentState != SERVICE_PAUSED &&
            svcState.shStatus.dwCurrentState != SERVICE_STOP_PENDING &&
            svcState.shStatus.dwCurrentState != SERVICE_STOPPED)
            svcState.shStatus.dwCurrentState = SERVICE_PAUSE_PENDING;
        else opcode = 0;
        break;

    case SERVICE_CONTROL_CONTINUE:
        if (svcState.shStatus.dwCurrentState == SERVICE_PAUSED ||
            svcState.shStatus.dwCurrentState == SERVICE_PAUSE_PENDING)
            svcState.shStatus.dwCurrentState = SERVICE_CONTINUE_PENDING;
        else opcode = 0;
        break;

    case SERVICE_CONTROL_STOP:
        if (svcState.shStatus.dwCurrentState != SERVICE_STOPPED)
        {
            svcState.shStatus.dwCurrentState = SERVICE_STOP_PENDING;
            svcState.shStatus.dwControlsAccepted = 0;
        }
        else opcode = 0;
        break;

    case SERVICE_CONTROL_SHUTDOWN:
        if (svcState.shStatus.dwCurrentState != SERVICE_STOPPED)
        {
            svcState.shStatus.dwCurrentState = SERVICE_STOP_PENDING;
            svcState.shStatus.dwControlsAccepted = 0;
        }
        else opcode = 0;
        break;

    case SERVICE_CONTROL_INTERROGATE:
        opcode = 0;
        // Fall through to send current status.
        break;

    default:
        break;
    }

    svcState.shStatus.dwCheckPoint++;
    ntseSetStatus(svcState.shHndl, &svcState.shStatus);
    change_icon((int)svcState.shStatus.dwCurrentState);

    if (opcode)
      {
        svcState.shCommand = opcode;
        if (!svcState.shSignal) 
          { 
           svcState.shSignal = 1;
           SetEvent(svcState.shCond);
          }
      }

    LeaveCriticalSection(&svcState.shLock);
    return;
}

/************************ helpers ************************/

/* Translates MSGID to string.
   Returned string must be freed via LocalFree */

char *system_message(int msgid)
{
  char *buf = 0;
  unsigned len;
  len = FormatMessage(
    FORMAT_MESSAGE_ALLOCATE_BUFFER |
    FORMAT_MESSAGE_FROM_SYSTEM |
    FORMAT_MESSAGE_IGNORE_INSERTS,
    NULL, msgid, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
    (char*)&buf, 0, NULL);
  if (!buf || !len)
    {
     if (buf) LocalFree(buf);
     buf = (char*)LocalAlloc(LMEM_FIXED, 80);
     if (buf)
       wsprintf(buf, "GetLastError()=%d/0x%X/ ", msgid, msgid);
    }
  else
    {
      AnsiToOem(buf, buf);
      while(len--) /* strip cr-lf */
         if (' ' > (unsigned char)buf[len])
           buf[len] = ' ';
    }
 return buf;
}

void print_err(int ecode, const char *fmt, ...)
{
  char *msg = system_message(ecode);
  va_list ap; va_start(ap, fmt);
  vfprintf(stdout, fmt, ap);
  va_end(ap);
  fprintf(stdout, " [%s(%d)]\n", msg? msg: "null", ecode);
  LocalFree(msg);
}

/*********************************************************************
 [OPTIONAL] GUI stuff [ these additions do not required even on Win95]
 *********************************************************************/

unsigned ntseHideConsole(void)
{
  HWND hwndr = 0;
  HMODULE kernel;
  FARPROC getconsolewindow;

  if ((kernel = GetModuleHandle("KERNEL32.DLL")) && 
      (getconsolewindow = GetProcAddress(kernel, "GetConsoleWindow")))
    {
      hwndr = ((HWND (WINAPI *)(VOID))getconsolewindow)();
      if (hwndr) ShowWindowAsync(hwndr, SW_HIDE); /* SW_HIDE SW_MINIMIZE*/
//      UL_TRACE((NSLOG, "GetConsoleWindow()=%x", hwnd));
    }
  else
    {
      DWORD iam_pid = GetCurrentProcessId();
      int hope = 4;
      for(;;)
        {
          static const char *console_class[] = { "tty", "ConsoleWindowClass" };
          int icl;
          HWND hwnd = 0;
#ifndef SIZEOF_ARRAY
#define SIZEOF_ARRAY(XX) (sizeof(XX)/sizeof(XX[0]))
#endif
          for(icl = 0; icl < SIZEOF_ARRAY(console_class); icl++)
            while(hwnd = FindWindowEx(NULL, hwnd, console_class[icl], NULL))
              { /* An alternative is EnumThreadWindows() */
                DWORD win_pid = 0;
                DWORD win_thr = GetWindowThreadProcessId(hwnd, &win_pid);
                if (win_pid == iam_pid)
                  {
                    ShowWindowAsync(hwnd, SW_HIDE); /* SW_HIDE SW_MINIMIZE*/
//                    UL_TRACE((NSLOG, "Window Found(%s/%d): whd=%x pid=%d thrid=%d iam= %d %d", 
  //                    console_class[icl], hope, hwnd, win_pid, win_thr, iam_pid, GetCurrentThreadId()));
                    hope = 0;
                    hwndr = hwnd;
                  }
              }
          if (0 <= --hope) Sleep(333);
          else break;
        }
    }
  return (unsigned)hwndr;
}

#ifdef IDM_ABOUT /* have an additional commands? */

/* 'About' dialog proc. */

static LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_INITDIALOG:
                SetFocus(hDlg);
                return TRUE;

        case WM_COMMAND:
            if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
            {
                EndDialog(hDlg, LOWORD(wParam));
                return TRUE;
            }
            break;
    }
    return FALSE;
}

/* hooks */

static int hook_proc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  if (message == NTSE_WM_TASKBAR &&
      (//LOWORD(lParam) == WM_LBUTTONDOWN ||
       LOWORD(lParam) == WM_LBUTTONDBLCLK) )
    {
      PostMessage(hwnd, WM_COMMAND, IDM_ABOUT, 0);
    }
  else if (message == WM_COMMAND &&
           LOWORD(wParam) == IDM_ABOUT)
    {
        static int dlgON;
        if (!dlgON)
          {
            dlgON = 1;
            //SetForegroundWindow(hwnd);
            DialogBox(GetModuleHandle(NULL),
                  MAKEINTRESOURCE(IDD_ABOUTBOX),
                  hwnd, (DLGPROC)About);
            dlgON = 0;
            return 1;
        }
    }
  return 0;
}

static LRESULT CALLBACK
hook_CallWndRet(int hc, WPARAM wParam, LPARAM lParam)
{
    CWPRETSTRUCT *pcwps = (CWPRETSTRUCT*)lParam;
    if (hc >= 0 && pcwps && pcwps->hwnd)
      hook_proc(pcwps->hwnd, pcwps->message, pcwps->wParam, pcwps->lParam);
    return CallNextHookEx(NULL, hc, wParam, lParam);
}

static LRESULT CALLBACK
hook_GetMsg(int hc, WPARAM wParam, LPARAM lParam)
{
    MSG *pmsg = (MSG*)lParam;
    if (hc >= 0 && pmsg && pmsg->hwnd)
      hook_proc(pmsg->hwnd, pmsg->message, pmsg->wParam, pmsg->lParam);
    return CallNextHookEx(NULL, hc, wParam, lParam);
}

static HHOOK hook_ret = 0;
static HHOOK hook_get = 0;
#endif /*IDM_ABOUT*/

static HWND taskbar_hwnd = 0;

static int set_hooks(void *arg, HWND hwnd)
{
/* The hwnd can be obtained via ntseServiceWindow() too */
  if (hwnd) taskbar_hwnd = hwnd;
  svcIsFakeSCM = 1;
{
#if defined(IDM_ABOUT) || defined(IDI_RUNNING)
  DWORD thrid = GetWindowThreadProcessId(hwnd, NULL);
  HMENU menu = GetMenu(hwnd);

  fprintf(stdout, "Service [%s] Setting the HOOK [hwnd=%x: thr=%x]...\n",
      svcName, hwnd, thrid);

  change_icon(SERVICE_STOPPED);
#endif /*IDM_ABOUT || IDI_RUNNING*/
#ifdef IDM_ABOUT
  if (menu && (-1 == (int)GetMenuState(menu, IDM_ABOUT, MF_BYCOMMAND)))
    {
      AppendMenu(menu, MF_STRING,
                 IDM_ABOUT/*128...255*/, "About");
      DrawMenuBar(hwnd);
    }

  hook_ret = SetWindowsHookEx(WH_CALLWNDPROCRET,
          (HOOKPROC)hook_CallWndRet, //GetProcAddress(hmodHook, "SpyGetMsgProc"),
          GetModuleHandle(NULL), thrid);
  hook_get = SetWindowsHookEx(WH_GETMESSAGE,
          (HOOKPROC)hook_GetMsg, //GetProcAddress(hmodHook, "SpyGetMsgProc"),
          GetModuleHandle(NULL), thrid);
  if (!hook_get)
    print_err(GetLastError(), "Hook failed:");
#endif /*IDM_ABOUT*/
}
  return 0; /* !=0 cause abort */
}

static void unset_hooks(void)
{
#ifdef IDM_ABOUT
 if (hook_ret) UnhookWindowsHookEx(hook_ret), hook_ret = 0;
 if (hook_get) UnhookWindowsHookEx(hook_get), hook_get = 0;
#endif
 taskbar_hwnd = 0;
 svcIsFakeSCM = 0;
}

#ifdef IDI_RUNNING /* have icons? */
/* Change taskbar icon */
void change_icon(int state)
{
  int ico = 0;
  const char *sysico = IDI_INFORMATION;
  NOTIFYICONDATA pnid;

  if (!taskbar_hwnd) return;

  pnid.cbSize = sizeof (pnid);
  pnid.hWnd = taskbar_hwnd;
  pnid.uID   = NTSE_ID_TASKBAR;
  pnid.uFlags = NIF_ICON;
  switch(state)
    {
     case SERVICE_RUNNING: ico = IDI_RUNNING; 
                        sysico = IDI_APPLICATION; 
                        break;
     case SERVICE_STOPPED: ico = IDI_STOPPED; 
                        sysico = IDI_ERROR; 
                        break;
     case SERVICE_PAUSED:  ico = IDI_PAUSED; 
                        sysico = IDI_WARNING; 
                        break;
     case 0:               ico = IDI_BLANK;
                        sysico = IDI_WINLOGO;
                        break;
    }
  pnid.hIcon = ico? LoadImage(GetModuleHandle(NULL),
                              MAKEINTRESOURCE(ico),
                              IMAGE_ICON, 16, 16, LR_SHARED): 0;
  if (!pnid.hIcon)
    pnid.hIcon = LoadIcon(NULL, sysico);

  Shell_NotifyIcon(NIM_MODIFY,  &pnid);
  DrawMenuBar(taskbar_hwnd);
//  UpdateWindow(taskbar_hwnd);
}
#endif /*IDI_RUNNING*/

/**************************************************************************/
/* end of samp_svc.c */

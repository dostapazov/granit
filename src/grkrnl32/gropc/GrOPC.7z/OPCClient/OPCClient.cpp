//---------------------------------------------------------------------------
/*
Copyright (c) 2013,2014
Serge L. Ryadkow admin@opcgate.ru http://opcgate.ru
Leonid P. Lebedev llebedev@k-solutions.ru

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be included in all copies
or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.
*/
//---------------------------------------------------------------------------
/*
�����������, ���������� ��������� ������ � ��������� �������� ���������,
�������� ������������� // 2014.07.31 L�
*/
//---------------------------------------------------------------------------

#include <vcl.h>

#pragma hdrstop


#include <assert.h>

#pragma warn -8027
#include <utilcls.h>
#pragma warn .8027
//#include <objbase.h>  //CoInitialize
//#include <oleauto.h>

#include "OPCClient.h"
#include "OPCEnum.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
/*
static class TOle
{
  public:
    TOle() {OleCheck(::CoInitialize(0));}
    ~TOle() {::CoUninitialize();}
} Ole;
  */
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
TOPCServer::TOPCServer(const AnsiString &server, const AnsiString &host)
{
  CLSID clsid;
  if (host.IsEmpty()) {
    OleCheck(CLSIDFromProgID(WideString(server), &clsid));
    OleCheck(CoClassCreator::CoCreateInstance(
      clsid, IID_IOPCServer, reinterpret_cast<LPVOID*>(&Server)));
  } else {
    TOPCEnum e(host);
    clsid = e.CLSIDFromProgID(server);
    OleCheck(CoClassCreator::CreateRemote(WideString(host),
      clsid, IID_IOPCServer, reinterpret_cast<LPVOID*>(&Server)));
  }
#ifndef NO_OPC_SERVER_CALLBACK
  ShutdownCallbackSink.EvShutdown = DoShutdown;
  OleCheck(ShutdownCallbackSink.Connect(Server));
#endif
}
//---------------------------------------------------------------------------
TOPCServer::~TOPCServer()
{
#ifndef NO_OPC_SERVER_CALLBACK
  ShutdownCallbackSink.Disconnect();
#endif
  Server->Release();
}
//---------------------------------------------------------------------------
TDateTime TOPCServer::OPCTimeToDateTime(FILETIME t)
{
  TSystemTime st;
  FileTimeToLocalFileTime(&t, &t);
  FileTimeToSystemTime(&t, &st);
  return SystemTimeToDateTime(st);
}
//---------------------------------------------------------------------------
OPCSERVERSTATE __fastcall TOPCServer::GetState()
{
  OPCSERVERSTATUS *sts;
  OleCheck(Server->GetStatus(&sts));
  OPCSERVERSTATE ret = sts->dwServerState;
  if (sts->szVendorInfo)
    ::CoTaskMemFree(sts->szVendorInfo);
  ::CoTaskMemFree(sts);
  return ret;
}
//---------------------------------------------------------------------------
TDateTime __fastcall TOPCServer::GetStartTime()
{
  OPCSERVERSTATUS *sts;
  OleCheck(Server->GetStatus(&sts));
  TDateTime ret = OPCTimeToDateTime(sts->ftStartTime);
  if (sts->szVendorInfo)
    ::CoTaskMemFree(sts->szVendorInfo);
  ::CoTaskMemFree(sts);
  return ret;
}
//---------------------------------------------------------------------------
TDateTime __fastcall TOPCServer::GetCurrTime()
{
  OPCSERVERSTATUS *sts;
  OleCheck(Server->GetStatus(&sts));
  TDateTime ret = OPCTimeToDateTime(sts->ftCurrentTime);
  if (sts->szVendorInfo)
    ::CoTaskMemFree(sts->szVendorInfo);
  ::CoTaskMemFree(sts);
  return ret;
}
//---------------------------------------------------------------------------
TDateTime __fastcall TOPCServer::GetLastUpdateTime()
{
  OPCSERVERSTATUS *sts;
  OleCheck(Server->GetStatus(&sts));
  TDateTime ret = OPCTimeToDateTime(sts->ftLastUpdateTime);
  if (sts->szVendorInfo)
    ::CoTaskMemFree(sts->szVendorInfo);
  ::CoTaskMemFree(sts);
  return ret;
}
//---------------------------------------------------------------------------
int __fastcall TOPCServer::GetGroupCount()
{
  OPCSERVERSTATUS *sts;
  OleCheck(Server->GetStatus(&sts));
  int ret = sts->dwGroupCount;
  if (sts->szVendorInfo)
    ::CoTaskMemFree(sts->szVendorInfo);
  ::CoTaskMemFree(sts);
  return ret;
}
//---------------------------------------------------------------------------
int __fastcall TOPCServer::GetBandWidth()
{
  OPCSERVERSTATUS *sts;
  OleCheck(Server->GetStatus(&sts));
  int ret = sts->dwBandWidth;
  if (sts->szVendorInfo)
    ::CoTaskMemFree(sts->szVendorInfo);
  ::CoTaskMemFree(sts);
  return ret;
}
//---------------------------------------------------------------------------
int __fastcall TOPCServer::GetMajorVersion()
{
  OPCSERVERSTATUS *sts;
  OleCheck(Server->GetStatus(&sts));
  int ret = sts->wMajorVersion;
  if (sts->szVendorInfo)
    ::CoTaskMemFree(sts->szVendorInfo);
  ::CoTaskMemFree(sts);
  return ret;
}
//---------------------------------------------------------------------------
int __fastcall TOPCServer::GetMinorVersion()
{
  OPCSERVERSTATUS *sts;
  OleCheck(Server->GetStatus(&sts));
  int ret = sts->wMinorVersion;
  if (sts->szVendorInfo)
    ::CoTaskMemFree(sts->szVendorInfo);
  ::CoTaskMemFree(sts);
  return ret;
}
//---------------------------------------------------------------------------
int __fastcall TOPCServer::GetBuildNumber()
{
  OPCSERVERSTATUS *sts;
  OleCheck(Server->GetStatus(&sts));
  int ret = sts->wBuildNumber;
  if (sts->szVendorInfo)
    ::CoTaskMemFree(sts->szVendorInfo);
  ::CoTaskMemFree(sts);
  return ret;
}
//---------------------------------------------------------------------------
AnsiString __fastcall TOPCServer::GetVendorInfo()
{
  OPCSERVERSTATUS *sts;
  OleCheck(Server->GetStatus(&sts));
  AnsiString ret;
  if (sts->szVendorInfo) {
//    ret = AnsiString(szVendorInfo);
    ::CoTaskMemFree(sts->szVendorInfo);
  }
  ::CoTaskMemFree(sts);
  return ret;
}
//---------------------------------------------------------------------------
void __fastcall TOPCServer::DoShutdown(
      /* [in] */ LPCWSTR szReason)
{
  if(FOnShutdown)
    FOnShutdown(this, AnsiString(szReason));
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
__fastcall TOPCBrowser::TOPCBrowser(TOPCServer *server)
{
  OleCheck(server->Server->QueryInterface(IID_IOPCBrowseServerAddressSpace,
                                          reinterpret_cast<LPVOID*>(&Browser)));
}
//---------------------------------------------------------------------------
__fastcall TOPCBrowser::~TOPCBrowser()
{
  Browser->Release(); //Slow!!!!!!!!!!!!!!!!!!!!!
}
//---------------------------------------------------------------------------
OPCNAMESPACETYPE __fastcall TOPCBrowser::GetOrganization()
{
  OPCNAMESPACETYPE nst;
  OleCheck(Browser->QueryOrganization(&nst));
  return nst;
}
//---------------------------------------------------------------------------
void __fastcall TOPCBrowser::GoUp(const AnsiString &s)
{
  OleCheck(Browser->ChangeBrowsePosition(OPC_BROWSE_UP, WideString(s)));
}
//---------------------------------------------------------------------------
void __fastcall TOPCBrowser::GoDown(const AnsiString &s)
{
  OleCheck(Browser->ChangeBrowsePosition(OPC_BROWSE_DOWN, WideString(s)));
}
//---------------------------------------------------------------------------
void __fastcall TOPCBrowser::GoTo(const AnsiString &s)
{
  OleCheck(Browser->ChangeBrowsePosition(OPC_BROWSE_TO, WideString(s)));
}
//---------------------------------------------------------------------------
int __fastcall TOPCBrowser::GetGroups(TStrings *sl)
{
  sl->Clear();
  IEnumString* intf = NULL;
  OleCheck(Browser->BrowseOPCItemIDs(OPC_BRANCH, L"", VT_EMPTY, 0, &intf));
  try {
    LPWSTR s = NULL;
    while(intf->Next(1, &s, 0) == S_OK) {
        sl->Add(s);
        ::CoTaskMemFree(s);
    }
  }
  __finally {
    intf->Release();
  }
  return sl->Count;
}
//---------------------------------------------------------------------------
int __fastcall TOPCBrowser::GetTags(TStrings *sl)
{
  sl->Clear();
	IEnumString* intf = NULL;
  OleCheck(Browser->BrowseOPCItemIDs(OPC_LEAF, L"", VT_EMPTY, 0, &intf));
  try {
    LPWSTR s = NULL;
    while(intf->Next(1, &s, 0) == S_OK) {
        sl->Add(s);
        ::CoTaskMemFree(s);
    }
  }
  __finally {
    intf->Release();
  }
  return sl->Count;
}
//---------------------------------------------------------------------------
int __fastcall TOPCBrowser::GetFlat(TStrings *sl)
{
  sl->Clear();
	IEnumString* intf = NULL;
  OleCheck(Browser->BrowseOPCItemIDs(OPC_FLAT, L"", VT_EMPTY, 0, &intf));
  try {
    LPWSTR s = NULL;
    while(intf->Next(1, &s, 0) == S_OK) {
        sl->Add(s);
        ::CoTaskMemFree(s);
    }
  }
  __finally {
    intf->Release();
  }
  return sl->Count;
}
//---------------------------------------------------------------------------
AnsiString TOPCBrowser::GetItemId(const AnsiString &item)
{
  LPWSTR ws = NULL;
  OleCheck(Browser->GetItemID(WideString(item), &ws));
  AnsiString s(ws);
  ::CoTaskMemFree(ws);
  return s;
}
//---------------------------------------------------------------------------
void __fastcall TOPCBrowser::FillTree(TTreeNodes *nodes, TTreeNode *root)
{
  if (!root)
	  nodes->Clear();
  if (IsFlat) {
    TStringList *sl = new TStringList;
    try {
      GetFlat(sl);
      for (int i = 0; i < sl->Count; ++i)
        nodes->AddChild(root, sl->Strings[i]);
    }
    __finally {
      delete sl;
    }
  } else
    FillTreeP(nodes, root);
}
//---------------------------------------------------------------------------
void __fastcall TOPCBrowser::FillTreeP(TTreeNodes *nodes, TTreeNode *node)
{
  TStringList *sl = new TStringList;
  try {
    GetGroups(sl);
    for (int i = 0; i < sl->Count; ++i) {
      TTreeNode *n = nodes->AddChild(node, sl->Strings[i]);
      GoDown(sl->Strings[i]);
      try {
        FillTreeP(nodes, n);
      }
      __finally {
        GoUp(sl->Strings[i]);
      }
    }
    GetTags(sl);
    for (int i = 0; i < sl->Count; ++i)
      nodes->AddChild(node, sl->Strings[i]);
  }
  __finally {
    delete sl;
  }
}
//---------------------------------------------------------------------------
void __fastcall TOPCBrowser::FillGroupTree(TTreeNodes *nodes, TTreeNode *root)
{
  if (!root)
	  nodes->Clear();
  if (IsHierarchial)
    FillGroupTreeP(nodes, root);
}
//---------------------------------------------------------------------------
void __fastcall TOPCBrowser::FillGroupTreeP(TTreeNodes *nodes, TTreeNode *node)
{
  TStringList *sl = new TStringList;
  try {
    GetGroups(sl);
    for (int i = 0; i < sl->Count; ++i) {
      TTreeNode *n = nodes->AddChild(node, sl->Strings[i]);
      GoDown(sl->Strings[i]);
      try {
        FillGroupTreeP(nodes, n);
      }
      __finally {
        GoUp(sl->Strings[i]);
      }
    }
  }
  __finally {
    delete sl;
  }
}
//---------------------------------------------------------------------------
int __fastcall TOPCBrowser::FillList(TStrings *sl)
{
  sl->Clear();
  if (IsFlat) {
    GetFlat(sl);
    for (int i = 0; i < sl->Count; ++i)
      sl->Strings[i] = GetItemId(sl->Strings[i]);
  } else
    FillListP(sl);
  return sl->Count;
}
//---------------------------------------------------------------------------
void __fastcall TOPCBrowser::FillListP(TStrings *sl)
{
  TStringList *sl1 = new TStringList;
  try {
    GetGroups(sl1);
    for (int i = 0; i < sl1->Count; ++i) {
      GoDown(sl1->Strings[i]);
      try {
        FillListP(sl);
      }
      __finally {
        GoUp(sl1->Strings[i]);
      }
    }
    GetTags(sl1);
    for (int i = 0; i < sl1->Count; ++i)
      sl->Add(GetItemId(sl1->Strings[i]));
  }
  __finally {
    delete sl1;
  }
}
//---------------------------------------------------------------------------
int __fastcall TOPCBrowser::FillList(TTreeNode *node, TStrings *names,
                                     TStrings *ids)
{
  names->Clear();
  ids->Clear();
  if (IsHierarchial) {
    TStringList *sl = new TStringList;
    try {
      for (TTreeNode *n = node; n; n = n->Parent)
        sl->Add(n->Text);
      for (int i = sl->Count; i;)
        GoDown(sl->Strings[--i]);
      try {
        GetTags(names);
        for (int i = 0; i < names->Count; ++i)
          ids->Add(GetItemId(names->Strings[i]));
      }
      __finally {
      for (int i = 0; i < sl->Count; ++i)
        GoUp(sl->Strings[i]);
      }
    }
    __finally {
      delete sl;
    }
  }
  return names->Count;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
TOPCGroup::TOPCGroup(TOPCServer *server, TStrings* tl, const AnsiString &name,
                     int rate, float deadBand)
  : Server(server),
    FCount(tl->Count),
    FRate(rate),
    FDeadBand(deadBand)
{
  OleCheck(Server->Server->AddGroup(WideString(name), TRUE, Rate, 0, 0,
                                    &FDeadBand, 0, &Handle,
                                    (DWORD*)&FRate, IID_IUnknown,
                                    reinterpret_cast<LPUNKNOWN*>(&Group)));
  OleCheck(Group->QueryInterface(IID_IOPCSyncIO,
                                 reinterpret_cast<LPVOID*>(&SyncIO)));
  OleCheck(Group->QueryInterface(IID_IOPCItemMgt,
                                 reinterpret_cast<LPVOID*>(&ItemMgt)));
  OPCITEMDEF *id = new OPCITEMDEF[Count];
  HRESULT *err = NULL;
  OPCITEMRESULT *ir = NULL;
  for (int i = 0; i < Count; ++i) {
    id[i].szItemID = WideString(tl->Strings[i]).Detach();
    id[i].szAccessPath = L"";
    id[i].bActive = TRUE;
    id[i].hClient = i;
    id[i].dwBlobSize = 0;
    id[i].pBlob = NULL;
    id[i].vtRequestedDataType = 0;
  }
  try {
    OleCheck(ItemMgt->AddItems(Count, id, &ir, &err));
    assert(ir && err);
    try {
      ItemHandles = new DWORD[Count];
      for (int i = 0; i < Count; ++i) {
        OleCheck(err[i]);
        ItemHandles[i] = ir[i].hServer;
        if (ir[i].pBlob)
          ::CoTaskMemFree(ir[i].pBlob);
      }
      Values = new Variant[Count];
      Times = new TDateTime[Count];
      Qualities = new int[Count];
      // 2014.07.31 L� - �������� ������ ��� ������ ������
      Errors = new long[Count];
    }
    __finally {
      ::CoTaskMemFree(ir);
      ::CoTaskMemFree(err);
    }
  }
  __finally {
    delete[] id;
  }
}
//---------------------------------------------------------------------------
TOPCGroup::~TOPCGroup()
{
  HRESULT* err;
  ItemMgt->RemoveItems(Count, ItemHandles, &err);
  ::CoTaskMemFree(err);
  delete[] ItemHandles;
  delete[] Values;
  delete[] Times;
  delete[] Qualities;
  // 2014.07.31 L� - ����������� ������, ���������� ��� ������ ������
  delete[] Errors;
  ItemMgt->Release();
  SyncIO->Release();
  Group->Release();
  Server->Server->RemoveGroup(Handle, FALSE);
}
//---------------------------------------------------------------------------
Variant TOPCGroup::GetValue(int i)
{
  return Values[i];
}
//---------------------------------------------------------------------------
void TOPCGroup::Write(int i, const Variant &value)
{
  TVariant v(value);
  HRESULT *err = NULL;
  OleCheck(SyncIO->Write(1, ItemHandles + i, &v, &err));
  assert(err);
  try {
    OleCheck(err[0]);
    Values[i] = value;
  }
  __finally {
    ::CoTaskMemFree(err);
  }
}
//---------------------------------------------------------------------------
void TOPCGroup::SetValue(int i, const Variant &value)
{
  Write(i, value);
}
//---------------------------------------------------------------------------
TDateTime TOPCGroup::GetTime(int i)
{
  return Times[i];
}
//---------------------------------------------------------------------------
int TOPCGroup::GetQuality(int i)
{
  return Qualities[i];
}
//---------------------------------------------------------------------------
bool TOPCGroup::GetGood(int i)
{
  return (Qualities[i] & 0xc0) == 0xc0;
}
//---------------------------------------------------------------------------
// 2014.07.31 L� - ���������� ��� ������ �������� � �������� i
long TOPCGroup::GetError(int i)
{
  return Errors[i];
}
//---------------------------------------------------------------------------
// 2014.07.31 L� - ���������� ������� ���������� ������ ��� �������� � �������� i
bool TOPCGroup::GetSucceeded(int i)
{
  return SUCCEEDED(Errors[i]);
}
//---------------------------------------------------------------------------
void TOPCGroup::Read(bool fromDevice)
{
  OPCITEMSTATE *is = NULL;
  HRESULT *err = NULL;
  if (fromDevice)
    OleCheck(SyncIO->Read(OPC_DS_DEVICE, Count, ItemHandles, &is, &err));
  else
    OleCheck(SyncIO->Read(OPC_DS_CACHE, Count, ItemHandles, &is, &err));
  assert(is && err);
  try {
    for (int i = 0; i < Count; ++i) {
      // 2014.07.31 L� - ���������� ��� ������
      Errors[i] = err[i];
      OleCheck(err[i]);
      Values[i] = is[i].vDataValue;
      Times[i] = TOPCServer::OPCTimeToDateTime(is[i].ftTimeStamp);
      Qualities[i] = is[i].wQuality;
    }
  }
  __finally {
    ::CoTaskMemFree(is);
    ::CoTaskMemFree(err);
  }
}
//---------------------------------------------------------------------------
void TOPCGroup::Read()
{
  Read(false);
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
TAsyncOPCGroup::TAsyncOPCGroup(TOPCServer *server, TStrings* tl,
                               const AnsiString &name,
                               int rate, float deadBand)
  : TOPCGroup(server, tl, name, rate, deadBand),
    FOnDataChange(0)
{
  OleCheck(Group->QueryInterface(IID_IOPCAsyncIO2,
                                 reinterpret_cast<LPVOID*>(&AsyncIO)));
  DataCallbackSink.EvDataChange = DoDataChange;
  DataCallbackSink.EvReadComplete = DoReadComplete;
  DataCallbackSink.EvWriteComplete = DoWriteComplete;
  DataCallbackSink.EvCancelComplete = DoCancelComplete;
  OleCheck(DataCallbackSink.Connect(Group));
  OleCheck(AsyncIO->SetEnable(TRUE));
}
//---------------------------------------------------------------------------
TAsyncOPCGroup::~TAsyncOPCGroup()
{
  AsyncIO->SetEnable(FALSE);
  DataCallbackSink.Disconnect();
  AsyncIO->Release();
}
//---------------------------------------------------------------------------
void __fastcall TAsyncOPCGroup::DoDataChange(
      /* [in] */ DWORD dwTransid,
      /* [in] */ OPCHANDLE hGroup,
      /* [in] */ HRESULT hrMasterquality,
      /* [in] */ HRESULT hrMastererror,
      /* [in] */ DWORD dwCount,
      /* [size_is][in] */ OPCHANDLE __RPC_FAR *phClientItems,
      /* [size_is][in] */ VARIANT __RPC_FAR *pvValues,
      /* [size_is][in] */ WORD __RPC_FAR *pwQualities,
      /* [size_is][in] */ FILETIME __RPC_FAR *pftTimeStamps,
      /* [size_is][in] */ HRESULT __RPC_FAR *pErrors)
{
  if(SUCCEEDED(hrMastererror)) {
    for (int i = 0; i < int(dwCount); ++i) {
      // 2014.07.31 L� - ���������� ��� ������
      Errors[phClientItems[i]] = pErrors[i];
      // 2014.07.31 L� - ��������� ������������ ���������� �� ������� ������
      //if (SUCCEEDED(pErrors[i])) {
        Values[phClientItems[i]] = pvValues[i];
        Times[phClientItems[i]] = TOPCServer::OPCTimeToDateTime(pftTimeStamps[i]);
        Qualities[phClientItems[i]] = pwQualities[i];
      //}
    }
    if (FOnDataChange)
      FOnDataChange(this, dwCount, (int*)phClientItems);
  }
}
//---------------------------------------------------------------------------
void __fastcall TAsyncOPCGroup::DoReadComplete(
      /* [in] */ DWORD dwTransid,
      /* [in] */ OPCHANDLE hGroup,
      /* [in] */ HRESULT hrMasterquality,
      /* [in] */ HRESULT hrMastererror,
      /* [in] */ DWORD dwCount,
      /* [size_is][in] */ OPCHANDLE __RPC_FAR *phClientItems,
      /* [size_is][in] */ VARIANT __RPC_FAR *pvValues,
      /* [size_is][in] */ WORD __RPC_FAR *pwQualities,
      /* [size_is][in] */ FILETIME __RPC_FAR *pftTimeStamps,
      /* [size_is][in] */ HRESULT __RPC_FAR *pErrors)
{
  if(SUCCEEDED(hrMastererror)) {
    for (int i = 0; i < int(dwCount); ++i) {
      // 2014.07.31 L� - ���������� ��� ������
      Errors[phClientItems[i]] = pErrors[i];
      // 2014.07.31 L� - ��������� ������������ ���������� �� ������� ������
      //if (SUCCEEDED(pErrors[i])) {
        Values[phClientItems[i]] = pvValues[i];
        Times[phClientItems[i]] = TOPCServer::OPCTimeToDateTime(pftTimeStamps[i]);
        Qualities[phClientItems[i]] = pwQualities[i];
      //}
    }
    if (FOnReadComplete)
      FOnReadComplete(this);
  }
}
//---------------------------------------------------------------------------
void __fastcall TAsyncOPCGroup::DoWriteComplete(
      /* [in] */ DWORD dwTransid,
      /* [in] */ OPCHANDLE hGroup,
      /* [in] */ HRESULT hrMastererr,
      /* [in] */ DWORD dwCount,
      /* [size_is][in] */ OPCHANDLE __RPC_FAR *pClienthandles,
      /* [size_is][in] */ HRESULT __RPC_FAR *pErrors)
{
  if(SUCCEEDED(hrMastererr) && FOnWriteComplete)
    FOnWriteComplete(this);
}
//---------------------------------------------------------------------------
void __fastcall TAsyncOPCGroup::DoCancelComplete(
      /* [in] */ DWORD dwTransid,
      /* [in] */ OPCHANDLE hGroup)
{
  if(FOnCancelComplete)
    FOnCancelComplete(this);
}
//---------------------------------------------------------------------------
void TAsyncOPCGroup::Read()
{
  HRESULT *err = NULL;
  OleCheck(AsyncIO->Read(Count, ItemHandles, 0, &CancelId, &err));
  assert(err);
  try {
    for (int i = 0; i < Count; ++i)
      OleCheck(err[i]);
  }
  __finally {
    ::CoTaskMemFree(err);
  }
}
//---------------------------------------------------------------------------
void TAsyncOPCGroup::Write(int i, const Variant &value)
{
  TVariant v(value);
  HRESULT *err = NULL;
  OleCheck(AsyncIO->Write(1, ItemHandles + i, &v, 0, &CancelId, &err));
  assert(err);
  try {
    OleCheck(err[0]);
    Values[i] = value;
  }
  __finally {
    ::CoTaskMemFree(err);
  }
}
//---------------------------------------------------------------------------
void TAsyncOPCGroup::SetValue(int i, const Variant &value)
{
  Write(i, value);
}
//---------------------------------------------------------------------------
void TAsyncOPCGroup::Refresh(bool fromDevice)
{
  if(fromDevice)
    OleCheck(AsyncIO->Refresh2(OPC_DS_DEVICE, 0, &CancelId));
  else
    OleCheck(AsyncIO->Refresh2(OPC_DS_CACHE, 0, &CancelId));
}
//---------------------------------------------------------------------------


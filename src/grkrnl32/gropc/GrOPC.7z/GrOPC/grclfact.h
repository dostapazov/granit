#ifndef __GRCLFACT_H
#define __GRCLFACT_H

#define _WIN32_DCOM
#include <windows.h>
#include <ole2.h>
#include <olectl.h>
#include <oleauto.h>
#include <process.h>
#include <stdio.h>
//#include <errno.h>
//#include <locale.h>
//#include <opcda.h>
#include <opcerror.h>
#include "lightopc.h"
#include "unilog.h"

//static int driver_init(int lflags);
//static void driver_destroy(void);
//static void simulate(unsigned pause);

/* OLE-specefic data: ***********************************************************/

// {0E7D15EC-5C44-43a4-8F6B-DEB2F8D3D483}   inproc-server
static const GUID CLSID_GranitOPCServer = 
{ 0xe7d15ec, 0x5c44, 0x43a4, { 0x8f, 0x6b, 0xde, 0xb2, 0xf8, 0xd3, 0xd4, 0x83 } };

/* standard OLE registration stuff */

const char dClsidName[] = "GranitOPC server";
const char dProgID[] = "OPC.GranitCenter";

/**** Server Counting stuff & OLE ICF implementation *****************************
  The IClassFactory is unavoidable evil. Feel free to go ahead.
  Basically we've to unload when the server_count being zero.
  But there are different techniques for in-/out-of- proc servers.
*/

class GrClassFactory: public IClassFactory
{
public:
  int  server_inuse; /* go 0 when unloading initiated */
  LONG server_count;
  CRITICAL_SECTION lk_count;  /* protect server_count */
//	loService *gr_service;

  GrClassFactory();
  virtual ~GrClassFactory();

  void serverAdd(void);
  void serverRemove(void);
//	void SetVars(loService *_gr_service){gr_service=_gr_service;};

	// IUnknown
	STDMETHODIMP QueryInterface(REFIID iid, LPVOID *ppInterface);
/* Do nothing: we're static, he-he */  
  STDMETHODIMP_(ULONG) AddRef(void) { return 1; }
  STDMETHODIMP_(ULONG) Release(void) { return 1; }
	// IClassFactory
  STDMETHODIMP LockServer(BOOL fLock);
  STDMETHODIMP CreateInstance(LPUNKNOWN pUnkOuter, REFIID riid, LPVOID *ppvObject);
};

extern unilog *log;
//extern loService *gr_service;
//static GrClassFactory Gr_CF;
extern HMODULE server_module;

#endif

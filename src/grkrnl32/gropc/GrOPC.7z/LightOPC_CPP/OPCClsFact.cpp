//---------------------------------------------------------------------------
/*
Object oriented shell for LightOPC library
Copyright (C) 2012 Serge L. Ryadkow

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

Contacts:
admin@opcgate.ru
http://opcgate.ru
*/
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
#pragma hdrstop

#include "OPCClsFact.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
loService *OPCSvc;
TOPCClassFactory ClsFact;

static void a_server_finished(void *arg, loService *b, loClient *c)
{
  ClsFact.serverRemove();
}

void TOPCClassFactory::serverAdd(void)
{
  EnterCriticalSection(&lk_count);
 if (is_out_of_proc)
    CoAddRefServerProcess();
  ++server_count;
  LeaveCriticalSection(&lk_count);
}

void TOPCClassFactory::serverRemove(void)
{
  EnterCriticalSection(&lk_count);
  if (is_out_of_proc) {
     if (0 == CoReleaseServerProcess())
       server_inuse = 0;
  }
  if (0 == --server_count && server_inuse)
    server_inuse = 0;
  LeaveCriticalSection(&lk_count);
}

STDMETHODIMP TOPCClassFactory::CreateInstance(LPUNKNOWN pUnkOuter, REFIID riid,
                                            LPVOID *ppvObject)
{
  IUnknown *server = 0;
  HRESULT hr = S_OK;

  if (pUnkOuter)
    {
     if (riid != IID_IUnknown)
          return CLASS_E_NOAGGREGATION;
    }

  serverAdd();  // the lock for a_server_finished()

//***********************************************
// * check other conditions (i.e. security) here *
// ***********************************************
  if (0 == server_inuse) // we're stopped
    {                    // stopping initiated when there are no active instances
      if (is_out_of_proc)
        {                // a stopped EXE should exit soon and can't work anymore
          serverRemove();
          return E_FAIL;
        }
    }
{
 IUnknown *inner = 0;
 if (loClientCreate_agg(OPCSvc, (loClient**)&server,
                       pUnkOuter, &inner,
                       0, &OPCVendor, a_server_finished, 0))
    {
      serverRemove();
      hr = E_OUTOFMEMORY;
    }
  else if (pUnkOuter) *ppvObject = (void*)inner; //aggregation requested
  else // no aggregation
    {
//      loClientCreate(OPCSvc, (loClient**)&server,
//                 0, &OPCVendor, a_server_finished, 0);
      // Initally the created SERVER has RefCount=1
      hr = server->QueryInterface(riid, ppvObject); // Then 2 (if success)
      server->Release(); // Then 1 (on behalf of client) or 0 (if QI failed)
//      if (FAILED(hr))
//        UL_MESSAGE((LOGID, "TOPCClassFactory::loClient QueryInterface() failed"));
      // So we shouldn't carry about SERVER destruction at this point
    }
}
  if (SUCCEEDED(hr))
    {
      loSetState(OPCSvc, (loClient*)server,
             loOP_OPERATE, (int)OPC_STATUS_RUNNING, // other states are possible
             "Running");
    }

  return hr;
}


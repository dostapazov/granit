//---------------------------------------------------------------------------

#ifndef opcclientmdm_wndH
#define opcclientmdm_wndH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "gkmodule_form.h"
#include "../opcclientmdm.h"
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
#include <ImgList.hpp>
#include <ToolWin.hpp>
#include "../../OPCClient/OPCEnum.h"
#include "../../OPCClient/OPCClient.h"
#include <CheckLst.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
#include <System.ImageList.hpp>
//---------------------------------------------------------------------------
class TOPCClientWnd : public TGKModuleForm
{
__published:	// IDE-managed Components
        TPageControl *PageControl1;
        TStatusBar *StatusBar1;
        TTabSheet *TabSheet1;
        TTabSheet *TabSheet2;
        TLabel *Label1;
        TLabel *Label3;
        TEdit *CfgName;
        TToolBar *ToolBar1;
        TToolButton *StartBtn;
        TToolButton *StopBtn;
        TToolButton *ToolButton3;
        TToolButton *ApplyBtn;
        TToolButton *UndoBtn;
        TImageList *ImageList1;
        TLabel *Label4;
        TEdit *ModemNumberEdit;
        TUpDown *ModemNumber;
        TSpeedButton *SpeedButton2;
        TLabel *Label5;
        TTabSheet *ViewTab;
        TOpenDialog *OpenDialog1;
        TComboBox *CBServer;
        TTreeView *TreeView1;
        TButton *Button1;
        TPanel *Panel1;
        TPanel *Panel2;
        TSplitter *Splitter1;
        TSpeedButton *UpBtn;
        TSpeedButton *DownBtn;
        TSpeedButton *LoadBtn;
        TSpeedButton *SaveBtn;
        TSpeedButton *DelBtn;
        TSpeedButton *AddBtn;
        TStringGrid *StringGrid1;
        TListView *ListView1;
        TCheckBox *CBMask;
        TLabel *Label2;
        TLabel *Label6;
        TLabel *Label7;
        TEdit *EdRate;
        TEdit *EdDeadBand;
        void __fastcall ModemNumberChangingEx(TObject *Sender,
          bool &AllowChange, short NewValue, TUpDownDirection Direction);
        void __fastcall StartBtnClick(TObject *Sender);
        void __fastcall StopBtnClick(TObject *Sender);
        void __fastcall ApplyBtnClick(TObject *Sender);
        void __fastcall UndoBtnClick(TObject *Sender);
        void __fastcall CBServerDropDown(TObject *Sender);
        void __fastcall CBServerChange(TObject *Sender);
        void __fastcall SpeedButton2Click(TObject *Sender);
        void __fastcall CfgNameChange(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall AddBtnClick(TObject *Sender);
        void __fastcall DelBtnClick(TObject *Sender);
        void __fastcall StringGrid1SelectCell(TObject *Sender, int ACol,
          int ARow, bool &CanSelect);
        void __fastcall TreeView1DblClick(TObject *Sender);
        void __fastcall UpBtnClick(TObject *Sender);
        void __fastcall DownBtnClick(TObject *Sender);
        void __fastcall SaveBtnClick(TObject *Sender);
        void __fastcall LoadBtnClick(TObject *Sender);
        void __fastcall PageControl1Change(TObject *Sender);
        void __fastcall CBMaskClick(TObject *Sender);
        void __fastcall EdRateChange(TObject *Sender);
        void __fastcall EdDeadBandChange(TObject *Sender);
private:	// User declarations
  OCSETTINGS   settings;
  DWORD Fchmask;
  TOPCServer *Server;
  TOPCBrowser *Browser;
  bool NoRows;
  TOPCServer *ServerView;
  TAsyncOPCGroup *Group;
  void __fastcall on_module_state(GKHANDLE mod,DWORD state) ;
  void __fastcall on_module_config_change(GKHANDLE mod,LPMODULE_CONFIG_DATA mcd);
  void __fastcall Setchmask(DWORD value);
  void __fastcall after_set_gkhandle();
  void __fastcall setup_config_controls();
  bool __fastcall get_settings();
  void __fastcall handle_call_result(LRESULT ret);
  void __fastcall OnChange(TAsyncOPCGroup *group, int count, int *i);
  void __fastcall Connect();
  void __fastcall Disconnect();
public:		// User declarations
  __fastcall TOPCClientWnd(TComponent* Owner,HWND parent,GKHANDLE mod);
  __fastcall ~TOPCClientWnd();
protected:
  __property DWORD chmask  = { read=Fchmask, write=Setchmask };
};
//---------------------------------------------------------------------------
extern PACKAGE TOPCClientWnd *OPCClientWnd;
//---------------------------------------------------------------------------
#endif
 
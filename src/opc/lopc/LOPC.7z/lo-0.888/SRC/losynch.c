/**************************************************************************
 *                                                                        *
 * Light OPC Server development library                                   *
 *                                                                        *
 *   Copyright (c) 2000 by Timofei Bondarenko                             *
                                                                          *
  Synchronisation procedures
 **************************************************************************/
#include "losynch.h"

#include <stdlib.h>
#include <process.h>
#include <errno.h>
#include "util.h"

#define LW_malloc mallocX
#define LW_free   freeX

#include "lwsynch.c"

/* end of losynch.c */

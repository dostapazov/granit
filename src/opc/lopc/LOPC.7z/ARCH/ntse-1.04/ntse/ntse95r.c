/****************************************************************************

 NT-Service helper library.

 SCM Emulation on Win95.
 Running the services.

 Copyright (c) 2000,2002  Timofei Bondarenko, Kostya Volovich.
 ****************************************************************************/

#include <windows.h>
#include <winsvc.h>

#include <string.h>
#include <stdlib.h>
#include <stddef.h> /* offsetof()*/
#include <process.h>

#include "ntse.h"
#include "ntsepriv.h"

#ifndef SIZEOF_ARRAY
#define SIZEOF_ARRAY(xx) (sizeof(xx)/sizeof((xx)[0]))
#endif

static HINSTANCE hInstGlobal  = 0;
static HWND      hWndGlobal   = 0;
static HMENU     hPopupGlobal = 0;
static HICON hIconGlobal16;
static HICON hIconGlobal32;

static QUERY_SERVICE_CONFIG *wndSvcConf;
static CRITICAL_SECTION wndLock;
static int wndLock_ok;
static int wndShouldExit;
static int wndDestroyed;
static ntseContext *wndNC;

static UINT wm_TaskbarCreated;

static int ntseRegServProc95(int reg);

static unsigned command_for_all(unsigned ctl);

static int InitInstance(int, const char *);
static void ExitInstance(void);


static LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);

int ntseStatus95(ntseHandle se, const SERVICE_STATUS *st)
{
  int ch = 0;

  UL_TRACE((NSLOG, "ntseStatus95 {..."));

  if (!wndLock_ok) return -1;

  if (&se->niStatus != st)
    {
      EnterCriticalSection(&wndLock);
      ch = se->niStatus.dwControlsAccepted != st->dwControlsAccepted ||
           se->niStatus.dwCurrentState != st->dwCurrentState;
      se->niStatus = *st;
      LeaveCriticalSection(&wndLock);
    }

  if (ch && !wndDestroyed && hWndGlobal)
    {
      PostMessage(hWndGlobal, WM_COMMAND, se->niWnd + nwCmdSvSTATUS, 0);
  UL_TRACE((NSLOG, "ntseStatus95 sent %x", se->niWnd + nwCmdSvSTATUS));
    }
  return 0;
}

int ntseServRun95(ntseContext *nc,
                  int (*init_callback)(void *arg, HWND), void *arg)
{
 int rv;
 MSG msg;
 ntseService_int *stw = ntse_servlist;

 while(stw->niSe)
  {
    stw->niStatus.dwCurrentState = stw->niLastStatus = SERVICE_STOPPED;
    stw->niStatus.dwControlsAccepted = stw->niLastAccept = 0;
    stw++;
  }
  wndShouldExit = 0;

/********* Windowng stuff here *********************************/
  wndNC = nc;
 if (!wndLock_ok)
   {
     InitializeCriticalSection(&wndLock);
     wndLock_ok = 1;
   }

 if (!hInstGlobal) hInstGlobal = GetModuleHandle(NULL);

 ntseQueryConf95(nc, ntse_servlist->niSe->nsName, &wndSvcConf);

 SetLastError(0); /* Win95 doesn't report some errors,
                    so clean a previous error code */
 wndDestroyed = 0;
 if (rv = InitInstance(SW_HIDE/*nCmdShow*/, ntse_servlist->niSe->nsName)) 
   goto Return;

 if (0 != init_callback)
   {
     UL_TRACE((NSLOG, "Calling init_callback(%p, hwnd=%x)...", 
              arg, hWndGlobal));
     if (rv = init_callback(arg, hWndGlobal)) goto Return;
   }
     
#if 1
 FreeConsole();
#endif

 if (wndSvcConf && wndSvcConf->dwStartType == SERVICE_AUTO_START)
   {
     command_for_all(nwCmdCtlSTART);
#if 0  /* Let them remove it from taskbar, if required */
     rv = ntseAutoRun95(nc, ntse_servlist->niSe->nsName,
                        wndSvcConf->lpBinaryPathName);
     UL_TRACE((NSLOG, "%!l Ensuring AutoRun :: %s / %s",
       rv, ntse_servlist->niSe->nsName, wndSvcConf->lpBinaryPathName));
#endif
   }

  ntseRegServProc95(1);
  wm_TaskbarCreated = RegisterWindowMessage("TaskbarCreated");

  while (GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
  ntseRegServProc95(0);

  command_for_all(nwCmdCtlSTOP);
/*  rv = 100; // ntseServiceRun() does ... 
  while(command_for_all(nwCmdCtlSTOP) && --rv) Sleep(100);
  */
  rv = 0;

Return:

   ExitInstance();
/***************************************************************/

   if (wndLock_ok)
    {
      wndLock_ok = 0;
      DeleteCriticalSection(&wndLock);
    }
  if (wndSvcConf)
    {
      ntseFree(nc, wndSvcConf); wndSvcConf = 0;
    }      
  wndNC = NULL;

  if (rv)
      UL_INFO((NSLOG, "%!l ntseRunServ95(%d) FAILED", rv, ntse_servcount));
  else
      UL_TRACE((NSLOG, "ntseRunServ95() Finished Ok"));
  return rv;
}

static UINT isAcceptedMF(ntseService_int *sw, unsigned ctl)
{
  unsigned LastStatus, LastAccept;

  EnterCriticalSection(&wndLock);
  LastStatus = sw->niStatus.dwCurrentState;
  LastAccept = sw->niStatus.dwControlsAccepted;
  LeaveCriticalSection(&wndLock);

  if (LastStatus == SERVICE_STOPPED ||
      LastStatus <= 0) return ctl? MF_GRAYED: MF_ENABLED;

  if (ctl >= nwCTL_MAX)
    return ctl >= 128 && ctl <= 255? MF_ENABLED: MF_GRAYED;

  if (ntse_ctlx[ctl].ctlcode == SERVICE_CONTROL_INTERROGATE)
    return MF_ENABLED;

  if (0 == (ntse_ctlx[ctl].accept & LastAccept))
    return MF_GRAYED;

  if (LastStatus == SERVICE_PAUSED ||
      LastStatus == SERVICE_PAUSE_PENDING)
    {
      if (ntse_ctlx[ctl].ctlcode == SERVICE_CONTROL_PAUSE)
        return MF_GRAYED;
    }
  else
    {
      if (ntse_ctlx[ctl].ctlcode == SERVICE_CONTROL_CONTINUE)
        return MF_GRAYED;
    }

 return MF_ENABLED;
}

#define isAccepted(sw,ctl) (MF_ENABLED == isAcceptedMF(sw, ctl))

static void sw_main(ntseService_int *se)
{
  SERVICE_STATUS st;
  const char *argc[1];
  argc[0] = se->niSe->nsName;
  UL_TRACE((NSLOG, "sw_main: invoking... %p", se));

  if (se->niSe->nsStatus) st = *se->niSe->nsStatus;
  else memset(&st, 0, sizeof(st));
  st.dwCurrentState = SERVICE_START_PENDING;
  st.dwControlsAccepted = 0;
  ntseStatus95(se, &st);

  se->niSe->nsMain(se, 1, argc);

  UL_TRACE((NSLOG, "sw_main: finished %p", se));
  st.dwCurrentState = SERVICE_STOPPED;
  st.dwControlsAccepted = 0;
  ntseStatus95(se, &st);
  se->niSh = 0;
  if (wndShouldExit)
    PostMessage(hWndGlobal, WM_COMMAND, nwCmdWmEXIT, 0);
}

/* Return > 0 if beginthread failed, -1 if command is not accepted  */
static int process_command(unsigned ctl, int verbose)
{
  unsigned srn, fn;

  ntseService_int *sw;
  UL_TRACE((NSLOG, "wnd_ctl: %x", ctl));

  srn = (ctl - nwCmdBASE) / nwCmdMUL;
  fn = (ctl - nwCmdBASE) % nwCmdMUL;

      UL_TRACE((NSLOG, "process command{ %d %d }", srn, fn));

  if (ctl < nwCmdBASE || srn >= ntse_servcount)
    {
      UL_INFO((NSLOG, "wnd_ctl: 0x%x Out of range (0x%x)", ctl, ntse_servcount));
      return -1;
    }
  sw = &ntse_servlist[srn];

  if (fn == nwCmdSvSTATUS)
    {
      int ch = 0;
      EnterCriticalSection(&wndLock);
      if (sw->niLastStatus != sw->niStatus.dwCurrentState)
        sw->niLastStatus = sw->niStatus.dwCurrentState, ch = 1;
      if (sw->niLastAccept != sw->niStatus.dwControlsAccepted)
        sw->niLastAccept = sw->niStatus.dwControlsAccepted, ch = 1;
      LeaveCriticalSection(&wndLock);
      if (ch) /* changed? */
        {
          ch = sw->niWnd;

          ModifyMenu(hPopupGlobal, ch + nwCmdSvSTATUS,
                  MF_BYCOMMAND|MF_STRING,
                  ch + nwCmdSvSTATUS,
                  (LPSTR)ntsePrintState(sw->niLastStatus));

          for(fn = 0; fn < nwCTL_MAXMENU; fn++)
              EnableMenuItem(hPopupGlobal, ch + fn,
                  MF_BYCOMMAND|isAcceptedMF(sw, fn));
//          DrawMenuBar(hWndGlobal);
        }
      return 0;
    }

  if (!isAccepted(sw, fn)/* && fn == nwCmdCtlSHUTDOWN && 
      !isAccepted(sw, fn = SERVICE_CONTROL_STOP)*/)
    {    // real SCM doesn't convert SHUTDOWN to STOP 
      UL_TRACE((NSLOG, "wnd_ctl: 0x%x is not accepted by 0x%x", fn, srn));
      return -1;
    }

  if (fn != 0)
    sw->niSe->nsHandler(fn < nwCTL_MAX? ntse_ctlx[fn].ctlcode: fn);
  else if (!sw->niSh)
    {
      sw->niStatus.dwCurrentState = SERVICE_STOPPED;
      sw->niStatus.dwControlsAccepted = 0;
      sw->niSh = 1;
      if (-1 == _beginthread((void(*)(void*))sw_main, 0, sw))
        {
          sw->niSh = 0;
          UL_ERROR((NSLOG, "wnd_ctl: Failed to start thread [%s]", sw->niSe->nsName));
          if (verbose)
            MessageBox(hWndGlobal, "Failed to start service", sw->niSe->nsName,
                       MB_OK|MB_ICONERROR);
          return 1;
        }
      else
        {
          UL_TRACE((NSLOG, "wnd_ctl: thread started [%s]", sw->niSe->nsName));
        }
    }
#if 1
  else return -1;
#else
  else if (verbose)
     MessageBox(hWndGlobal, "Failed to start service\r\n"
                            "The service is already running\r\n"
                            "or not completly stopped yet.", 
                sw->niSe->nsName,
                MB_OK|MB_ICONERROR);
#endif
  return 0;
}

/* Return number of acceptors of a command or total for command =-1 */
 
static unsigned command_for_all(unsigned ctl) 
{
 unsigned running = 0;
 unsigned ii;
 for(ii = 0; ii < ntse_servcount; ii++)
   {
    if ((-1 == (int)ctl ||
         0 == process_command(ctl + ntse_servlist[ii].niWnd, 0))
         && ntse_servlist[ii].niSh) running++;
   }

 UL_DEBUG((NSLOG, "ntse95::command_for_all(%d) = %u", ctl, running));

 return running;
}

static BOOL refresh_start_type(HMENU menu)
{
  static const struct StartTypeData
      {
       char *text;
       unsigned type;
       unsigned command;
      } sttData[] = {
    { "Auto",   SERVICE_AUTO_START, nwCmdStAUTO },
    { "Manual", SERVICE_DEMAND_START, nwCmdStDEMAND },
    { "Disabled", SERVICE_DISABLED, nwCmdStDISABLED }   };
  BOOL rv = 1;
  int ii;

  for(ii = 0; ii < SIZEOF_ARRAY(sttData); ii++)
    {
     UINT attr = wndSvcConf ? (wndSvcConf->dwStartType == 
           sttData[ii].type ? MF_ENABLED|MF_CHECKED|MF_STRING: 
                              MF_ENABLED|MF_UNCHECKED|MF_STRING): 
                              MF_GRAYED |MF_STRING;
     rv &= 0 != menu? AppendMenu(menu, attr,
                      sttData[ii].command, sttData[ii].text)
                    : ModifyMenu(hPopupGlobal, sttData[ii].command, attr,
                      sttData[ii].command, (LPSTR)sttData[ii].text);
    }
 return rv;
}

static int InitMenus(void)
{
    HMENU submenu, demenu = 0;
    unsigned ii;
    int rv = 1;
    ntseService_int *srw = ntse_servlist;
#if defined(USE_LOG) && USE_LOG >= ll_NOTICE
#define ANDrv rv = rv &&
#else
#define ANDrv 
#endif
    for(ii = 0; rv && srw->niSe; ii++, srw++)
    {
        int xx;
        int xwn = srw->niWnd = nwCmdBASE + ii * nwCmdMUL;
        submenu = CreatePopupMenu();
        if (!submenu || 
            !AppendMenu(hPopupGlobal, MF_POPUP|MF_STRING,
                    (UINT_PTR)submenu, srw->niSe->nsName))
          {
            demenu = submenu; goto Error;
          }

        ANDrv AppendMenu(ii? submenu: hPopupGlobal, MF_STRING,
                    xwn + nwCmdSvSTATUS, ntsePrintState(srw->niLastStatus));

        ANDrv AppendMenu(ii? submenu: hPopupGlobal, MF_SEPARATOR, 0, "");

        for(xx = 0; rv && xx < nwCTL_MAXMENU; xx++)
        {
            ANDrv AppendMenu(submenu, MF_STRING | isAcceptedMF(srw, xx),
                    xwn + xx, ntse_ctlx[xx].ctlname);
        }
    }
    if (ii > 1)
      {
        ANDrv AppendMenu(hPopupGlobal, MF_SEPARATOR, 0, "");
      }

    submenu = CreatePopupMenu();
    if (!submenu ||
        !AppendMenu(hPopupGlobal, MF_POPUP|MF_STRING/*|
                (wndSvcConf? MF_ENABLED: MF_GRAYED)*/,
                (UINT_PTR)submenu, "Start Type"))
      {
        demenu = submenu; goto Error;
      }
    ANDrv refresh_start_type(submenu);

      ANDrv AppendMenu(hPopupGlobal, MF_SEPARATOR, 0, "");
    submenu = CreatePopupMenu();
    if (!submenu ||
        !AppendMenu(hPopupGlobal, MF_POPUP|MF_STRING,
                (UINT_PTR)submenu, "Special"))
      {
        demenu = submenu; goto Error;
      }
    ANDrv AppendMenu(submenu, MF_STRING, nwCmdWmHIDE, "Hide");
    ANDrv AppendMenu(submenu, MF_STRING, nwCmdWmEXIT, "Exit");

    if (!rv)
    {
Error:
        rv = GetLastError();
        if (demenu) DestroyMenu(demenu);
        UL_ERROR((NSLOG, "%!l ntse::AppendMenu() FAILED", rv));
        return rv? rv: -1;
    }

    return 0;
}

static BOOL taskbar_icon(HWND hWnd, const char *title)
{
 BOOL rv;
 NOTIFYICONDATA pnid;

 memset(&pnid, 0, sizeof pnid);
#if    defined(NOTIFYICONDATA_V1_SIZE)
    pnid.cbSize = NOTIFYICONDATA_V1_SIZE;
#elif !defined(NIF_STATE)
    pnid.cbSize = sizeof(NOTIFYICONDATA);
    if (sizeof(pnid.szTip) > 64)
      pnid.cbSize = offsetof(NOTIFYICONDATA, szTip[64]);
#else
//    pnid.cbSize = offsetof(NOTIFYICONDATA, dwState);
    pnid.cbSize = offsetof(NOTIFYICONDATA, szTip) +
      sizeof(pnid.szTip) < 64? sizeof(pnid.szTip): 64;
#endif
 if (hWnd)
   {
    pnid.hWnd = hWnd;
    pnid.uID   = NTSE_ID_TASKBAR;
    pnid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    pnid.uCallbackMessage = NTSE_WM_TASKBAR;
    pnid.hIcon = hIconGlobal16;
    strncpy (pnid.szTip, title, sizeof(pnid.szTip));
    rv = Shell_NotifyIcon(NIM_ADD,  &pnid);
    UL_DEBUG((NSLOG, "%!L ntse::Shell_NotifyIcon() = %d ", rv));
   }
 else
   {
    pnid.uFlags = 0;
    pnid.cbSize = sizeof (NOTIFYICONDATA);
    pnid.hWnd = hWndGlobal;
    pnid.uID   = NTSE_ID_TASKBAR;
    rv = Shell_NotifyIcon(NIM_DELETE,  &pnid);
   }
 DrawMenuBar(pnid.hWnd);
// UpdateWindow(pnid.hWnd);
 return rv;
}

static BOOL CALLBACK enum_icon(HMODULE hModule,   // module handle
                               LPCTSTR lpszType,  // resource type
                               LPTSTR lpszName,   // resource name
                               LPARAM/*LONG_PTR*/ lParam)   // application-defined parameter
{
  //UL_DEBUG((NSLOG, "%!L ---- EnumResource (%x)(%d)", hModule, lpszName));  
#if 0
  hIconGlobal = LoadIcon(hModule, lpszName);
#else
  hIconGlobal16 = LoadImage(hModule, lpszName, 
              IMAGE_ICON, 16, 16, LR_SHARED);
  hIconGlobal32 = LoadImage(hModule, lpszName, 
              IMAGE_ICON, 0, 0, LR_SHARED|LR_DEFAULTSIZE);
#endif
  //  UL_DEBUG((NSLOG, "%!L EnumResource %p(%d)", hIconGlobal, lpszName));  
  return !hIconGlobal16;
}

static int InitInstance(int nCmdShow, const char *title)
{
    HWND hWnd;
    WNDCLASSEX wcex;
    int rv;
#if 1
    if (!hIconGlobal16)
        EnumResourceNames(hInstGlobal, RT_GROUP_ICON, enum_icon, 0);
#endif
    if (!hIconGlobal16) hIconGlobal16 = LoadIcon(NULL, IDI_APPLICATION);
    if (!hIconGlobal32) hIconGlobal32 = hIconGlobal16;//LoadIcon(NULL, IDI_APPLICATION);

    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style            = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = (WNDPROC)WndProc;
    wcex.cbClsExtra        = 0;
    wcex.cbWndExtra        = 0;
    wcex.hInstance        = hInstGlobal;
    wcex.hIcon            = hIconGlobal32;
    wcex.hCursor        = LoadCursor(NULL, IDC_ARROW);
    wcex.hbrBackground    = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName    = NULL;
    wcex.lpszClassName    = ntse_classname;
    wcex.hIconSm        = hIconGlobal16;

    if (!RegisterClassEx(&wcex))
      {
        rv = GetLastError();
        UL_ERROR((NSLOG, "%!l ntse::RegisterClassEx() FAILED", rv));
        /* return rv? rv: -1;
        Let's try without class registerd... */
      }

   hWnd = FindWindow(ntse_classname, title);
   UL_MESSAGE((NSLOG, "%!L ntse::FindWindow()=%p", hWnd));
   if (hWnd)
     {
       taskbar_icon(hWnd, title);
       ShowWindow(hWnd, nCmdShow);
       UpdateWindow(hWnd);
       PostMessage(hWnd, WM_COMMAND, nwCmdWmSHOW, 0); /* for Wine only */
       return ERROR_SERVICE_ALREADY_RUNNING;
     }

/* We can live without menus... But we willn't */

    hPopupGlobal = CreatePopupMenu();
    if (!hPopupGlobal) 
      {
        rv = GetLastError();
        UL_ERROR((NSLOG, "%!l ntse::CreatePopupMenu() FAILED", rv));
        return rv? rv: -1;  
      }
    if (rv = InitMenus()) 
      {
        DestroyMenu(hPopupGlobal);
        hPopupGlobal = 0;
        return rv;
      }

   hWnd = CreateWindow(ntse_classname, title, /*WS_OVERLAPPEDWINDOW*/ WS_POPUP,
                                                   CW_USEDEFAULT, CW_USEDEFAULT,
                                                   CW_USEDEFAULT, CW_USEDEFAULT,
                                                   NULL, // parent
                                                   hPopupGlobal, //NULL,
                                                   hInstGlobal, NULL);

   if (!hWnd)
     {
        rv = GetLastError();
        UL_ERROR((NSLOG, "%!l ntse::CreateWindow() FAILED", rv));
        DestroyMenu(hPopupGlobal);
        hPopupGlobal = 0;
        return rv? rv: -1;
     }
   else UL_DEBUG((NSLOG, "ntse::CreateWindow()=%p"));
   hWndGlobal = hWnd;

   if (!taskbar_icon(hWnd, title))
     {
        rv = GetLastError();
        UL_WARNING((NSLOG, "%!l ntse::Shell_NotifyIcon() FAILED", rv));
        /* May be there is no shell/taskbar? */
     }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return 0;
}

static void ExitInstance (void)
{
    if (!wndDestroyed && hWndGlobal)
      UL_WARNING((NSLOG, "ntse95::ExitInstance()... Hmm..."));
    else UL_DEBUG((NSLOG, "ntse95::ExitInstance()..."));

    taskbar_icon(0, 0);
// Window does destroy itself...
//    if (!DestroyWindow(hWndGlobal))
//          UL_NOTICE((NSLOG, "%!L ntse::ExitInstance()DestroyWindow..."));
// Is the menu bound to window?
//    if (hPopupGlobal && !DestroyMenu (hPopupGlobal))
//        UL_NOTICE((NSLOG, "%!L ntse::ExitInstance()DestroyMenu..."));

    if (!UnregisterClass(ntse_classname, hInstGlobal))
      UL_NOTICE((NSLOG, "%!L ntse::UnRegisterClass() FAILED"));
    hPopupGlobal = 0;
    hWndGlobal = 0;
}

static LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    static int exit_pending;
    unsigned wmId, wmEvent;
    unsigned stt;

    switch (message)
    {
    case WM_COMMAND:
        wmId    = LOWORD(wParam);
        wmEvent = HIWORD(wParam);
        // Parse the menu selections:
        switch (wmId)
        {
        case nwCmdWmEXIT:
           exit_pending++;
           UL_DEBUG((NSLOG, "ntse::nwCmdWmEXIT %p", &wmId));
           if ( 0 == command_for_all(-1) ||
                IDCANCEL != MessageBox(hWnd, 
                "The service will be stopped", ntse_servlist->niSe->nsName, 
                    MB_OKCANCEL/*|MB_ICONQUESTION/*/|MB_ICONWARNING))
             {
              UL_DEBUG((NSLOG, "ntse95::process exit"));
              if (0 == command_for_all(nwCmdCtlSTOP))
                {
                  wndDestroyed = 1;
                  DestroyWindow(hWnd);
                }
              else { wndShouldExit = 1; /* Ignore, Let's user click it again */ }
             }
           UL_DEBUG((NSLOG, "ntse::nwCmdWmEXIT finish %p", &wmId));
           exit_pending--;
           break;
        case nwCmdWmQUIETEXIT:
           UL_DEBUG((NSLOG, "ntse::nwCmdWmQUIETEXIT"));
           wndShouldExit = 1;
           if (0 == command_for_all(-1))
              {
                wndDestroyed = 1;
                DestroyWindow(hWnd);
              }
           break;
        case nwCmdWmHIDE:
           UL_DEBUG((NSLOG, "ntse::nwCmdWmHIDE"));
           if (wndSvcConf &&
               wndSvcConf->dwStartType != SERVICE_DEMAND_START)
             ntseAutoRun95(wndNC, ntse_servlist->niSe->nsName, NULL);
           taskbar_icon(0, 0);
           break;
        case nwCmdWmSHOW: /* for Wine only */
           UL_DEBUG((NSLOG, "ntse::nwCmdWmSHOW"));
           taskbar_icon(hWndGlobal, ntse_servlist->niSe->nsName);
           break;

        case nwCmdStAUTO:
           stt = SERVICE_AUTO_START; goto StartType;
        case nwCmdStDEMAND:
           stt = SERVICE_DEMAND_START; goto StartType;
        case nwCmdStDISABLED:
           stt = SERVICE_DISABLED;
StartType:
           if (wndSvcConf && !(wndSvcConf->dwStartType == SERVICE_DISABLED?
                ntseCreate95(wndNC, ntse_servlist->niSe->nsName,
                wndSvcConf->dwServiceType, stt, wndSvcConf->lpBinaryPathName):
                ntseChange95(wndNC, ntse_servlist->niSe->nsName,
                wndSvcConf->dwServiceType, stt, wndSvcConf->lpBinaryPathName)))
             {
                wndSvcConf->dwStartType = stt;
                refresh_start_type(0);
             }
           else MessageBox(hWnd, "Failed to change start type",
                ntse_servlist->niSe->nsName, MB_OK|MB_ICONERROR);
           break;

        default:
          UL_DEBUG((NSLOG, "WM_COMMAND{ 0x%X %d }/%p", wmId, wmId, &wmId));
          if (wmId >= nwCmdBASE)
            process_command(wmId, 1/*verbose*/);
          else if (wmId >= nwCmdFORALL)
            command_for_all(wmId - nwCmdFORALL);
          else return DefWindowProc(hWnd, message, wParam, lParam);
        }
    break;

    case NTSE_WM_TASKBAR: //wParam = NTSE_ID_TASKBAR; lParam = mouse notify
        wmId    = LOWORD(lParam);
        wmEvent = HIWORD(lParam);
        switch (wmId)
        {
        case WM_LBUTTONDOWN:
        case WM_LBUTTONDBLCLK:
        case WM_RBUTTONDOWN:
          {
            POINT pt;
            GetCursorPos (&pt);
            if (exit_pending) 
              SetForegroundWindow(hWnd);
            else
              {
#if 1
                static unsigned last_refresh;
                unsigned time_now = GetTickCount();

                if (time_now - last_refresh > (/*!wndSvcConf? 3000u:*/ 6000u))
                  {
                    QUERY_SERVICE_CONFIG *sc = 0;
                    stt = wndSvcConf? wndSvcConf->dwStartType: SERVICE_DISABLED;

                    if (ntseQueryConf95(wndNC, ntse_servlist->niSe->nsName, &sc))
                      {
                        if (wndSvcConf) wndSvcConf->dwStartType = SERVICE_DISABLED;
                      }
                    else
                      {
                        QUERY_SERVICE_CONFIG *tsc = wndSvcConf;
                        wndSvcConf = sc; sc = tsc;
                      }
                    if (sc) ntseFree(wndNC, sc);
                    if (stt != (wndSvcConf? wndSvcConf->dwStartType: SERVICE_DISABLED))
                      refresh_start_type(0);
                    last_refresh = time_now;
                  }
#endif
               if (SetForegroundWindow(hWnd) ||
                   wmId == WM_LBUTTONDBLCLK)
                 {
                  TrackPopupMenu(hPopupGlobal,  TPM_RIGHTBUTTON,
                                    pt.x, pt.y, 0, hWnd, NULL);
                  PostMessage(hWnd, WM_NULL, 0, 0); 
                 }
               else
                 {
//                  PostMessage(hWnd, NTSE_WM_TASKBAR, wParam, lParam); 
                 }
              }
          }
            break;
        }
    break;

    case WM_DESTROY:
        UL_MESSAGE((NSLOG, "ntse::WM_DESTROY received"));
//??            ExitInstance (hInstGlobal);
//        command_for_all(nwCmdCtlSTOP);
//        DrawMenuBar(hWnd);
        PostQuitMessage(0);
    break;

    case WM_ENDSESSION:
        UL_TRACE((NSLOG, "ntse::WM_ENDSESSION received %x", lParam));
        //wndShouldExit = 1;
        if (lParam == 0) // real shutdown
          {
           unsigned nn = 32;
           do if (command_for_all(nwCmdCtlSHUTDOWN)) Sleep(200);
              else   // real SCM doesn't translate SHUTDOWN to STOP
                {
                  if (!command_for_all(-1))
                    {
                      wndDestroyed = 1;
                      DestroyWindow(hWnd);
                    }
                  break;
                }
           while(--nn > 0);
          }
    break;

    default:
        if (wm_TaskbarCreated && wm_TaskbarCreated == message)
          taskbar_icon(hWndGlobal, ntse_servlist->niSe->nsName);
        return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}

static int ntseRegServProc95(int reg)
{
  DWORD (WINAPI *regservproc)(DWORD dwProcessId, DWORD dwType);
  HMODULE kernel;
  int rv;
  kernel = GetModuleHandle("KERNEL32.DLL");
  if (!kernel)
    {
      rv = GetLastError();
      UL_NOTICE((NSLOG, "%!l ntseRegServProc(%d):GetModuleHandle()", rv, reg));
      goto Error;
    }
  regservproc = (DWORD (WINAPI *)(DWORD, DWORD))
       GetProcAddress(kernel, "RegisterServiceProcess");
  if (!regservproc)
    {
      rv = GetLastError();
      UL_NOTICE((NSLOG, "%!l ntseRegServProc(%d):GetProcAddress()", rv, reg));
      goto Error;
    }
  rv = regservproc(0, reg);
  if (!rv)
    {
      rv = GetLastError();
      UL_NOTICE((NSLOG, "%!l ntseRegServProc(%d):RegisterServiceProcess()", rv, reg));
      goto Error;
    }
  UL_TRACE((NSLOG, "ntseRegServProc(%d): Ok", reg));
  return 0;
Error:
  return rv? rv: -1;
}

/********************************************************************************/
/* end of ntse95r.c */

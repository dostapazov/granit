/****************************************************************************

 NT-Service helper library.

 Print ServiceConfig info.

 Copyright (c) 2000,2002  Timofei Bondarenko.
 ****************************************************************************/
#include <windows.h>
#include <winsvc.h>

#include <stdio.h>

#include "ntse.h"
#include "ntsepriv.h"


static void print_type(unsigned dwServiceType)
{
    const char *str1;
    const char *str2;

    str2 = dwServiceType & SERVICE_INTERACTIVE_PROCESS? "-INTERACTIVE": "";
    switch(dwServiceType & ~SERVICE_INTERACTIVE_PROCESS)
      {
    case SERVICE_WIN32_OWN_PROCESS:   str1 = "OWN_PROCESS";   break;
    case SERVICE_WIN32_SHARE_PROCESS: str1 = "SHARE_PROCESS"; break;
    case SERVICE_FILE_SYSTEM_DRIVER:  str1 = "FS_DRIVER";     break;
    case SERVICE_KERNEL_DRIVER :      str1 = "KERNEL_DRIVER"; break;
    default:                          str1 = "unknown";       break;
      }
    printf("dwServiceType =\t%s%s [%d 0x%X]\n",
           str1, str2, dwServiceType, dwServiceType);
}


int printServiceConfig(ntseContext *nc, const char *name)
{
 QUERY_SERVICE_CONFIG *sc = 0;
 int rc;
 rc = ntseQueryConfig(nc, name, &sc);
 if (rc || !sc)
   printf("ntseQueryConfig(%s) FAILED %d/0x%X\n", name, rc, rc);
 else
   {
    const char *str;

    printf("ServiceName: \t'%s'\n"
           "DisplayName: \t'%s'\n"
           "Executable:  \t'%s'\n"
           "Account:     \t'%s'\n",
         name, sc->lpDisplayName, sc->lpBinaryPathName, sc->lpServiceStartName);

    print_type(sc->dwServiceType);

    switch(sc->dwStartType)
      {
    case SERVICE_DISABLED:      str = "DISABLED";  break;
    case SERVICE_AUTO_START:    str = "AUTO";      break;
    case SERVICE_DEMAND_START:  str = "DEMAND";    break;
    case SERVICE_BOOT_START:    str = "BOOT";      break;
    case SERVICE_SYSTEM_START:  str = "SYSTEM";    break;
    default:                    str = "unknown";   break;
      }
    printf("dwStartType =  \t%s [%d 0x%X]\n",
           str, sc->dwStartType, sc->dwStartType);

    switch(sc->dwErrorControl)
      {
    case SERVICE_ERROR_IGNORE:  str = "IGNORE";    break;
    case SERVICE_ERROR_NORMAL:  str = "NORMAL";    break;
    case SERVICE_ERROR_SEVERE:  str = "SEVERE";    break;
    case SERVICE_ERROR_CRITICAL:str = "CRITICAL";  break;
    default:                    str = "unknown";   break;
      }
    printf("dwErrorControl=\t%s [%d 0x%X]\n",
           str, sc->dwErrorControl, sc->dwErrorControl);

    printf("LoadOrderGroup=\t'%s'\n"
           "dwTagId       =\t%d 0x%X\n",
           sc->lpLoadOrderGroup, sc->dwTagId, sc->dwTagId);

    printf("Dependencies:\t");
    str = sc->lpDependencies;
    if (str)
      do {
          printf("-'%s'", str);
          str += strlen(str) + 1;
         }
      while(*str);
    printf("\n");
   }
 ntseFree(nc, sc);
 return rc;
}

int printServiceStatus(ntseContext *nc, const char *name)
{
 int rc;
 DWORD bits, pos;
 SERVICE_STATUS st;
 memset(&st, 0, sizeof(st));

 rc = ntseControl(nc, name, ntseOP_QUERY, &st);
 if (rc)
   {
    printf("ntseQueryStatus(%s) FAILED %d/0x%X\n", name, rc, rc);
    return rc;
   }
 printf("ServiceName: \t'%s'\n"
        "ServiceState:\t'%s'\n",
        name, ntsePrintState(st.dwCurrentState));
 print_type(st.dwServiceType);

 printf("ControlsAccepted: ");
 bits = 0;
 for(pos = 1; pos; pos <<= 1)
   if (pos & st.dwControlsAccepted)
     {      
      const char *str;
      switch(pos)
        {
      case SERVICE_ACCEPT_STOP:           str = "STOP";           break;
      case SERVICE_ACCEPT_PAUSE_CONTINUE: str = "PAUSE&CONTINUE"; break;
      case SERVICE_ACCEPT_SHUTDOWN:       str = "SHUTDOWN";       break;
      case SERVICE_ACCEPT_PARAMCHANGE:    str = "PARAM-Chg";      break;
#ifdef     SERVICE_ACCEPT_POWEREVENT
      case SERVICE_ACCEPT_POWEREVENT:     str = "POWEREVENT";     break;
      case SERVICE_ACCEPT_SESSIONCHANGE:  str = "SESSION-Chg";    break;
      case SERVICE_ACCEPT_HARDWAREPROFILECHANGE: 
                                          str = "HWPROF-Chg";     break; 
#endif
      case SERVICE_ACCEPT_NETBINDCHANGE:  str = "NETBIND-Chg";    break; 
      default: bits |= pos; continue;
        }
      printf(" %s", str);
     }
 if (bits) printf(" 0x%08X", bits);
 putchar('\n');
 printf("ErrorCode= %9d %#8X  \tWaitHint = %9d\n"
        "Specefic = %9d %#8X  \tCheckPint= %9d\n",
        st.dwWin32ExitCode, st.dwWin32ExitCode, st.dwWaitHint, 
        st.dwServiceSpecificExitCode,
        st.dwServiceSpecificExitCode, st.dwCheckPoint);
 return 0;
}
/* end of ntsprint.c */

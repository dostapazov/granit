//---------------------------------------------------------------------------
/*
Object oriented shell for LightOPC library
Copyright (C) 2012 Serge L. Ryadkow

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

Contacts:
admin@opcgate.ru
http://opcgate.ru
*/
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
#include <vcl.h>

#pragma hdrstop

#include <windows.h>
#include <ole2.h>
#include <olectl.h>
#include <oleauto.h>
#include <stdio.h>

#include <opcda.h>
#include <opcerror.h>

#include "OPCClsFact.h"
#include "OPCSrvr.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//static
void __fastcall TOPCSrvr::Register()
{
  char np[FILENAME_MAX + 32];
  GetModuleFileName(NULL, np + 1, sizeof(np) - 8);
  np[0] = '"';
  strcat(np, "\"");
  if (loServerRegister(&OPCGUID, OPCProgID, OPCClsID, np, 0))
    throw Exception("loServerRegister() error");
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::UnRegister()
{
  if (loServerUnregister(&OPCGUID, OPCProgID))
    throw Exception("loServerUnregister() error");
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
__fastcall TOPCSrvr::TOPCSrvr(int tagCnt, int refRate, int flags)
  : TagCnt(tagCnt)
{
  ClsFact.is_out_of_proc = ClsFact.server_inuse = 1;
  if (FAILED(CoInitializeEx(NULL, COINIT_MULTITHREADED)))
    throw Exception("CoInitializeEx() error");
  setlocale(LC_CTYPE, "");
  if (OPCSvc)
    throw Exception("Driver already initialized");
  memset(&Drv, 0, sizeof(Drv));
  Drv.ldDriverArg = this;
  Drv.ldRefreshRate = refRate;
  Drv.ldWriteTags = WriteTagsS;
  Drv.ldReadTags = ReadTagsS;   //force to device
  Drv.ldFlags = flags;
  Drv.ldBranchSep = '.'; //Hierarchial branch separator
  if (loServiceCreate(&OPCSvc, &Drv, tagCnt))
    throw Exception("loServiceCreate() error");
  InitializeCriticalSection(&CS);
  TV = new loTagValue[tagCnt + 1];
  memset(TV, 0, sizeof(loTagValue) * tagCnt);
}
//---------------------------------------------------------------------------
__fastcall TOPCSrvr::~TOPCSrvr()
{
//  ClsFact.serverRemove();
  CoRevokeClassObject(ObjID);
  if (OPCSvc) {
    loServiceDestroy(OPCSvc);
    for(int i = 0; i < TagCnt; ++i)
      VariantClear(&TV[i].tvValue);
    delete[] TV;
    DeleteCriticalSection(&CS);
    OPCSvc = 0;
  }
  CoUninitialize();
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::Start()
{
  if (FAILED(CoRegisterClassObject(OPCGUID, &ClsFact,
      CLSCTX_LOCAL_SERVER | CLSCTX_REMOTE_SERVER | CLSCTX_INPROC_SERVER,
      REGCLS_MULTIPLEUSE, &ObjID)))
    throw Exception("CoRegisterClassObject() error");
  ClsFact.serverAdd();
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::Add(int id, const char *name, VARTYPE vt, int access)
{
  VARIANT var;
  VariantInit(&var);
  switch (vt) {
    case VT_BOOL: V_BOOL(&var) = false; break;
    case VT_I1: V_I1(&var) = 0; break;
    case VT_I2: V_I2(&var) = 0; break;
    case VT_I4: V_I4(&var) = 0; break;
    case VT_R4: V_R4(&var) = 0.0; break;
    case VT_R8: V_R8(&var) = 0.0; break;
  }
  V_VT(&var) = vt;
  if (loAddRealTag(OPCSvc,    /* actual service context */
                   &TV[id].tvTi,  /* returned TagId */
                   (loRealTag)id, /* != 0 driver's key */
                   name,   /* tag name */
                   0,     /* loTF_ Flags */
                   access,
                   &var, 0, 0))
    throw Exception("loAddRealTag() error");
  TV[id].tvState.tsError = S_OK;
  TV[id].tvState.tsQuality = OPC_QUALITY_BAD;
  switch (vt) {
    case VT_BOOL: V_BOOL(&TV[id].tvValue) = false; break;
    case VT_I1: V_I1(&TV[id].tvValue) = 0; break;
    case VT_I2: V_I2(&TV[id].tvValue) = 0; break;
    case VT_I4: V_I4(&TV[id].tvValue) = 0; break;
    case VT_R4: V_R4(&TV[id].tvValue) = 0.0; break;
    case VT_R8: V_R8(&TV[id].tvValue) = 0.0; break;
  }
  V_VT(&TV[id].tvValue) = vt;
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::AddBool(int id, const char *name, int access)
{
  VARIANT var;
  VariantInit(&var);
  V_BOOL(&var) = false;
  V_VT(&var) = VT_BOOL;
  if (loAddRealTag(OPCSvc,    /* actual service context */
                   &TV[id].tvTi,  /* returned TagId */
                   (loRealTag)id, /* != 0 driver's key */
                   name,   /* tag name */
                   0,     /* loTF_ Flags */
                   access,
                   &var, 0, 0))
    throw Exception("loAddRealTag() error");
  TV[id].tvState.tsError = S_OK;
  TV[id].tvState.tsQuality = OPC_QUALITY_BAD;
  V_VT(&TV[id].tvValue) = VT_BOOL;
  V_BOOL(&TV[id].tvValue) = 0;
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::AddByte(int id, const char *name, int access)
{
  VARIANT var;
  VariantInit(&var);
  V_I1(&var) = 0;
  V_VT(&var) = VT_I1;
  if (loAddRealTag(OPCSvc,    /* actual service context */
                   &TV[id].tvTi,  /* returned TagId */
                   (loRealTag)id, /* != 0 driver's key */
                   name,   /* tag name */
                   0,     /* loTF_ Flags */
                   access,
                   &var, 0, 0))
    throw Exception("loAddRealTag() error");
  TV[id].tvState.tsError = S_OK;
  TV[id].tvState.tsQuality = OPC_QUALITY_BAD;
  V_VT(&TV[id].tvValue) = VT_I1;
  V_I1(&TV[id].tvValue) = 0;
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::AddUByte(int id, const char *name, int access)
{
  VARIANT var;
  VariantInit(&var);
  V_UI1(&var) = 0;
  V_VT(&var) = VT_UI1;
  if (loAddRealTag(OPCSvc,    /* actual service context */
                   &TV[id].tvTi,  /* returned TagId */
                   (loRealTag)id, /* != 0 driver's key */
                   name,   /* tag name */
                   0,     /* loTF_ Flags */
                   access,
                   &var, 0, 0))
    throw Exception("loAddRealTag() error");
  TV[id].tvState.tsError = S_OK;
  TV[id].tvState.tsQuality = OPC_QUALITY_BAD;
  V_VT(&TV[id].tvValue) = VT_UI1;
  V_UI1(&TV[id].tvValue) = 0;
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::AddShort(int id, const char *name, int access)
{
  VARIANT var;
  VariantInit(&var);
  V_I2(&var) = 0;
  V_VT(&var) = VT_I2;
  if (loAddRealTag(OPCSvc,    /* actual service context */
                   &TV[id].tvTi,  /* returned TagId */
                   (loRealTag)id, /* != 0 driver's key */
                   name,   /* tag name */
                   0,     /* loTF_ Flags */
                   access,
                   &var, 0, 0))
    throw Exception("loAddRealTag() error");
  TV[id].tvState.tsError = S_OK;
  TV[id].tvState.tsQuality = OPC_QUALITY_BAD;
  V_VT(&TV[id].tvValue) = VT_I2;
  V_I2(&TV[id].tvValue) = 0;
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::AddUShort(int id, const char *name, int access)
{
  VARIANT var;
  VariantInit(&var);
  V_UI2(&var) = 0;
  V_VT(&var) = VT_UI2;
  if (loAddRealTag(OPCSvc,    /* actual service context */
                   &TV[id].tvTi,  /* returned TagId */
                   (loRealTag)id, /* != 0 driver's key */
                   name,   /* tag name */
                   0,     /* loTF_ Flags */
                   access,
                   &var, 0, 0))
    throw Exception("loAddRealTag() error");
  TV[id].tvState.tsError = S_OK;
  TV[id].tvState.tsQuality = OPC_QUALITY_BAD;
  V_VT(&TV[id].tvValue) = VT_UI2;
  V_UI2(&TV[id].tvValue) = 0;
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::AddLong(int id, const char *name, int access)
{
  VARIANT var;
  VariantInit(&var);
  V_I4(&var) = 0;
  V_VT(&var) = VT_I4;
  if (loAddRealTag(OPCSvc,    /* actual service context */
                   &TV[id].tvTi,  /* returned TagId */
                   (loRealTag)id, /* != 0 driver's key */
                   name,   /* tag name */
                   0,     /* loTF_ Flags */
                   access,
                   &var, 0, 0))
    throw Exception("loAddRealTag() error");
  TV[id].tvState.tsError = S_OK;
  TV[id].tvState.tsQuality = OPC_QUALITY_BAD;
  V_VT(&TV[id].tvValue) = VT_I4;
  V_I4(&TV[id].tvValue) = 0;
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::AddULong(int id, const char *name, int access)
{
  VARIANT var;
  VariantInit(&var);
  V_UI4(&var) = 0;
  V_VT(&var) = VT_UI4;
  if (loAddRealTag(OPCSvc,    /* actual service context */
                   &TV[id].tvTi,  /* returned TagId */
                   (loRealTag)id, /* != 0 driver's key */
                   name,   /* tag name */
                   0,     /* loTF_ Flags */
                   access,
                   &var, 0, 0))
    throw Exception("loAddRealTag() error");
  TV[id].tvState.tsError = S_OK;
  TV[id].tvState.tsQuality = OPC_QUALITY_BAD;
  V_VT(&TV[id].tvValue) = VT_UI4;
  V_UI4(&TV[id].tvValue) = 0;
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::AddFloat(int id, const char *name, int access)
{
  VARIANT var;
  VariantInit(&var);
  V_R4(&var) = 0.0;
  V_VT(&var) = VT_R4;
  if (loAddRealTag(OPCSvc,    /* actual service context */
                   &TV[id].tvTi,  /* returned TagId */
                   (loRealTag)id, /* != 0 driver's key */
                   name,   /* tag name */
                   0,     /* loTF_ Flags */
                   access,
                   &var, 0, 0))
    throw Exception("loAddRealTag() error");
  TV[id].tvState.tsError = S_OK;
  TV[id].tvState.tsQuality = OPC_QUALITY_BAD;
  V_VT(&TV[id].tvValue) = VT_R4;
  V_R4(&TV[id].tvValue) = 0.0;
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::AddDouble(int id, const char *name, int access)
{
  VARIANT var;
  VariantInit(&var);
  V_R8(&var) = 0.0;
  V_VT(&var) = VT_R8;
  if (loAddRealTag(OPCSvc,    /* actual service context */
                   &TV[id].tvTi,  /* returned TagId */
                   (loRealTag)id, /* != 0 driver's key */
                   name,   /* tag name */
                   0,     /* loTF_ Flags */
                   access,
                   &var, 0, 0))
    throw Exception("loAddRealTag() error");
  TV[id].tvState.tsError = S_OK;
  TV[id].tvState.tsQuality = OPC_QUALITY_BAD;
  V_VT(&TV[id].tvValue) = VT_R8;
  V_R8(&TV[id].tvValue) = 0.0;
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::SetBool(int id, bool val, FILETIME *time, int qual)
{
  bool t0 = time ? false : (time = new FILETIME) != 0;
  try {
    if (t0)
      GetSystemTimeAsFileTime(time);
    EnterCriticalSection(&CS);
    try {
      V_BOOL(&TV[id].tvValue) = val;
      V_VT(&TV[id].tvValue) = VT_BOOL;
      TV[id].tvState.tsTime = *time;
      TV[id].tvState.tsQuality = qual;
    } __finally {
      LeaveCriticalSection(&CS);
    }
  } __finally {
    if (t0)
      delete time;
  }
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::SetByte(int id, char val, FILETIME *time, int qual)
{
  bool t0 = time ? false : (time = new FILETIME) != 0;
  try {
    if (t0)
      GetSystemTimeAsFileTime(time);
    EnterCriticalSection(&CS);
    try {
      V_I1(&TV[id].tvValue) = val;
      V_VT(&TV[id].tvValue) = VT_I1;
      TV[id].tvState.tsTime = *time;
      TV[id].tvState.tsQuality = qual;
    } __finally {
      LeaveCriticalSection(&CS);
    }
  } __finally {
    if (t0)
      delete time;
  }
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::SetUByte(int id, unsigned char val, FILETIME *time,
    int qual)
{
  bool t0 = time ? false : (time = new FILETIME) != 0;
  try {
    if (t0)
      GetSystemTimeAsFileTime(time);
    EnterCriticalSection(&CS);
    try {
      V_UI1(&TV[id].tvValue) = val;
      V_VT(&TV[id].tvValue) = VT_UI1;
      TV[id].tvState.tsTime = *time;
      TV[id].tvState.tsQuality = qual;
    } __finally {
      LeaveCriticalSection(&CS);
    }
  } __finally {
    if (t0)
      delete time;
  }
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::SetShort(int id, short val, FILETIME *time, int qual)
{
  bool t0 = time ? false : (time = new FILETIME) != 0;
  try {
    if (t0)
      GetSystemTimeAsFileTime(time);
    EnterCriticalSection(&CS);
    try {
      V_I2(&TV[id].tvValue) = val;
      V_VT(&TV[id].tvValue) = VT_I2;
      TV[id].tvState.tsTime = *time;
      TV[id].tvState.tsQuality = qual;
    } __finally {
      LeaveCriticalSection(&CS);
    }
  } __finally {
    if (t0)
      delete time;
  }
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::SetUShort(int id, unsigned short val, FILETIME *time,
    int qual)
{
  bool t0 = time ? false : (time = new FILETIME) != 0;
  try {
    if (t0)
      GetSystemTimeAsFileTime(time);
    EnterCriticalSection(&CS);
    try {
      V_UI2(&TV[id].tvValue) = val;
      V_VT(&TV[id].tvValue) = VT_UI2;
      TV[id].tvState.tsTime = *time;
      TV[id].tvState.tsQuality = qual;
    } __finally {
      LeaveCriticalSection(&CS);
    }
  } __finally {
    if (t0)
      delete time;
  }
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::SetLong(int id, long val, FILETIME *time, int qual)
{
  bool t0 = time ? false : (time = new FILETIME) != 0;
  try {
    if (t0)
      GetSystemTimeAsFileTime(time);
    EnterCriticalSection(&CS);
    try {
      V_I4(&TV[id].tvValue) = val;
      V_VT(&TV[id].tvValue) = VT_I4;
      TV[id].tvState.tsTime = *time;
      TV[id].tvState.tsQuality = qual;
    } __finally {
      LeaveCriticalSection(&CS);
    }
  } __finally {
    if (t0)
      delete time;
  }
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::SetULong(int id, unsigned long val, FILETIME *time,
    int qual)
{
  bool t0 = time ? false : (time = new FILETIME) != 0;
  try {
    if (t0)
      GetSystemTimeAsFileTime(time);
    EnterCriticalSection(&CS);
    try {
      V_UI4(&TV[id].tvValue) = val;
      V_VT(&TV[id].tvValue) = VT_UI4;
      TV[id].tvState.tsTime = *time;
      TV[id].tvState.tsQuality = qual;
    } __finally {
      LeaveCriticalSection(&CS);
    }
  } __finally {
    if (t0)
      delete time;
  }
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::SetFloat(int id, float val, FILETIME *time, int qual)
{
  bool t0 = time ? false : (time = new FILETIME) != 0;
  try {
    if (t0)
      GetSystemTimeAsFileTime(time);
    EnterCriticalSection(&CS);
    try {
      V_R4(&TV[id].tvValue) = val;
      V_VT(&TV[id].tvValue) = VT_R4;
      TV[id].tvState.tsTime = *time;
      TV[id].tvState.tsQuality = qual;
    } __finally {
      LeaveCriticalSection(&CS);
    }
  } __finally {
    if (t0)
      delete time;
  }
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::SetDouble(int id, double val, FILETIME *time, int qual)
{
  bool t0 = time ? false : (time = new FILETIME) != 0;
  try {
    if (t0)
      GetSystemTimeAsFileTime(time);
    EnterCriticalSection(&CS);
    try {
      V_R8(&TV[id].tvValue) = val;
      V_VT(&TV[id].tvValue) = VT_R8;
      TV[id].tvState.tsTime = *time;
      TV[id].tvState.tsQuality = qual;
    } __finally {
      LeaveCriticalSection(&CS);
    }
  } __finally {
    if (t0)
      delete time;
  }
}
//---------------------------------------------------------------------------
bool __fastcall TOPCSrvr::GetBool(int id)
{
  bool ret;
  EnterCriticalSection(&CS);
  try {
    ret = V_BOOL(&TV[id].tvValue);
  } __finally {
    LeaveCriticalSection(&CS);
  }
  return ret;
}
//---------------------------------------------------------------------------
char __fastcall TOPCSrvr::GetByte(int id)
{
  char ret;
  EnterCriticalSection(&CS);
  try {
    ret = V_I1(&TV[id].tvValue);
  } __finally {
    LeaveCriticalSection(&CS);
  }
  return ret;
}
//---------------------------------------------------------------------------
unsigned char __fastcall TOPCSrvr::GetUByte(int id)
{
  unsigned char ret;
  EnterCriticalSection(&CS);
  try {
    ret = V_UI1(&TV[id].tvValue);
  } __finally {
    LeaveCriticalSection(&CS);
  }
  return ret;
}
//---------------------------------------------------------------------------
short __fastcall TOPCSrvr::GetShort(int id)
{
  short ret;
  EnterCriticalSection(&CS);
  try {
    ret = V_I2(&TV[id].tvValue);
  } __finally {
    LeaveCriticalSection(&CS);
  }
  return ret;
}
//---------------------------------------------------------------------------
unsigned short __fastcall TOPCSrvr::GetUShort(int id)
{
  unsigned short ret;
  EnterCriticalSection(&CS);
  try {
    ret = V_UI2(&TV[id].tvValue);
  } __finally {
    LeaveCriticalSection(&CS);
  }
  return ret;
}
//---------------------------------------------------------------------------
long __fastcall TOPCSrvr::GetLong(int id)
{
  long ret;
  EnterCriticalSection(&CS);
  try {
    ret = V_I4(&TV[id].tvValue);
  } __finally {
    LeaveCriticalSection(&CS);
  }
  return ret;
}
//---------------------------------------------------------------------------
unsigned long __fastcall TOPCSrvr::GetULong(int id)
{
  unsigned long ret;
  EnterCriticalSection(&CS);
  try {
    ret = V_UI4(&TV[id].tvValue);
  } __finally {
    LeaveCriticalSection(&CS);
  }
  return ret;
}
//---------------------------------------------------------------------------
float __fastcall TOPCSrvr::GetFloat(int id)
{
  float ret;
  EnterCriticalSection(&CS);
  try {
    ret = V_R4(&TV[id].tvValue);
  } __finally {
    LeaveCriticalSection(&CS);
  }
  return ret;
}
//---------------------------------------------------------------------------
double __fastcall TOPCSrvr::GetDouble(int id)
{
  double ret;
  EnterCriticalSection(&CS);
  try {
    ret = V_R8(&TV[id].tvValue);
  } __finally {
    LeaveCriticalSection(&CS);
  }
  return ret;
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::SetBad(int id, FILETIME *time)
{
  bool t0 = time ? false : (time = new FILETIME) != 0;
  try {
    if (t0)
      GetSystemTimeAsFileTime(time);
    EnterCriticalSection(&CS);
    try {
      TV[id].tvState.tsTime = *time;
      TV[id].tvState.tsQuality = OPC_QUALITY_BAD;
    } __finally {
      LeaveCriticalSection(&CS);
    }
  } __finally {
    if (t0)
      delete time;
  }
}
//---------------------------------------------------------------------------
void __fastcall TOPCSrvr::Flush()
{
  EnterCriticalSection(&CS);
  try {
    loCacheUpdate(OPCSvc, TagCnt, TV, 0);
  } __finally {
    LeaveCriticalSection(&CS);
  }
}
//---------------------------------------------------------------------------
//static
int TOPCSrvr::WriteTagsS(const loCaller *ca, unsigned count, loTagPair taglist[],
    VARIANT values[], HRESULT error[], HRESULT *master, LCID lcid)
{
  return ((TOPCSrvr*)ca->ca_se_arg)->WriteTags(ca, count, taglist, values,
      error, master, lcid);
}
//---------------------------------------------------------------------------
//static
loTrid TOPCSrvr::ReadTagsS(const loCaller *ca, unsigned count, loTagPair taglist[],
    VARIANT *values, WORD *qualities, FILETIME *stamps, HRESULT *errs,
    HRESULT *master_err, HRESULT *master_qual, const VARTYPE vtypes[],
    LCID lcid)
{
  return ((TOPCSrvr*)ca->ca_se_arg)->ReadTags(ca, count, taglist, values,
      qualities, stamps, errs, master_err, master_qual, vtypes, lcid);
}
//---------------------------------------------------------------------------
//virtual
int TOPCSrvr::WriteTags(const loCaller *ca, unsigned count, loTagPair taglist[],
    VARIANT values[], HRESULT error[], HRESULT *master, LCID lcid)
{
  for(unsigned int i = 0; i < count; ++i)
    if (taglist[i].tpTi) {
      HRESULT hr = WriteTag((int)taglist[i].tpRt, values[i]);
      if (hr == S_OK)
        taglist[i].tpTi = 0;
      else
        *master = S_FALSE;
      error[i] = hr;
    }
//  return *master == S_FALSE ? loDW_TOCACHE : loDW_ALLDONE;
  return loDW_ALLDONE;
}
//---------------------------------------------------------------------------
//virtual
loTrid TOPCSrvr::ReadTags(const loCaller *ca, unsigned count, loTagPair taglist[],
    VARIANT *values, WORD *qualities, FILETIME *stamps, HRESULT *errs,
    HRESULT *master_err, HRESULT *master_qual, const VARTYPE vtypes[],
    LCID lcid)
{
  return loDR_CACHED; /* perform actual reading from cache */
}
//---------------------------------------------------------------------------
//virtual
HRESULT TOPCSrvr::WriteTag(int id, VARIANT &val)
{
  HRESULT hr = VariantChangeType(&TV[id].tvValue, &val, 0, V_VT(&TV[id].tvValue));
//  if (hr == S_OK) hr = AttemptToWrite
  return hr;
}
//---------------------------------------------------------------------------


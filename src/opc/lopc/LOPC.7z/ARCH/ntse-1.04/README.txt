NTSE
~~~~
                NT-Service helper library
                ~~~~~~~~~~~~~~~~~~~~~~~~~

31 October 2003  - v1.04
	The function ntseHideConsole() introduced.
Usage (in a console daemon application):
	FreeConsole();
	AllocConsole();
	ntseHideConsole();
	Now it's possible to start console subprocesses
without blinking windows.

27 July 2003  - v1.03
	Icons have been changed.

17 July 2003  - v1.03
        samp_svc.c has been fixed a bit.
Now the user's entry svcRegister() doesn't called unless
OpenSCManager()/CreateService() are successfull.
This protects registry from altering by for example
occasional using of /install key with insufficient access rights.

15 July 2003  - v1.02
        A minor bug specefic to v1.01 fixed.
The "Exit warning" message box displayed by SCM simulator
doesn't became foreground whe simulator's icon clicked.
This modal message box can be "lost" in desktop and simulator's
icon seems being hanging.

22 May  2003  - v1.01
        Handling of the "TaskbarCreated" message 
        has been included in SCM simulator.

25 february 2003  - v1.00
------------------------------------------------------------------

The NTSE is a simple library destinated to simplify writing of
NT-Services. (Note _writing_ - not desigining).
NTSE does two thing:
  a) wrap native SCM API to save some handtyping 
    (but keep transparency and allow to turn back to native SCM easily);
  b) provide SCM simulator for the Win95/98/ME.
    (An icon with menu inserted into taskbar).

Therefore we got two thing:
  a) The same binares of NTSE-based services are able to run on eihter
     Win95 or NT with no changes.
  b) NTSE layer can be removed easily, without redesigning of a service.

Details are in ntse.h
Details about SCM theory are in MSDN Library.

The sample (SAMP_svc.c) shows extensibility (additional meny item,
icons) of the SCM-simulator.

The sample contains also a complete COM server implementing OPC DA
(SAMP_opc.cpp). This server _require_ the LightOPC library.

(binary release:
ftp://ftp.ipi.ac.ru/pub/LightOPC/lightopc-0.888-0313bin.tar.gz).
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
On another hand, the service sample (SAMP_svc.c) is selfconsistent.
It can be compiled without OPC. To do it you have to exclude
SAMP_opc from the project and compile SAMP_svc.c with -DTEST_SVC


BUILD
~~~~~

The ntse library contained in "ntse" subdirectory; the sample
contained in "ntsesamp" subdirectory.

Each subdir contains makefile.MSVC and makefile.MINGW

You may rename one of them to "Makefile" or run:

- for MS Visual Studio:
        vcvars32.bat
        cd ntsesamp
        nmake -f makefile.MSVC

- for MinGW32/gcc:
        cd ntsesamp
        make -f makefile.MINGW

In some cases the LIBRARY and INCLUDE paths needed to be 
adjusted in makefile.

To make an import library you may simple run:

for MS VisualC:
        lib /MACHINE:i386 /DEF:libname.def
for MING32/gcc:
        dlltool -d libname.def -l libname.a
        or include the libname.def instead of libname.a
        in the ld command line.

------------------------------------------------------------

http://www.ipi.ac.ru/lab43
ftp://ftp.ipi.ac.ru/pub/LightOPC
e-mail: master@ipi.ac.ru

------------------------------------------------------------

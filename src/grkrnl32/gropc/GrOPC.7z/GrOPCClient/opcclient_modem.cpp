//---------------------------------------------------------------------------

#pragma hdrstop

#include <tregstry.hpp>
#include "opcclient_modem.h"
#include "opcclient_line.h"
#pragma package(smart_init)
//---------------------------------------------------------------------------
TOPCClientModem::TOPCClientModem()
{
  alloc_gkhandle((wchar_t*)NULL);
  lock_param = GKHB_AUTO_LOCK_OFF;
}

wchar_t wm_name[] = L"GROPCCLIENTWND.DLL";
DWORD  __fastcall TOPCClientModem::get_window_module (wchar_t * buf,DWORD bsz)
{
  int len = lstrlenW(wm_name)+1;
  if(buf && int(bsz) > len)
  {
    SetLastError(0);
    safe_strcpy(buf,wm_name);
  }
  else
    {SetLastError(MERR_INVALID_BUFFER_SIZE);len=-len;}
  return DWORD(len);
}

bool   __fastcall TOPCClientModem::read_settings()
{
  bool ret ;
  TRegsReader rr(DupKey(reg_key));
  ret = TModemBase::read_settings();
  lock();
  settings.srv_name[rr.ReadString(OPCMDM_REGSTR_SRVNAME,settings.srv_name,sizeof(settings.srv_name)/sizeof(wchar_t),true)] = 0;
  settings.cfg_name[rr.ReadString(OPCMDM_REGSTR_CFGNAME,settings.cfg_name,sizeof(settings.cfg_name)/sizeof(wchar_t),true)] = 0;
  settings.rate=rr.ReadDword(OPCMDM_REGDW_RATE,1000,true);
  settings.dead_band=(float)rr.ReadDword(OPCMDM_REGDW_DEADBAND,0,true);
  unlock();
  return ret;
}

bool   __fastcall TOPCClientModem::write_settings()
{
  bool ret ;
  TRegsWriter rw(DupKey(reg_key));
  ret = TModemBase::write_settings();
  lock();
  if(cc_flags&CCFL_SRVNAME)
  {
    rw.WriteString(OPCMDM_REGSTR_SRVNAME,settings.srv_name,true);
    cc_flags&=~CCFL_SRVNAME;
  }
  if(cc_flags&CCFL_CFGNAME)
  {
    rw.WriteString(OPCMDM_REGSTR_CFGNAME,settings.cfg_name,true);
    cc_flags&=~CCFL_CFGNAME;
  }
  if(cc_flags&CCFL_RATE)
  {
    rw.WriteDword(OPCMDM_REGDW_RATE,settings.rate,true);
    cc_flags&=~CCFL_RATE;
  }
  if(cc_flags&CCFL_DEADBAND)
  {
    rw.WriteDword(OPCMDM_REGDW_DEADBAND,(DWORD)settings.dead_band,true);
    cc_flags&=~CCFL_DEADBAND;
  }
  unlock();
  return ret;
}

DWORD   __fastcall TOPCClientModem::get_config_data(DWORD mask,LPVOID buf,DWORD bsz)
{
  LPOCSETTINGS ocs =(LPOCSETTINGS)buf;
  if(check_data_size(ocs,sizeof(*ocs)))
  {
    if((mask&CCFL_MODEM_NUMBER))
      ocs->modem_number = get_modem_number();
    lock();
    if(mask&CCFL_SRVNAME)
      safe_strcpy(ocs->srv_name,settings.srv_name);
    if(mask&CCFL_CFGNAME)
      safe_strcpy(ocs->cfg_name,settings.cfg_name);
    if(mask&CCFL_RATE)
      ocs->rate=settings.rate;
    if(mask&CCFL_DEADBAND)
      ocs->dead_band=settings.dead_band;
    unlock();
    return GKH_RET_SUCCESS;
  }
  return GKH_RET_ERROR;
}

bool    __fastcall TOPCClientModem::set_config_data(DWORD mask,LPVOID buf,DWORD bsz)
{
  bool ret = false;
  LPOCSETTINGS ocs =(LPOCSETTINGS)buf;
  DWORD error = 0;
  if(check_data_size(ocs,sizeof(*ocs)))
  {
    ret = true;
    if((mask&CCFL_MODEM_NUMBER))
    {
      if(set_modem_number(ocs->modem_number,NULL))
      {
        error = GetLastError();
        ret = false;
      }
      else
        settings.modem_number = get_modem_number();
    }
    lock();
    if(mask&CCFL_SRVNAME)
      safe_strcpy(settings.srv_name,ocs->srv_name);
    if(mask&CCFL_CFGNAME)
      safe_strcpy(settings.cfg_name,ocs->cfg_name);
    if(mask&CCFL_RATE)
      settings.rate=ocs->rate;
    if(mask&CCFL_DEADBAND)
      settings.dead_band=ocs->dead_band;
    unlock();
  }
  if(error) SetLastError(error);//��������� ������
  return ret;
}

bool    __fastcall TOPCClientModem::compare_config_data(DWORD mask,LPVOID buf,DWORD bsz,LPDWORD ch_mask,BOOL * restart)
{
  bool ret = false;
  LPOCSETTINGS ocs =(LPOCSETTINGS)buf;
  DWORD cm   = 0;
  BOOL  rst  = FALSE;
  if(check_data_size(ocs,sizeof(*ocs)))
  {
    ret = true;
   if((mask&CCFL_MODEM_NUMBER) && ocs->modem_number!=get_modem_number())
     cm|=CCFL_MODEM_NUMBER,rst = TRUE;
   lock();
   if((mask&CCFL_SRVNAME) && lstrcmpiW(settings.srv_name,ocs->srv_name))
     cm|= CCFL_SRVNAME,rst = TRUE;
   if((mask&CCFL_CFGNAME) && lstrcmpiW(settings.cfg_name,ocs->cfg_name))
     cm|= CCFL_CFGNAME,rst = TRUE;
   if((mask&CCFL_RATE) && (settings.rate!=ocs->rate))
     cm|= CCFL_RATE,rst = TRUE;
   if((mask&CCFL_DEADBAND) && (settings.dead_band!=ocs->dead_band))
     cm|= CCFL_DEADBAND,rst = TRUE;
    unlock();
  }
  if(ch_mask)*ch_mask = cm;
  if(restart) *restart = rst;
  return ret;
}

bool    __fastcall TOPCClientModem::check_config_data  (DWORD mask,LPVOID buf,DWORD bsz)
{
  return TModemBase::check_config_data(mask,buf,bsz);
}

int     __fastcall TOPCClientModem::convert_rx_data(LPWORD fa,LPBYTE in,int in_len,LPBYTE out,DWORD out_sz)
{
  if(out && out_sz)
  {
    if(int(out_sz)>=in_len)
    {
      memcpy(out,in,in_len);
    }
    else
    {
      memcpy(out,in,out_sz);
      in_len = -in_len;
    }
  }
  else
    in_len = -in_len;
  return in_len;
}

void    __fastcall TOPCClientModem::free_line     (modem_line * line)
{
  if(line)
  {
    opcclient_line * pl = dynamic_cast<opcclient_line*>(line);
    if(pl)
      delete pl;
    else
      delete line;
  }
}

//BOOL  __fastcall TOPCClientModem::can_start(DWORD reason,LPARAM p2)
//{
//  if(TModemBase::can_start(reason,p2))
//  {
//    //if(GetFileAttributesW(settings.proc_name)!=(DWORD)-1)
//     return TRUE;
//  }
//  return FALSE;
//}

DWORD   __fastcall TOPCClientModem::start(DWORD reason,LPARAM start_param)
{
  if(!get_lines_count())
    add_line(new opcclient_line(0));
  lock();
  opcclient_line * pl = dynamic_cast<opcclient_line*>(get_line(0));
  if(pl)
    pl->set_start_param(&settings);
  unlock();
  return TModemBase::start(reason,start_param);
}






//---------------------------------------------------------------------------

#pragma hdrstop

#include "opcclient_line.h"
#include "item_def.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)

opcclient_line::opcclient_line(DWORD number):modem_line(number),term_event(true,false)
{
  ZeroMemory(&settings,sizeof(settings));
  settings.dw_size = sizeof(settings);
  ItemList=new TList;
}

void __fastcall opcclient_line::release()
{
  ItemList->Clear();
  delete ItemList;
  modem_line::release();
}

DWORD __fastcall opcclient_line::get_line_text  (wchar_t * text,DWORD text_sz)
{
  DWORD ret = 0;
  wchar_t name[MAX_PATH]={0};
  *name = 0;
  if(settings.srv_name)
     safe_strcpy(name,settings.srv_name);
  else
     safe_strcpy(name,L"����� �� ��������");
  if(text && text_sz>=(DWORD)(2+lstrlenW(name)))
    ret=wsprintfW(text,L"%s",name);
  return ret;
}

bool __fastcall opcclient_line::do_start()
{
  bool ret = true;
  //ret=Start(0);
  Connect();
  return ret;
}

bool __fastcall opcclient_line::do_stop()
{
  bool   ret = true;
  //TerminateAndWait(2000);
  Disconnect();
  return ret;
}

bool  __fastcall opcclient_line::send(LPMPROTO_HEADER mph,DWORD sz)
{
  DWORD wr_bytes = MPROTO_SIZE(mph);
  if(((int)wr_bytes)>=0)
  {
//    if(write_pipe)
//    {
//     if(wr_bytes)
//     {
//      send_queue.PutIntoQueue(mph,wr_bytes);
//      update_modemmer_tx(wr_bytes,1);
//     }
//    }
  }
  else
    wr_bytes = 0;
  return wr_bytes ? true:false;
}

//bool __fastcall opcclient_line::BeforeExecute()
//{
//  term_event.SetEvent(false);
//  ss.Clear();
//  ss+=term_event;
//  return TGKThread::BeforeExecute();
//}
//
//int __fastcall opcclient_line::Execute()
//{
//  Connect();
//  DWORD wr = -1;
//  while(wr)
//  {
//    wr =  ss.Wait(100);
//    switch(wr)
//    {
////    case 1   : send_processing();
////               recv_processing();
////               break;
////
////    case 2   :
////               connect(false);
////               cleanup_process();
////               if(!process.WaitForTerminate(1000));
////                  TerminateProcess(proccess_info.hProcess,-1);
////               ss-=process();
////               process.Close();
////               if(!settings.auto_restart || !run_process())//���������� �� ����������
////                  wr = 0;
////                  else
////                  ss+=process();
////               break;
//      case WAIT_TIMEOUT  : WaitMessage(); /*recv_processing();*/break;   Idle
//    }
//  }
//  Disconnect();
//  return 0;
//}
//
//void __fastcall opcclient_line::BeforeTerminate()
//{
//  set_state(MODEM_LINE_STATE_WORKED,false);
//  TGKThread::BeforeTerminate();
//}
//
void __fastcall opcclient_line::OnChange(TAsyncOPCGroup *group, int count, int *i)
{
  SYSTEMTIME st;
  TItemDef *def;
  BYTE *buf;
  DWORD need_size,dw;
  bool b;
  float f;
  otd_proto op;
  op.dw_size = sizeof(op);
  otd_proto_param opp={0};
  opp.dw_size = sizeof(opp);
  opp.parts = OTD_PROTO_PART_DATA|OTD_PROTO_PART_TIMESTAMP|OTD_PROTO_PART_DIAG|OTD_PROTO_PART_PERSONAL_CHMASK;
  for (int j = 0; j < count; ++j)
  {
    def = (TItemDef *)ItemList->Items[i[j]];
    def->Value=group->Value[i[j]];
    DateTimeToSystemTime(group->Time[i[j]],st);
    SystemTimeToFileTime(&st,&def->TimeStamp);
    def->Quality=group->Quality[i[j]];

    if(def->Address.fa==OTD_FA_DISCRETE)
      opp.dt_param.type = OTD_DISCRETE;
    else
      opp.dt_param.type = OTD_FLOAT;
    opp.dt_param.first = def->Object;
    opp.dt_param.count = 1;
    need_size = otd_proto_calc_size_ex(opp,0);
    buf = new BYTE[need_size];
    otd_proto_format_ex(buf,need_size,opp,0,&op);
    *op.addr=def->Address;
    *op.time_stamp=def->TimeStamp;
    dw=(def->Quality&192)?0:OTD_DIAG_NODATA;
    *op.diag=dw;
    if(def->Address.fa==OTD_FA_DISCRETE)
    {
      b=def->GetMaskedValue();
      otd_set_value(op.data,def->Object,&b,sizeof(b));
    }
    else
    {
      f=0.0;
      switch(def->Value.vt)
      {
        case VT_I1:
        case VT_I2:
        case VT_I4:
        case VT_I8:
        case VT_INT:
          f=def->Value.iVal;
          break;
        case VT_UI1:
        case VT_UI2:
        case VT_UI4:
        case VT_UI8:
        case VT_UINT:
          f=def->GetMaskedValue();
          break;
        case VT_R4:
        case VT_CY:
          f=def->Value.fltVal;
          break;
        case VT_R8:
          f=def->Value.dblVal;
          break;
      }
      otd_set_value(op.data,def->Object,&f,sizeof(float));
    }
    otd_inc_value(op.personal_chmask,def->Object,true);
    queue_rxdata(FA_OTD,(LPBYTE)op.addr,op.proto_size,false);
    if(buf) delete buf;
  }
}

void __fastcall opcclient_line::Connect()
{
  TStringList *sl=new TStringList;
  TStringList *ids=new TStringList;
  TItemDef *def;
  TListItem *li;
  sl->LoadFromFile(settings.cfg_name);
  for(int i=0; i<sl->Count; i++)
  {
    def=new TItemDef;
    if(def->FromString(sl->Strings[i]))
    {
      ids->Add(def->Name);
      ItemList->Add(def);
    }
    else
      delete def;
  }
  delete sl;
  try
  {
    Server=new TOPCServer(settings.srv_name);
    Group=new TAsyncOPCGroup(Server,ids,"MainGroup",settings.rate,settings.dead_band);
    Group->OnDataChange = OnChange;
  }
  __finally
  {
    delete ids;
  }
  if(Group)
    set_state(MODEM_LINE_STATE_CONNECT,true);
}

void __fastcall opcclient_line::Disconnect()
{
  set_state(MODEM_LINE_STATE_CONNECT,false);
  if (Group)
  {
    delete Group;
    Group=NULL;
  }
  if(Server)
  {
    delete Server;
    Server=NULL;
  }
  ItemList->Clear();
}

DWORD __fastcall opcclient_line::BitCount(DWORD v)
{
  #define g21 0x55555555ul // = 0101_0101_0101_0101_0101_0101_0101_0101
  #define g22 0x33333333ul // = 0011_0011_0011_0011_0011_0011_0011_0011
  #define g23 0x0f0f0f0ful // = 0000_1111_0000_1111_0000_1111_0000_1111

  v = (v & g21) + ((v >> 1) & g21);
  v = (v & g22) + ((v >> 2) & g22);
  v = (v + (v >> 4)) & g23;
  return (v + (v >> 8) + (v >> 16) + (v >> 24)) & 0x3f;
}


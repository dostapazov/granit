/****************************************************************************

 NT-Service helper library.

 Private declarations.

 Copyright (c) 2000,2002  Timofei Bondarenko, Kostya Volovich.
 ****************************************************************************/
#ifndef  NTSEPRIV_H_
#define  NTSEPRIV_H_

#include "ntse.h"
#include <unilog.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(USE_LOG) && USE_LOG >= 0
extern unilog *ntse_log;
#endif
#define NSLOG ntse_log,0

extern ntseContext ntse_null_context;

struct ntseService_int
	{
         ntseService   *niSe;
         SERVICE_STATUS niStatus;
         SERVICE_STATUS_HANDLE niSh;
         int            niWnd;  /* indicating w95 mode */
         /* following members are win95 only */
         DWORD          niLastStatus,
                        niLastAccept;
	};

typedef struct ntseService_int ntseService_int;

extern ntseService_int *ntse_servlist;
extern unsigned ntse_servcount;

extern const char ntse_classname[];

/* return Non-zero nc->ncNT95 >0 on NT, <0 on 95/8 */
int ntseSwitch95(ntseContext *nc, int rv);

int ntseStatus95(ntseHandle se, const SERVICE_STATUS *st);
int ntseControl95(ntseContext *nc, const char *name, int command, SERVICE_STATUS *st);
int ntseQueryConf95(ntseContext *nc, const char *name, QUERY_SERVICE_CONFIG **st);
int ntseChange95(ntseContext *nc,
                 const char *serviceName,   /* name of service */
                       int   serviceType,   /* type of service: */
                       int   startType,     /* when to start service */
                 const char *commandline);  /* name of binary file */
int ntseCreate95(ntseContext *nc,
                 const char *serviceName,   /* name of service */
                       int   serviceType,   /* type of service: */
                       int   startType,     /* when to start service */
                 const char *commandline);  /* name of binary file */

int ntseDelete95(const char *name);

int ntseServRun95(ntseContext *nc, 
                  int (*init_callback)(void *arg, HWND), void *arg); 
/* global ntse_serv/list/count should be prepared */

/* Update regitry to guarantee reinvocation of a RunService process */
int ntseAutoRun95(ntseContext *nc, const char *name, const char *commandline);
const char *ntsePrintState(unsigned state);

/* Windowing stuff */
#define nwCTL_MAX     (6) 
#define nwCTL_MAXMENU (nwCTL_MAX-1) /* 0, -1=noSutdown, -2=noInterrogate */

#define nwCmdFORALL    (256/*64*/)
#define nwCmdBASE      (nwCmdFORALL+nwCmdMUL)
#define nwCmdMUL       (256)
/* per-service commands (nwCmdBASE + nwCmd??? * nwCmdMUL) */
/* control codes: */
#define nwCmdCtlSTART    (0)
#define nwCmdCtlSTOP     (1)
/*
#define nwCmdCtlPAUSE    (2)
#define nwCmdCtlCONTINUE (3)
*/
#define nwCmdCtlINTERROGATE (4) /* Be careful: */
#define nwCmdCtlSHUTDOWN (5)    /* nwCmdCtlXXXX are indexes in ntse_ctlx[] ! */
/* helpers (per-service too): */
#define nwCmdSvSTATUS   (64)
/* Start type (potentially per-service): */
#define nwCmdStAUTO     (65)
#define nwCmdStDEMAND   (66)
#define nwCmdStDISABLED (67)
/* Ordinary per-window commands */
#define nwCmdWmSHOW     (68)
#define nwCmdWmHIDE     (69)
#define nwCmdWmEXIT     (70)
#define nwCmdWmQUIETEXIT (71)

typedef struct ntseCtlCode
  {
   unsigned ctlcode;
   unsigned accept;
   char    *ctlname;
  } ntseCtlCode;

extern const ntseCtlCode ntse_ctlx[nwCTL_MAX];

struct ntseContext
	{
	 char *ncHostname; /* for OpenSCManager() */
	 char *ncDatabase; /* for OpenSCManager() */
     int   ncNT95; /* 0=autodetect, 1=NT only, -1=Win95 only */
	};

#ifdef __cplusplus
           }
#endif
#endif /*NTSEPRIV_H_*/

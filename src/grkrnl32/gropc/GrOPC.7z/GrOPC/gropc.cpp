#define _WIN32_DCOM
#include "grclfact.h"
#define LOGID log,0
#include <errno.h>
#include <locale.h>
#include <opcda.h>

unilog *log;                    /* logging entry */

/********************* OPC vendor info ***************************************/
static const loVendorInfo vendor = {
  1 /*Major */ , 0 /*Minor */ , 0 /*Build */ , 0 /*Reserv */ ,
  "Granit OPC Server"
};

loService *gr_service;
static GrClassFactory gr_CF;

GrClassFactory::GrClassFactory(): server_inuse(0), server_count(0)
{
  InitializeCriticalSection(&lk_count);
}

GrClassFactory::~GrClassFactory()
{
  DeleteCriticalSection(&lk_count);
}

STDMETHODIMP GrClassFactory::QueryInterface(REFIID iid, LPVOID *ppInterface)
{
      if (ppInterface == NULL)
        return E_INVALIDARG;
      if (iid == IID_IUnknown || iid == IID_IClassFactory)
        {
          UL_DEBUG((LOGID, "grClassFactory::QueryInterface() Ok"));
          *ppInterface = this;
          AddRef();
          return S_OK;
        }
      UL_DEBUG((LOGID, "grClassFactory::QueryInterface() Failed"));
      *ppInterface = NULL;
      return E_NOINTERFACE;
}

STDMETHODIMP GrClassFactory::LockServer(BOOL fLock)
{
  UL_DEBUG((log,0, "grClassFactory::LockServer(%d)", fLock));
  if (fLock) serverAdd();
  else serverRemove();
  return S_OK;
}

void GrClassFactory::serverAdd(void)
{
  EnterCriticalSection(&lk_count);
  ++server_count;
  LeaveCriticalSection(&lk_count);
}

void GrClassFactory::serverRemove(void)
{
  EnterCriticalSection(&lk_count);
  if (0 == --server_count && server_inuse) server_inuse = 0;
  LeaveCriticalSection(&lk_count);
}

static void a_server_finished(void *arg, loService *b, loClient *c)
{
  /* ARG is the same as we've passed to loClientCreate() */
  UL_DEBUG((LOGID, "a_server_finished(%lu)...", gr_CF.server_count));
  gr_CF.serverRemove();

/* OPTIONAL: */
  UL_INFO((LOGID, "a_server_finished(%lu) USERID=<%ls>",
    gr_CF.server_count, arg? arg: L"<null>"));
}

STDMETHODIMP GrClassFactory::CreateInstance(LPUNKNOWN pUnkOuter, REFIID riid,
                                            LPVOID *ppvObject)
{
  IUnknown *server = 0;
  HRESULT hr = S_OK;

/* OPTIONAL: security stuff */
  OLECHAR *userid = 0;
  wchar_t *cuserid;
  LONG userno;
  static LONG usercount;

  userno = InterlockedIncrement(&usercount);

  CoQueryClientBlanket(0, 0, 0, 0, 0, (RPC_AUTHZ_HANDLE*)&userid, 0);
  if (!userid) userid = L"{unknown}";

  UL_WARNING((LOGID, "USER:#%ld <%ls>", userno, userid));

  if (cuserid = (wchar_t*)malloc((wcslen(userid) + 16) * sizeof(wchar_t)))
    swprintf(cuserid, L"#%ld %ls", userno, userid);
/* -- end of security stuff */

  if (pUnkOuter)
    {
#if 1 /* Do we support aggregation? */
     if (riid != IID_IUnknown) 
#endif
          return CLASS_E_NOAGGREGATION;
    }

  AddRef(); 
	serverAdd();  /* the lock for a_server_finished() */

/***********************************************
 * check other conditions (i.e. security) here *
 ***********************************************/

{

 IUnknown *inner = 0;
 if (loClientCreate(gr_service, (loClient**)&server, 0, &vendor, a_server_finished, this))
	 //loClientCreate_agg(gr_service, (loClient**)&server, 
  //                     pUnkOuter, &inner,
  //                     0, &vendor, a_server_finished, cuserid/*this*/))
    {
      Release(); 
			serverRemove();
      hr = E_OUTOFMEMORY;
      UL_MESSAGE((LOGID, "grClassFactory::loClientCreate_agg() failed"));
    }
    {
      hr = server->QueryInterface(riid, ppvObject); /* Then 2 (if success) */
      //server->Release(); /* Then 1 (on behalf of client) or 0 (if QI failed) */
      if (FAILED(hr)) 
        UL_MESSAGE((LOGID, "grClassFactory::loClient QueryInterface() failed"));
      /* So we shouldn't carry about SERVER destruction at this point */
    }
}
  if (SUCCEEDED(hr))
    {
      loSetState(gr_service, (loClient*)server,
             loOP_OPERATE, (int)OPC_STATUS_RUNNING, /* other states are possible */
             "Finished by client");
      UL_DEBUG((LOGID, "grClassFactory::server_count = %ld", server_count));
    }

  return hr;
}

/************************* The END of OLE-specific ***************************/

/****************** The Process Data to be exported via OPC ******************
 (driver's internal representation) */

static CRITICAL_SECTION lk_values;     /* protects ti[] from simultaneous 
                                    access by simulator() and WriteTags() */
/* Our data tags: */
/* zero is resierved for an invalid RealTag */
#define TI_zuzu      (1)
#define TI_lulu      (2)
#define TI_bandwidth (3)
#define TI_array     (4)
#define TI_enum      (5)
#define TI_quiet     (6)
#define TI_quality   (7)
#define TI_string    (8)
#define TI_MAX       (8)

static loTagId ti[TI_MAX + 1];          /* their IDs */
static const char *tn[TI_MAX + 1] =     /* their names */
{ "--not--used--", "zuzu", "lulu", "bandwidth", "array", "enum-localizable",
    "quiet", "quality", "string" };
static loTagValue tv[TI_MAX + 1];       /* their values */

int driver_init(int lflags)
{
  loDriver ld;
  VARIANT var;
  loTagId tti;
  int ecode;

  setlocale(LC_CTYPE, "");

  if (gr_service) 
    {
      UL_ERROR((LOGID, "Driver already initialized!"));
      return 0;
    }

  memset(&ld, 0, sizeof(ld));   /* basic server parameters: */
//  ld.ldRefreshRate = 3;//10;
  //ld.ldSubscribe = activation_monitor;
  //ld.ldWriteTags = WriteTags;
//  ld.ldReadTags = ReadTags;
  //ld.ldConvertTags = ConvertTags;
//#if 0
//  ld.ldAskItemID = AskItemID;
//#endif
  ld.ldFlags = lflags | loDF_IGNCASE |  /*loDf_FREEMARSH | loDf_BOTHMODEL | */
    /*loDF_NOCOMP| */ loDf_NOFORCE & 0 /*| loDF_SUBSCRIBE_RAW*/;
    /*Fix the Bug in ProTool *//*|loDF_IGNCASE */ ;
  ld.ldBranchSep = '/'; /* Hierarchial branch separator */
  ecode = loServiceCreate(&gr_service, &ld, 64 /* number of tags in the cache */);
                                               /* 500000 is ok too */ 
  UL_TRACE((LOGID, "%!e loCreate()=", ecode));
  if (ecode) return -1;

  //InitializeCriticalSection(&lk_values);
  memset(tv, 0, sizeof(tv));    /* instead of VariantInit() for each of them */

  VariantInit(&var);

/* OPTIONAL: Tags creation. Do you need a few tags? */

  V_I1(&var) = -1; /* the good practice: set the value first, then type. */
  V_VT(&var) = VT_I1; /* Do you know why? */

  ecode = loAddRealTag_a(gr_service,    
                  &ti[2], /* returned TagId (lightopc's identifier)*/
                  (loRealTag)2, /* != 0  (driver's internal identifier)*/
                  "Granit2",      /* tag name */
                  0,                     /* loTF_ Flags */
                  OPC_READABLE | OPC_WRITEABLE,          /* OPC access rights */
                  &var,                  /* type and value for conversion checks */
                  -1, 101); /*Analog EUtype: from -1 (unknown) to 101% (overload)*/
  UL_TRACE((LOGID, "%!e loCreate()=", ecode));
  UL_TRACE((LOGID, "%!e loAddRealTag_a()=", ti[2]));

	ecode = loAddRealTag_b(gr_service,    /* actual service context */
                         &ti[1],  /* returned TagId */
                         (loRealTag)1,     /* != 0  driver's key */
                         "Granit1",   /* tag name (hint) */
                         0,     /* loTF_ Flags */
                         OPC_READABLE | OPC_WRITEABLE, ti[2]);

	V_R8(&var) = 214.1; /* initial value. Will be used to check types conersions */
  V_VT(&var) = VT_R8;
  
	loAddRealTag(gr_service, &ti[3], (loRealTag)3, "Granit3",
               0, OPC_READABLE | OPC_WRITEABLE, &var, 0, 0);


  return 0;
}

void driver_destroy(void)
{
  if (gr_service)
    {
      int ecode = loServiceDestroy(gr_service);
      UL_INFO((LOGID, "%!e loDelete(%p) = ", ecode));

      for(ecode = 0; ecode < sizeof(tv) / sizeof(tv[0]); ecode++)
        VariantClear(&tv[ecode].tvValue);

      DeleteCriticalSection(&lk_values);

      gr_service = 0;
    }
}

HMODULE server_module = 0;

/***************************************************************************
 DLL-specefic stuff
 ***************************************************************************/

extern "C"
  BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
  if (fdwReason == DLL_PROCESS_ATTACH)
    {
      server_module = hinstDLL;

      log = unilog_Create("LOPC-dll", "|LOPC-dll", "%!T", -1,   /* Max filesize: -1 unlimited, -2 -don't change */
                          ll_DEBUG);    /* level [ll_FATAL...ll_DEBUG] */
      unilog_Redirect("LOPC-dll", "LightOPC", 0);
      unilog_Delete(log);
      log = unilog_Create("Lopc-Sample-dll", "|Lopc-Sample-dll", "", -1,        /* Max filesize: -1 unlimited, -2 -don't change */
                          ll_DEBUG);    /* level [ll_FATAL...ll_DEBUG] */
      UL_DEBUG((LOGID, "DllMAin(process_attach)"));
      if (!gr_service) driver_init(loDf_FREEMARSH | loDf_BOTHMODEL);
			//driver_init(0);    /* not the best place */
    }
  else if (fdwReason == DLL_PROCESS_DETACH)
    {

      UL_DEBUG((LOGID, "DllMAin(process_detach)"));
      unilog_Delete(log);
      log = 0;
      driver_destroy(); /* not the best place */
      //EnterCriticalSection(&my_CF.lk_count);
      //driver_destroy();
      //LeaveCriticalSection(&my_CF.lk_count);
    }

  return TRUE;
}

STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID *ppv)
{
  UL_DEBUG((LOGID, "DllGetClassObject() ..."));

  if (rclsid == CLSID_GranitOPCServer)
    {
      HRESULT hr = gr_CF.QueryInterface(riid, ppv);
      UL_DEBUG((LOGID, "%!l DllGetClassObject() >>%04X %s", hr, hr,
                FAILED(hr) ? "failed" : "Ok"));
      return hr;
    }
  UL_DEBUG((LOGID, "DllGetClassObject() >>CLASS_E_CLASSNOTAVAILABLE"));
  return CLASS_E_CLASSNOTAVAILABLE;
}

STDAPI DllCanUnloadNow(void)
{
  UL_DEBUG((LOGID, "DllCanUnloadNow() invoked servers=%d", gr_CF.server_count));
  gr_CF.serverAdd();
  gr_CF.serverRemove(); /* Force stopping the simulator if not used */
/* the simulator can be restarted in ICF::CreateInstance() if requested */
  if (0 == gr_CF.server_inuse) 
    {
      return S_OK;
    }
  return S_FALSE;
}

STDAPI DllRegisterServer(void)
{
  char sFile[FILENAME_MAX + 16];
  GetModuleFileName(server_module, sFile, sizeof(sFile) - 1);
  UL_DEBUG((LOGID, "DllRegister(%s)", sFile));
  return loServerRegister(&CLSID_GranitOPCServer, dProgID, dClsidName, sFile,
          "Both") ? SELFREG_E_CLASS: S_OK;
}

STDAPI DllUnregisterServer(void)
{
  return loServerUnregister(&CLSID_GranitOPCServer, dProgID)? SELFREG_E_CLASS: S_OK;
}
 
/******************* This is the end... ************************************/

//---------------------------------------------------------------------------

#ifndef opcclient_lineH
#define opcclient_lineH

#include <modem.hpp>
#include <SysUtils.hpp>
#include "opcclientmdm.h"
#include "../OPCClient/OPCClient.h"

//---------------------------------------------------------------------------
//,public TGKThread
class opcclient_line : public modem_line //,public TGKThread
{
protected:
  OCSETTINGS            settings;
  TOPCServer            *Server;
  TAsyncOPCGroup        *Group;
  TEvent                term_event;
  TList                 *ItemList;
  TSynchroSet           ss;
// TProcess              process;
// HANDLE                write_pipe;
// HANDLE                stdin_pipe;
// HANDLE                read_pipe;
// HANDLE                stdout_pipe;
// modem_proto_buffer    mpb;
// SECURITY_ATTRIBUTES   proc_sa;
// SECURITY_DESCRIPTOR   sd;
// STARTUPINFOW          startup_info;
// PROCESS_INFORMATION   proccess_info;
// TEventSimpleDataQueue send_queue;
//
// bool          __fastcall run_process();
// void          __fastcall cleanup_process();
//
// const char  * __fastcall get_gkthread_name(){ return "TProcess Line thread";}
//  void  __fastcall Terminate(){term_event.SetEvent(true);TGKThread::Terminate();}
//  int __fastcall Execute();
//  bool __fastcall BeforeExecute();
//  void __fastcall BeforeTerminate();

  DWORD __fastcall get_line_flags(){return MLPF_RXABLE|MLPF_TXABLE;}
  DWORD __fastcall get_max_frame_size(){return -1;}
  DWORD __fastcall get_tx_queue_size (){return 0;} // send_queue.QueueCount();}
  DWORD __fastcall get_line_text  (wchar_t * text,DWORD text_sz) ;
//
  bool  __fastcall do_start ();
  bool  __fastcall do_stop  ();
  bool  __fastcall send     (LPMPROTO_HEADER mph,DWORD sz) ;
// void  __fastcall send_processing();
// void  __fastcall recv_processing();
// void  __fastcall handle_recv();
// void  __fastcall on_disconnect();
  void  __fastcall release();
// DWORD __fastcall OnException(DWORD ExceptionCode,LPEXCEPTION_POINTERS);
  void __fastcall OnChange(TAsyncOPCGroup *group, int count, int *i);
  void __fastcall Connect();
  void __fastcall Disconnect();
  DWORD __fastcall BitCount(DWORD v);

public:
  opcclient_line(DWORD number);
  virtual ~opcclient_line(){release();}
  void __fastcall set_start_param(LPOCSETTINGS sp){lock();memcpy(&settings,sp,sizeof(*sp));unlock();}

};

#endif
